/* MBL Hub v1.1.56 — offline, one-time Pipeline transfer between devices.
   Never copies authentication, official sync queues, or writes to official MBL. */
(function(root){
 'use strict';
 const FORMAT='mbl-hub-pipeline-transfer';
 const VERSION=1;
 const WORK_FIELDS=['proceeding','docsSent','contractSentAt','contractSignedAt',
   'contractLastChecked','contractNotifiedAt','onboardingState','onboardingStartedAt',
   'onboardingLastChecked','trainingSentAt','trainingReportedAt','trainingVerifiedAt'];
 const ACTIVE=new Set(['attended','contract_pending','contract_quiet','contract_signed']);
 const LOCAL_STATUS=new Set(['attended','contract_pending','contract_quiet','contract_signed','hired','not_proceeding']);
 const clone=v=>JSON.parse(JSON.stringify(v));
 const has=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
 const str=x=>typeof x==='string'?x.trim():'';
 const email=x=>str(x).toLowerCase();
 const phone=x=>{let n=str(x).replace(/\D/g,'');if(n.startsWith('0044'))n=n.slice(4);else if(n.startsWith('44'))n=n.slice(2);else if(n.startsWith('0'))n=n.slice(1);return n.length>=10?n.slice(-10):'';};
 const name=x=>str(x).toLowerCase().replace(/\s+/g,' ');
 function pipelineCandidate(c){
   return !!(c&&(
     c.proceeding===true||c.pipeline&&Object.keys(c.pipeline).length||
     ACTIVE.has(c.status)||c.status==='hired'));
 }
 function record(c){
   const fields={};
   for(const key of WORK_FIELDS)if(has(c,key))fields[key]=clone(c[key]);
   return {mblId:str(c.mblId)||null,localOnly:!c.mblId,
     name:str(c.name),phone:str(c.phone),email:str(c.email),
     applied:str(c.applied),sourceStatus:LOCAL_STATUS.has(c.status)?c.status:null,
     pipeline:c.pipeline&&typeof c.pipeline==='object'?clone(c.pipeline):null,
     fields};
 }
 function make(candidates,at=new Date().toISOString()){
   if(!Array.isArray(candidates))throw Error('Missing Hub candidates');
   const entries=candidates.filter(pipelineCandidate).map(record);
   return {format:FORMAT,version:VERSION,createdAt:at,records:entries};
 }
 function validate(input){
   if(!input||typeof input!=='object'||Array.isArray(input)||
     input.format!==FORMAT||input.version!==VERSION||
     !Array.isArray(input.records)||input.records.length>10000)
       throw Error('This is not an MBL Hub Pipeline transfer file.');
   const valid=[];
   for(const r of input.records){
     if(!r||typeof r!=='object'||Array.isArray(r)||!str(r.name)||
       !(str(r.mblId)||phone(r.phone)||email(r.email))||
       !r.fields||typeof r.fields!=='object'||Array.isArray(r.fields)||
       r.pipeline!==null&&(typeof r.pipeline!=='object'||Array.isArray(r.pipeline)))
       throw Error('The Pipeline file has an invalid candidate record.');
     valid.push(r);
   }
   return valid;
 }
 function exactLocalMatch(record,c){
   if(!c||name(c.name)!==name(record.name))return false;
   const p=phone(record.phone),e=email(record.email);
   return !!((p&&phone(c.phone)===p)||(e&&email(c.email)===e));
 }
 function unique(list){return list.length===1?list[0]:null;}
 function plan(payload,destCandidates){
   const src=validate(payload);
   if(!Array.isArray(destCandidates))throw Error('Hub candidate database unavailable');
   const mblCount=new Map();
   for(const entry of src)if(str(entry.mblId))mblCount.set(str(entry.mblId),(mblCount.get(str(entry.mblId))||0)+1);
   const actions=[],skipped=[];
   const used=new Set();
   for(const entry of src){
     const id=str(entry.mblId);
     if(id&&mblCount.get(id)>1){skipped.push({name:entry.name,reason:'Duplicate source MBL ID'});continue;}
     const byOfficialId=id?destCandidates.filter(c=>str(c.mblId)===id):[];
     // An older Hub may have held a candidate locally before the official
     // MBL ID was assigned on either device. Only accept one exact name plus
     // exact telephone/email match; never guess between ambiguous contacts.
     const matched=byOfficialId.length?byOfficialId:
       destCandidates.filter(c=>(!id||!c.mblId)&&exactLocalMatch(entry,c));
     if(matched.length>1){skipped.push({name:entry.name,reason:'Ambiguous candidate match'});continue;}
     const dest=unique(matched);
     if(dest&&used.has(dest.id)){skipped.push({name:entry.name,reason:'Duplicate candidate match'});continue;}
     if(dest)used.add(dest.id);
     // Official MBL candidates not present on this laptop are imported
     // locally with their known MBL ID; a later official refresh will match
     // exactly. Do not manufacture an official status or any sync write.
     actions.push({type:dest?'update':'add',source:entry,destId:dest?.id??null});
   }
   return {actions,skipped,
     updates:actions.filter(a=>a.type==='update').length,
     adds:actions.filter(a=>a.type==='add').length,
     total:src.length};
 }
 function apply(payload,candidates,previousPlan){
   validate(payload);
   const p=previousPlan||plan(payload,candidates);
   const usedIds=new Set(candidates.map(c=>Number(c.id)).filter(Number.isFinite));
   let nextId=Math.max(0,...usedIds)+1;
   function allocateId(){while(usedIds.has(nextId))nextId++;usedIds.add(nextId);return nextId++;}
   for(const action of p.actions){
     const data=action.source;
     let c=action.type==='update'?candidates.find(x=>x.id===action.destId):null;
     if(action.type==='update'&&!c)throw Error('Candidate list changed during import; nothing was saved');
     if(c&&data.mblId&&!c.mblId){c.mblId=data.mblId;c.localOnly=false;}
     if(!c){
       c={id:allocateId(),mblId:data.mblId||null,localOnly:!data.mblId,
         name:data.name,phone:data.phone,email:data.email,applied:data.applied,
         status:data.sourceStatus||'to_call',notes:[],history:[],previousApplications:[],
         source:data.mblId?'Transferred from PC · awaiting official refresh':'Transferred local candidate',
         syncState:'imported_local'};
       candidates.push(c);
     }
     if(data.pipeline!==null)c.pipeline=clone(data.pipeline);
     else delete c.pipeline;
     for(const key of WORK_FIELDS){
       if(has(data.fields,key))c[key]=clone(data.fields[key]);
       else if(has(c,key))delete c[key];
     }
     // Only local progression, not official stages or induction bookings.
     // Retain an officially finished status; otherwise use progression label.
     if(data.sourceStatus&&c.officialCallStage!=='hired'&&
       c.officialCallStage!=='not_hired'&&
       c.officialCallStage!=='not_meeting_requirements'&&
       !['hired','not_proceeding','requirements_failed'].includes(c.status)){
       c.status=data.sourceStatus;
     }
     if(data.sourceStatus&&!has(data.fields,'proceeding')&&
       ['contract_pending','contract_quiet','contract_signed'].includes(data.sourceStatus)){
       c.proceeding=true;
     }
   }
   return {updated:p.updates,added:p.adds,skipped:p.skipped.length};
 }
 root.hubPipelineTransferV1156={FORMAT,VERSION,make,validate,plan,apply};
})(window);
