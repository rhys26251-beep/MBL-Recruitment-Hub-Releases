/* v1.1.59 — A copy-only day-before ridealong message.
 * Does not send messages, change candidate progress or transmit data.
 */
(function(root){
  'use strict';
  function firstName(candidate){
    const text=String(candidate?.name||'').trim();
    return text?text.split(/\s+/)[0]:'';
  }
  function message(candidate){
    const name=firstName(candidate);
    return 'Hello'+(name?' '+name:'')+',\n\n'+
      'Please arrive at the depot reception tomorrow at 11:45 AM for your ridealong.\n\n'+
      'Please bring a fully charged phone, a power bank, suitable work shoes and a high-visibility vest. '+
      'If you do not have a hi-vis vest, we can provide one.\n\n'+
      'I will add you to the driver WhatsApp group shortly.\n\n'+
      'Thank you,\nMBL Recruitment';
  }
  root.hubRidealongMessageV1159={firstName,message};
})(typeof window==='object'?window:globalThis);
