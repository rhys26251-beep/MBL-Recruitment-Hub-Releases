/* v1.1.53: purely local attendance evidence and official discrepancy detection.
 * Read-only helpers: never guess attendance from a booking or contact stage.
 * No remote writes, credentials, cookies, or personal data leave the Hub.
 */
(function(global){
  'use strict';
  const POSITIVE=new Set(['Attended','Attended · historical check','Attended — Not Proceeding']);
  const NEGATIVE=new Set(['Not Attended','Not Attended · historical check']);
  const FINAL_OFFICIAL=new Set(['hired','not_hired','not_meeting_requirements']);
  const DATE_RE=/^(\d{2})\/(\d{2})\/(\d{4})$/;
  function validDate(input){
    const m=DATE_RE.exec(String(input||''));
    if(!m)return null;
    const day=+m[1],month=+m[2],year=+m[3];
    const d=new Date(Date.UTC(year,month-1,day));
    return d.getUTCFullYear()===year&&d.getUTCMonth()===month-1&&d.getUTCDate()===day?input:null;
  }
  function stampDate(h,now){
    const detail=String(h?.[2]||'');
    // The historical-attendance form records the complete induction date.
    const explicit=detail.match(/(?:induction on|attended on|did not attend induction on)\s+(\d{2}\/\d{2}\/\d{4})/i);
    if(explicit&&validDate(explicit[1]))return explicit[1];
    // Legacy activity timestamps only contain DD/MM HH:MM. Use them only
    // for recent events; never assume an arbitrary old record's year.
    const match=String(h?.[0]||'').match(/^(\d{2})\/(\d{2})\s+\d{2}:\d{2}$/);
    if(!match)return null;
    const year=new Date(now).getFullYear();
    for(const y of [year,year-1]){
      const day=match[1]+'/'+match[2]+'/'+y;
      if(!validDate(day))continue;
      const [dd,mm,yyyy]=day.split('/').map(Number);
      const elapsed=now-Date.UTC(yyyy,mm-1,dd);
      if(elapsed>=-86400000&&elapsed<=45*86400000)return day;
    }
    return null;
  }
  function fromHistory(candidate,now=Date.now()){
    const history=Array.isArray(candidate?.history)?candidate.history:[];
    for(let i=history.length-1;i>=0;i--){
      const h=history[i],title=String(h?.[1]||'');
      // A later explicit undo must not re-activate an earlier decision.
      if(/^(Undo(?: Last)?|Attendance correction undone)$/i.test(title))return null;
      if(!POSITIVE.has(title)&&!NEGATIVE.has(title))continue;
      // A correction recorded the following day is evidence for the actual
      // induction date, not for the later moment the recruiter edited it.
      const corrected=candidate?.historicalDateCorrection?.date;
      const correctionNote=/induction outcome corrected|historical attendance correction|previous induction/i.test(String(h?.[2]||''));
      const date=correctionNote&&validDate(corrected)?corrected:stampDate(h,now);
      if(!date)continue;
      return {date,outcome:POSITIVE.has(title)?'attended':'not_attended',source:'history'};
    }
    return null;
  }
  function saved(candidate,now=Date.now()){
    const record=candidate?.attendanceRecord;
    if(record && validDate(record.date) &&
      ['attended','not_attended'].includes(record.outcome)){
      return {date:record.date,outcome:record.outcome,source:record.source||'record'};
    }
    return fromHistory(candidate,now);
  }
  function disagreement(candidate,now=Date.now()){
    if(!candidate?.mblId)return null;
    const local=saved(candidate,now);
    if(!local)return null;
    const official=String(candidate.officialCallStage||'');
    if(official===local.outcome || FINAL_OFFICIAL.has(official))return null;
    return {candidateId:candidate.id,mblId:candidate.mblId,name:candidate.name||'Unknown',
      date:local.date,outcome:local.outcome,source:local.source,
      official:official||'Unrecorded',officialDate:candidate.officialInduction||null};
  }
  global.hubAttendanceAuditV1153={validDate,stampDate,fromHistory,saved,disagreement};
})(window);
