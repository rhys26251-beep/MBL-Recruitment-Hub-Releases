/* Recruitment Hub Pipeline v1.1.50 — per-step stopwatch history and total pipeline clock.
   Local checklist data is intentionally separate from official MBL stages.
   Only final explicit hiring decisions use the official sync queue. */
(() => {
  'use strict';

  const STEPS=[
    {id:'proceeded',label:'Induction attended — proceeding'},
    {id:'contract_sent',label:'Contract sent'},
    {id:'contract_signed',label:'Contract signed'},
    {id:'onboarding_started',label:'Onboarding started'},
    {id:'training_ready',label:'Ready for online training'},
    {id:'training_sent',label:'Online training details sent'},
    {id:'training_reported',label:'Driver reported training completed'},
    {id:'training_verified',label:'Training verified in Cortex'},
    {id:'ridealong_complete',label:'Ridealong completed'},
    {id:'van_allocated',label:'Van allocated'},
    {id:'first_shift',label:'First working shift started'}
  ];
  const STEPS_BY_ID=Object.fromEntries(STEPS.map(s=>[s.id,s]));
  const ACTIVE=new Set(['contract_pending','contract_quiet','contract_signed']);
  const STOPPED=new Set(['requirements_failed','not_proceeding']);
  const ISO=()=>new Date().toISOString();

  function get(id){return state.candidates.find(x=>String(x.id)===String(id))||null;}
  function included(c){
    if(!c || c.pipeline?.archivedAt)return false;
    return c.proceeding===true || ACTIVE.has(c.status) ||
      c.status==='hired' || !!c.pipeline?.decision || !!c.pipeline?.pendingDecision ||
      !!c.pipeline?.alreadyHiredAt;
  }
  function ensure(c){
    if(!c.pipeline||typeof c.pipeline!=='object')c.pipeline={};
    if(!c.pipeline.steps||typeof c.pipeline.steps!=='object')c.pipeline.steps={};
    if(!c.pipeline.ridealong||typeof c.pipeline.ridealong!=='object')c.pipeline.ridealong={days:2,day1:'',day2:''};
    return c.pipeline;
  }
  function legacy(c,id){
    if(id==='proceeded')return c.proceeding===true || ACTIVE.has(c.status) ||
      c.status==='hired' || !!c.pipeline?.decision;
    if(id==='contract_sent')return !!c.docsSent && !!c.contractSentAt;
    if(id==='contract_signed')return !!c.contractSignedAt || c.status==='contract_signed';
    const onboarding=String(c.onboardingState||'');
    if(id==='onboarding_started')return ['training_ready','training_sent','complete'].includes(onboarding);
    if(id==='training_ready')return ['training_ready','training_sent','complete'].includes(onboarding);
    if(id==='training_sent')return onboarding==='training_sent';
    // "complete" in the old onboarding screen meant Amazon onboarding
    // was complete; it was NOT proof that online training was verified.
    return false;
  }
  function done(c,id){
    const val=c.pipeline?.steps?.[id];
    if(val===false)return false;
    if(typeof val==='string' && val.length)return true;
    if(val===true)return true;
    return legacy(c,id);
  }
  function completed(c){return STEPS.filter(s=>done(c,s.id)).length;}
  function percent(c){
    if(c.pipeline?.decision==='hired'||c.status==='hired')return 100;
    return Math.round(100*completed(c)/STEPS.length);
  }
  function next(c){return STEPS.find(x=>!done(c,x.id))||null;}
  function final(c){return c.pipeline?.decision==='hired'||c.pipeline?.decision==='not_hired'||
    c.status==='hired';}
  function latest(c,key){
    const v=c.pipeline?.steps?.[key];
    if(typeof v==='string')return v;
    if(key==='contract_sent')return c.contractSentAt||null;
    if(key==='contract_signed')return c.contractSignedAt||null;
    return null;
  }
  function ageH(iso){
    const t=Date.parse(iso||'');
    return Number.isFinite(t)?Math.max(0,(Date.now()-t)/3600000):Infinity;
  }
  // Thresholds in hours. Known operational windows take priority: Dropbox
  // first check at 3h, onboarding usually 48-72h, training verification ~24h.
  // Other stages use guidance thresholds, not official hiring deadlines.
  const STAGE_LIMITS={
    proceeded:[3,24],contract_sent:[3,24],contract_signed:[3,72],
    onboarding_started:[24,48],training_ready:[48,72],
    training_sent:[3,24],training_reported:[24,72],
    training_verified:[24,48],ridealong_complete:[48,120],
    van_allocated:[24,72],first_shift:[24,72],decision:[3,24]
  };
  const TOTAL_LIMITS=[168,336]; // 7 days / 14 days: advisory only
  function safeTime(value,now=Date.now()){
    // Never interpret a boolean, date-only field or ambiguous local string
    // as a precise start timestamp.
    if(typeof value!=='string'||
      !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value)||
      !/(Z|[+-]\d{2}:\d{2})$/i.test(value))return null;
    const t=Date.parse(value);
    return Number.isFinite(t)&&t>=Date.UTC(2020,0,1)&&t<=now+300000?t:null;
  }
  function stepTime(c,key,now){
    if(!done(c,key))return null;
    const p=c.pipeline||{};
    let date=safeTime(p.steps?.[key],now);
    if(date!==null)return date;
    const sources={
      proceeded:p.startedAt,
      contract_sent:c.contractSentAt,
      contract_signed:c.contractSignedAt,
      onboarding_started:c.onboardingStartedAt,
      training_sent:c.trainingSentAt,
      training_reported:c.trainingReportedAt,
      training_verified:c.trainingVerifiedAt
    };
    return safeTime(sources[key],now);
  }
  function clockResult(start,end,limits,estimate=false){
    if(start===null||end===null||end<start)
      return {known:false,elapsedMs:null,tone:'unknown',minimum:false,limits};
    const elapsedMs=end-start;
    const hours=elapsedMs/3600000;
    return {known:true,elapsedMs,minimum:estimate,
      tone:estimate?'unknown':hours>=limits[1]?'red':hours>=limits[0]?'orange':'green',
      startedAt:new Date(start).toISOString(),limits};
  }
  // Every step has its own independent stopwatch. The current step starts
  // at 00:00:00 when tracking begins or immediately when the previous step is
  // ticked. Completed step durations are frozen in the candidate's local data.
  // Historical steps completed before this update cannot have a trustworthy
  // duration reconstructed, so they remain untracked rather than invented.
  function currentStepKey(c){return next(c)?.id||'decision';}
  function initializeStepClocks(c,now=Date.now()){
    if(!c||!included(c)||final(c)||c.pipeline?.archivedAt)return;
    const p=ensure(c);
    const key=currentStepKey(c);
    const timestamp=new Date(now).toISOString();
    if(p.stepClocksVersion!==1||!p.stepClocks||
      typeof p.stepClocks!=='object'||Array.isArray(p.stepClocks)){
      p.stepClocks={};
      p.stepClocksVersion=1;
      p.stepClockActiveKey=key;
      p.stepClocks[key]={startedAt:timestamp};
      p.activeStageKey=key;
      p.stageEnteredAt=timestamp;
      save();
      return;
    }
    if(p.stepClockActiveKey!==key||!p.stepClocks[key]){
      const previous=p.stepClocks[p.stepClockActiveKey];
      if(previous&&!previous.finishedAt)previous.finishedAt=timestamp;
      p.stepClockActiveKey=key;
      p.stepClocks[key]={startedAt:timestamp};
      p.activeStageKey=key;
      p.stageEnteredAt=timestamp;
      save();
    }
  }
  function finishStepClock(c,oldKey,newKey,now=Date.now()){
    if(oldKey===newKey)return;
    const p=ensure(c),timestamp=new Date(now).toISOString();
    if(!p.stepClocks||p.stepClocksVersion!==1){
      initializeStepClocks(c,now);
      return;
    }
    const previous=p.stepClocks[oldKey];
    if(previous&&!previous.finishedAt)previous.finishedAt=timestamp;
    // Reopening an earlier step starts a fresh run of that step's stopwatch.
    p.stepClocks[newKey]={startedAt:timestamp};
    p.stepClockActiveKey=newKey;
    p.activeStageKey=newKey;
    p.stageEnteredAt=timestamp;
  }
  function timer(c,type,now=Date.now(),stepId=null){
    const n=Number.isFinite(now)?now:Date.now();
    const p=c?.pipeline||{};
    if(!c)return {known:false,elapsedMs:null,tone:'unknown'};
    const ended=!!p.archivedAt||final(c);
    const ending=ended?safeTime(p.archivedAt||p.decidedAt||p.alreadyHiredAt,n):n;
    if(type==='total'){
      // Reuse actual recorded pipeline start times, never replace them with
      // when this update was installed. For older records we show a grey
      // minimum elapsed time when the exact start is unavailable.
      const knownStart=safeTime(p.startedAt,n)??stepTime(c,'proceeded',n);
      if(knownStart!==null)return clockResult(knownStart,ending,TOTAL_LIMITS);
      const knownSteps=STEPS.map(s=>stepTime(c,s.id,n)).filter(t=>t!==null);
      if(!knownSteps.length)return clockResult(null,ending,TOTAL_LIMITS);
      return clockResult(Math.min(...knownSteps),ending,TOTAL_LIMITS,true);
    }
    if(type!=='stage'&&type!=='step')return {known:false,elapsedMs:null,tone:'unknown'};
    if(!ended)initializeStepClocks(c,n);
    const fresh=c.pipeline||{},current=currentStepKey(c);
    const key=type==='stage'?current:stepId;
    const limits=STAGE_LIMITS[key]||[24,72];
    const clock=key&&fresh.stepClocks?.[key];
    if(!clock)return {
      known:false,elapsedMs:null,tone:'unknown',
      stageKey:key,notStarted:!!key&&!done(c,key)&&key!==current,
      untracked:!!key&&done(c,key),stopped:ended,limits
    };
    const start=safeTime(clock.startedAt,n);
    const running=!ended&&current===key&&!clock.finishedAt;
    const completedAt=safeTime(clock.finishedAt,n)||
      (ended?ending:null)||
      (key&&done(c,key)?stepTime(c,key,n):null);
    const end=running?n:completedAt;
    const result=clockResult(start,end,limits);
    return {...result,stageKey:key,running,stopped:!running,completed:!!key&&done(c,key)};
  }
  function markStageTransition(c,before){
    const key=currentStepKey(c);
    if(key===before)return;
    finishStepClock(c,before,key);
  }
  function nextAction(c){
    if(c.pipeline?.archivedAt)return {kind:'archived',text:'Removed from pipeline · restore to resume',key:'archived'};
    if(c.pipeline?.alreadyHiredAt && !final(c))
      return {kind:'action',text:'Previously marked Hired locally · confirm with official MBL',key:'decision'};
    if(c.pipeline?.pendingDecision)return {kind:'waiting',text:'Official MBL hiring decision awaiting confirmation',key:'decision'};
    if(final(c))return {kind:'finished',text:c.pipeline?.decision==='not_hired'?'Not Hired':'Hired',key:'finished'};
    const s=next(c);
    if(!s)return {kind:'action',text:'Make final Hired / Not Hired decision',key:'decision'};
    const id=s.id;
    if(id==='proceeded')return {kind:'action',text:'Record induction proceeding decision',key:id};
    if(id==='contract_sent')return {kind:'action',text:'Send contract and tick Contract sent',key:id};
    if(id==='contract_signed'){
      const base=c.contractLastChecked||latest(c,'contract_sent');
      if(ageH(base)<3)return {kind:'waiting',text:'Waiting for signature · next Dropbox check in '+Math.max(1,Math.ceil(3-ageH(base)))+'h',key:id};
      return {kind:'action',text:'Check if the contract is signed in Dropbox',key:id};
    }
    if(id==='onboarding_started')return {kind:'action',text:'Check if onboarding has started in Cortex',key:id};
    if(id==='training_ready'){
      const wait=ageH(latest(c,'contract_signed'));
      if(wait<48)return {kind:'waiting',text:'Onboarding · check Cortex when ready (usually 48–72h)',key:id};
      return {kind:'action',text:'Check Cortex — ready for online training?',key:id};
    }
    if(id==='training_sent')return {kind:'action',text:'Copy training pack, get login from Cortex, then mark sent',key:id};
    if(id==='training_reported')return {kind:'waiting',text:'Waiting for driver to report training finished',key:id};
    if(id==='training_verified'){
      const hrs=ageH(latest(c,'training_reported'));
      if(hrs<24)return {kind:'waiting',text:'Training reported · Cortex may take ~24h to update',key:id};
      return {kind:'action',text:'Verify training completion in Cortex',key:id};
    }
    if(id==='ridealong_complete')return {kind:'action',text:'Arrange ridealong and record completed day(s)',key:id};
    if(id==='van_allocated')return {kind:'action',text:'Confirm a van has been allocated',key:id};
    if(id==='first_shift')return {kind:'action',text:'Confirm the driver has started their first shift',key:id};
    return {kind:'action',text:'Complete the next recruitment step',key:id};
  }

  // Newly proceeding candidates should start BEFORE "Contract sent".
  // The old Hub optimistically marked contracts sent when proceeding was selected.
  function enterFromInduction(c){
    if(!c||c.proceeding!==true)return;
    const p=ensure(c);
    if(p.startedAt)return;
    p.startedAt=ISO();
    p.steps.proceeded=p.startedAt;
    p.activeStageKey='contract_sent';
    p.stageEnteredAt=p.startedAt;
    p.stepClocksVersion=1;
    p.stepClockActiveKey='contract_sent';
    p.stepClocks={contract_sent:{startedAt:p.startedAt}};
    p.steps.contract_sent=false;
    c.docsSent=false;
    c.contractSentAt=null;
    c.contractLastChecked=null;
    c.contractNotifiedAt=null;
    c.onboardingStartedAt=null;
    c.onboardingState=null;
    c.status='attended';
    c.history=c.history||[];
    c.history.push([nowStamp(),'Recruitment pipeline started',
      'Attended and proceeding. Contract must be marked sent when actually sent.']);
    save();
  }
  const originalDecision=setProceedDecision;
  setProceedDecision=function(proceeding){
    const c=get(currentProceedId);
    const result=originalDecision(proceeding);
    if(proceeding && c && c.proceeding===true)enterFromInduction(c);
    if(currentPage==='home'||currentPage==='pipeline')render();
    return result;
  };
  const originalPast=window.setPastInductionOutcome;
  if(typeof originalPast==='function'){
    window.setPastInductionOutcome=function(id,outcome){
      const result=originalPast(id,outcome);
      if(outcome==='proceeding'){
        const c=get(id);
        if(c&&c.proceeding===true)enterFromInduction(c);
        render();
      }
      return result;
    };
  }

  // Any existing signed contracts remain complete on migration.
  // The new pipeline never infers "training verified" from 15/15.
  function record(c,label,detail){
    c.history=c.history||[];
    c.history.push([nowStamp(),label,detail||'']);
    save();
  }
  function completedAll(c){return STEPS.every(s=>done(c,s.id));}
  function tick(id,key,checked){
    const c=get(id);
    if(!included(c) || !STEPS_BY_ID[key] || final(c) || c.pipeline?.pendingDecision)return false;
    if(key==='proceeded'){toast('Change the induction decision from the induction record');return false;}
    const p=ensure(c);
    // Start tracking before the tick changes the current step. Invalid ticks
    // do not advance the stopwatch; successful ticks freeze the old timer.
    initializeStepClocks(c);
    const previousStage=currentStepKey(c);
    if(key==='contract_signed'){
      if(checked){
        if(!done(c,'contract_sent')){
          toast('First record that the contract has been sent');
          return false;
        }
        if(c.status!=='contract_signed'&&!c.contractSignedAt)markContractSigned(c.id);
        p.steps.contract_signed=ISO();
      }else{
        if(STEPS.some(s=>s.id!=='contract_signed'&&STEPS.indexOf(s)>2&&done(c,s.id))){
          toast('Undo later steps before unmarking Contract signed');
          return false;
        }
        if(c.status==='contract_signed' && typeof undoContractSigned==='function'){
          undoContractSigned(c.id);
          if(c.status==='contract_signed')return false;
        }else{
          c.contractSignedAt=null;
          c.status='contract_pending';
        }
        p.steps.contract_signed=false;
      }
    }else{
      p.steps[key]=checked?ISO():false;
    }
    if(key==='contract_sent'){
      if(checked){
        c.docsSent=true;c.contractSentAt=p.steps[key];c.contractLastChecked=c.contractSentAt;
        if(c.status==='attended')c.status='contract_pending';
      }else{
        if(done(c,'contract_signed')){
          p.steps[key]=ISO();
          toast('Contract already signed; cannot remove its sent record');
          return false;
        }
        c.docsSent=false;c.contractSentAt=null;c.contractLastChecked=null;
        if(c.status==='contract_pending'||c.status==='contract_quiet')c.status='attended';
      }
    }
    if(key==='onboarding_started' && checked){
      c.onboardingState='in_progress';
      c.onboardingStartedAt=p.steps[key];
      c.onboardingLastChecked=ISO();
    }
    if(key==='training_ready' && checked){
      c.onboardingState='training_ready';
      c.onboardingLastChecked=ISO();
    }
    if(key==='training_sent' && checked) {
      c.onboardingState='training_sent';
      c.trainingSentAt=p.steps[key];
    }
    if(key==='training_reported'&&checked)c.trainingReportedAt=p.steps[key];
    if(key==='training_verified'&&checked)c.trainingVerifiedAt=p.steps[key];
    if(key==='ridealong_complete'&&checked && !p.ridealong.day1){
      toast('Enter at least the first ridealong date before marking complete');
      p.steps[key]=false;
      return false;
    }
    markStageTransition(c,previousStage);
    record(c,checked?STEPS_BY_ID[key].label+' ✓':'Step unchecked',
      checked?'Confirmed manually in Recruitment Hub':'Reopened: '+STEPS_BY_ID[key].label);
    render();
    if(checked && key==='first_shift' && completedAll(c))setTimeout(()=>window.openPipelineDecisionV1142?.(c.id),50);
    return true;
  }
  // Remove and Restore affect the Hub only. Already Hired instead submits
  // through the verified official MBL hiring decision flow.
  function archive(id,reason){
    const c=get(id);
    if(!c || !included(c) || final(c) || c.pipeline?.pendingDecision)return false;
    const p=ensure(c);
    p.archivedAt=ISO();
    p.archiveReason=String(reason||'').trim()||'No reason given';
    record(c,'Removed from recruitment pipeline',p.archiveReason+' · Hub only, official MBL unchanged');
    render();return true;
  }
  function restore(id){
    const c=get(id),p=c?.pipeline;
    if(!p?.archivedAt)return false;
    const reason=p.archiveReason||'';
    delete p.archivedAt;
    delete p.archiveReason;
    // A restored candidate resumes the unfinished step with a fresh timer.
    if(p.stepClocksVersion===1){
      p.stepClockActiveKey=null;
    }
    record(c,'Restored to recruitment pipeline',reason?'Earlier removal reason: '+reason:'');
    render();return true;
  }
  function archived(){return state.candidates.filter(c=>!!c.pipeline?.archivedAt);}
  async function markAlreadyHired(id){
    // Skip old checklist ticks, but require verified official MBL confirmation.
    return decide(id,'hired','',true);
  }
  function undoAlreadyHired(id){
    const c=get(id),p=c?.pipeline;
    if(!p?.alreadyHiredAt || p.decision || c.status==='hired')return false;
    delete p.alreadyHiredAt;
    record(c,'Old local Already Hired mark cleared','Returned to active pipeline. Official MBL unchanged.');
    render();return true;
  }
  function ridealong(id,field,value){
    const c=get(id);
    if(!included(c)||final(c)||c.pipeline?.pendingDecision)return;
    const p=ensure(c);
    if(field==='days')p.ridealong.days=Number(value)===1?1:2;
    if(field==='day1'||field==='day2'){
      if(value && !/^\d{4}-\d{2}-\d{2}$/.test(value))return;
      p.ridealong[field]=value;
    }
    if(done(c,'ridealong_complete')&&(!p.ridealong.day1||
       (p.ridealong.days===2&&!p.ridealong.day2))){
      p.steps.ridealong_complete=false;
      initializeStepClocks(c);
    }
    save();render();
  }
  // Ridealong may be one or two days, on unrelated dates.
  function canCompleteRidealong(c){
    if(!c)return false;
    const r=c.pipeline?.ridealong||{};
    return !!r.day1 && (Number(r.days||2)===1||!!r.day2);
  }
  const oldTick=tick;
  function setStep(id,key,checked){
    const c=get(id);
    if(key==='ridealong_complete'&&checked&&!canCompleteRidealong(c)){
      toast('Enter the required ridealong dates first (one or two days)');
      return false;
    }
    return oldTick(id,key,checked);
  }
  async function decide(id,decision,reason,skipChecklist=false){
    const c=get(id);
    if(!c||!included(c)||final(c))return {error:'This candidate is not awaiting a hiring decision'};
    if(!completedAll(c) && !(skipChecklist===true && decision==='hired'))
      return {error:'Complete every recruitment step before making a hiring decision'};
    if(!['hired','not_hired'].includes(decision))return {error:'Choose Hired or Not Hired'};
    if(decision==='not_hired'&&!String(reason||'').trim())return {error:'Enter a reason for Not Hired'};
    if(!c.mblId)return {error:'This candidate must be linked to official MBL before the hiring decision can be submitted'};
    if(c.pipeline?.pendingDecision)return {error:'An official hiring update is already pending'};
    if(typeof window.pipelineQueueDecisionV1142!=='function')
      return {error:'Official hiring connection is unavailable. Update the Windows Hub.'};
    const p=ensure(c);
    p.pendingDecision=decision;
    p.pendingReason=String(reason||'').trim();
    p.pendingAt=ISO();
    p.pendingHiredShortcut=skipChecklist===true && decision==='hired';
    save();render();
    const response=await window.pipelineQueueDecisionV1142(c.id,decision,p.pendingReason);
    if(response?.error||response?.localOnly||response?.conflict){
      // A declined conflict has no queued write. Do not trap the candidate
      // in a permanent pending state after the user kept official MBL.
      if(response?.conflict && !(state.syncQueue||[]).some(q=>q.candidateId===c.id && q.status!=='done')){
        p.pendingDecision=null;p.pendingReason=null;p.pendingAt=null;p.pendingHiredShortcut=null;
      }
      save();render();
      return {error:response.error||'Official MBL did not confirm the hiring status; review Sync Pending in Settings'};
    }
    // A stale local stage is not proof that this write reached MBL.
    const stage=response?.verified?.candidate?.callStage;
    if(stage!==(decision==='hired'?'hired':'not_hired')){
      save();render();
      return {error:'Official MBL has not verified the hiring decision yet'};
    }
    p.decision=decision;p.decidedAt=ISO();p.reason=decision==='not_hired'?p.pendingReason:'';
    const usedShortcut=p.pendingHiredShortcut===true;
    if(usedShortcut)p.alreadyHiredAt=p.alreadyHiredAt||ISO();
    p.pendingDecision=null;p.pendingReason=null;p.pendingAt=null;p.pendingHiredShortcut=null;
    c.status=decision==='hired'?'hired':'not_proceeding';
    c.proceeding=decision==='hired';
    record(c,decision==='hired'
      ?(usedShortcut?'Already Hired shortcut — official MBL confirmed':'Hired — official MBL confirmed')
      :'Not Hired — official MBL confirmed',p.reason);
    render();
    return {ok:true};
  }
  function cancelPending(id){
    const c=get(id),p=c?.pipeline;
    if(!p?.pendingDecision)return false;
    if((state.syncQueue||[]).some(q=>q.candidateId===c.id && q.status!=='done')){
      toast('First resolve or discard the official hiring update in Settings');
      return false;
    }
    if(!confirm('Clear the pending hiring decision for '+c.name+'? This will not change official MBL.'))return false;
    p.pendingDecision=null;p.pendingReason=null;p.pendingAt=null;p.pendingHiredShortcut=null;
    record(c,'Hiring decision reset','Pending decision cleared; new confirmation may be submitted');
    render();return true;
  }
  function reconcile(){
    let dirty=false;
    for(const c of state.candidates){
      const p=c.pipeline;
      if(p?.decision && c.mblId && c.officialCallStage &&
        c.officialCallStage!==(p.decision==='hired'?'hired':'not_hired')){
        const earlier=p.decision;
        p.previousDecision=earlier;p.decision=null;
        c.history=c.history||[];
        c.history.push([nowStamp(),'Official hiring status changed',
          'Previously '+earlier+'; official MBL now '+c.officialCallStage+'. Please review before claiming Hired.']);
        dirty=true;
      }
      if(!p?.pendingDecision)continue;
      const match=p.pendingDecision==='hired'?'hired':'not_hired';
      if(c.officialCallStage===match && c.syncState!=='failed'){
        p.decision=p.pendingDecision;
        p.decidedAt=p.decidedAt||ISO();
        p.reason=p.pendingDecision==='not_hired'?p.pendingReason||'':'';
        const usedShortcut=p.pendingHiredShortcut===true;
        if(usedShortcut)p.alreadyHiredAt=p.alreadyHiredAt||ISO();
        p.pendingDecision=null;p.pendingAt=null;p.pendingReason=null;p.pendingHiredShortcut=null;
        c.status=match==='hired'?'hired':'not_proceeding';
        record(c,match==='hired'
          ?(usedShortcut?'Already Hired shortcut synced to official MBL':'Hired synced to MBL')
          :'Not Hired synced to MBL',p.reason);
        dirty=true;
      }
    }
    if(dirty)save();
  }
  const oldRender=render;
  render=function(){reconcile();return oldRender();};

  window.hubPipelineV1142={STEPS, get, included, done, completed, percent, next, nextAction,
    final, completedAll, ensure, tick:setStep, ridealong, canCompleteRidealong,
    decide,reconcile,cancelPending,ageH,archive,restore,archived,
    markAlreadyHired,undoAlreadyHired,timer,STAGE_LIMITS,TOTAL_LIMITS};
})();
