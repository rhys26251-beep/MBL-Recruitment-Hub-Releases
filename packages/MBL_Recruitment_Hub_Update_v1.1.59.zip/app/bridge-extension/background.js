const HUB_URL='http://127.0.0.1:53684';
const ALARM='mbl-bridge-refresh';
let scanBusy=false;
let followupTimer=null;
let lastAutoKick=0;

async function getState(){
  return await chrome.storage.local.get({
    amazonListUrl:'',amazonDetailUrls:[],dropboxUrls:[],autoRefresh:true,
    lastError:null,lastSend:null,lastBackgroundScan:null
  });
}
async function setState(patch){await chrome.storage.local.set(patch);}

async function sendToHub(payload){
  try{
    const r=await fetch(`${HUB_URL}/ingest`,{
      method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload)
    });
    const body=await r.json().catch(()=>({}));
    if(!r.ok||!body.ok)throw new Error(body.error||`Hub returned ${r.status}`);
    await setState({lastSend:new Date().toISOString(),lastError:null});
    return {ok:true};
  }catch(e){
    await setState({lastError:e.message||String(e)});
    return {ok:false,error:e.message||String(e)};
  }
}

async function remember(payload){
  const patch={};
  if(payload.source==='onboarding'){
    if(payload.bucket==='summary'&&payload.url)patch.amazonListUrl=payload.url;
    if(Array.isArray(payload.detailUrls)&&payload.detailUrls.length){
      const s=await getState();
      patch.amazonDetailUrls=[...new Set([...(s.amazonDetailUrls||[]),...payload.detailUrls])].slice(0,160);
    }
  }
  if(payload.source==='contracts'&&payload.url){
    const s=await getState();
    patch.dropboxUrls=[...new Set([...(s.dropboxUrls||[]),payload.url])].slice(-12);
  }
  if(Object.keys(patch).length)await setState(patch);
}

function scheduleOneFollowup(sender,payload){
  // Only a page the user actually opened is allowed to kick off a crawl.
  // Data coming from our own inactive scanner tab must never start another crawl.
  if(!sender?.tab?.active)return;
  if(!(payload?.source==='contracts'||payload?.bucket==='summary'))return;
  const now=Date.now();
  if(now-lastAutoKick<120000)return;
  clearTimeout(followupTimer);
  followupTimer=setTimeout(()=>{
    lastAutoKick=Date.now();
    runBackgroundScan(true);
  },2500);
}

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg?.type!=='MBL_BRIDGE_DATA'||!msg.payload)return;
  (async()=>{
    await remember(msg.payload);
    const result=await sendToHub(msg.payload);
    scheduleOneFollowup(sender,msg.payload);
    sendResponse(result);
  })();
  return true;
});

async function waitReady(tabId,timeout=25000){
  const start=Date.now();
  while(Date.now()-start<timeout){
    try{
      const t=await chrome.tabs.get(tabId);
      if(t.status==='complete')return true;
    }catch{return false;}
    await new Promise(r=>setTimeout(r,400));
  }
  return false;
}

async function scanUrlInTab(tabId,url,full){
  await chrome.tabs.update(tabId,{url,active:false});
  await waitReady(tabId,30000);
  await new Promise(r=>setTimeout(r,1200));
  try{
    return await chrome.tabs.sendMessage(tabId,{type:full?'MBL_SCAN_ALL':'MBL_SCAN_NOW'});
  }catch(e){
    return {ok:false,error:e.message||String(e)};
  }
}

async function runBackgroundScan(force=false){
  if(scanBusy)return {ok:false,error:'Scan already running.'};
  const s=await getState();
  if(!force&&!s.autoRefresh)return {ok:false,error:'Background refresh is off.'};
  scanBusy=true;
  let scannerTab=null;
  try{
    scannerTab=await chrome.tabs.create({url:'about:blank',active:false});
    let count=0;
    const primary=[...new Set([...(s.dropboxUrls||[]),s.amazonListUrl].filter(Boolean))];
    for(const url of primary){await scanUrlInTab(scannerTab.id,url,true);count++;}

    // The Associates list is enough for the recruitment workflow test.
    // 14/15 means online training needs sending; do not crawl every profile.
    await setState({lastBackgroundScan:new Date().toISOString(),lastError:null});
    return {ok:true,scanned:count};
  }catch(e){
    await setState({lastError:e.message||String(e)});
    return {ok:false,error:e.message||String(e)};
  }finally{
    if(scannerTab?.id)try{await chrome.tabs.remove(scannerTab.id);}catch{}
    scanBusy=false;
  }
}

chrome.runtime.onInstalled.addListener(()=>chrome.alarms.create(ALARM,{periodInMinutes:30}));
chrome.runtime.onStartup.addListener(()=>chrome.alarms.create(ALARM,{periodInMinutes:30}));
chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)runBackgroundScan(false);});
chrome.alarms.create(ALARM,{periodInMinutes:30});
