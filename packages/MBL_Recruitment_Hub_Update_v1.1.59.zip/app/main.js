const { app, BrowserWindow, ipcMain, shell, dialog, Notification, safeStorage, Menu } = require('electron');
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');

const BASE = 'https://inductions.mbllogistics.cloud';
const MCP_URL = `${BASE}/mcp`;
const META_URL = `${BASE}/.well-known/oauth-authorization-server`;
const RESOURCE_META_URL = `${BASE}/.well-known/oauth-protected-resource`;
const REDIRECT_PORT = 53682;
const REDIRECT_URI = `http://127.0.0.1:${REDIRECT_PORT}/callback`;
const DEPOT = 'HULL';
const APP_VERSION = app.getVersion();

const UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/rhys26251-beep/MBL-Recruitment-Hub-Releases/main/latest.json';

function versionParts(v) {
  return String(v || '0').replace(/^v/i, '').split('.').map(x => Number.parseInt(x, 10) || 0);
}
function compareVersions(a, b) {
  const aa = versionParts(a), bb = versionParts(b), n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) {
    const x = aa[i] || 0, y = bb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}
async function fetchUpdateManifest() {
  const sep = UPDATE_MANIFEST_URL.includes('?') ? '&' : '?';
  const res = await fetch(`${UPDATE_MANIFEST_URL}${sep}t=${Date.now()}`, {
    cache: 'no-store',
    headers: { 'User-Agent': 'MBL-Recruitment-Hub' }
  });
  if (!res.ok) throw new Error(`Update check failed (HTTP ${res.status}).`);
  const m = await res.json();
  if (!m || !m.version || !m.packageUrl || !m.sha256) throw new Error('Update manifest is incomplete.');
  return m;
}
function copyUpdateContents(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const from = path.join(src, entry.name);
    const to = path.join(dst, entry.name);
    if (entry.isDirectory()) copyUpdateContents(from, to);
    else fs.copyFileSync(from, to);
  }
}
async function applyUpdateZip(zip, expectedVersion = null) {
  const appDir = __dirname;
  const stage = fs.mkdtempSync(path.join(app.getPath('temp'), 'MBLHubUpdate-'));
  const logFile = path.join(app.getPath('userData'), 'update.log');
  const log = (m) => { try { fs.appendFileSync(logFile, `${new Date().toISOString()} ${m}\n`, 'utf8'); } catch {} };
  try {
    log(`Starting update from ${zip}`);
    const ps = `Expand-Archive -LiteralPath '${String(zip).replace(/'/g, "''")}' -DestinationPath '${String(stage).replace(/'/g, "''")}' -Force`;
    execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true, stdio: 'pipe' });
    const source = path.join(stage, 'app');
    if (!fs.existsSync(path.join(source, 'main.js')) || !fs.existsSync(path.join(source, 'index.html')) || !fs.existsSync(path.join(source, 'package.json'))) {
      throw new Error('This is not a valid MBL Recruitment Hub update package.');
    }
    let pkg = {};
    try { pkg = JSON.parse(fs.readFileSync(path.join(source, 'package.json'), 'utf8')); } catch {}
    if (pkg.name !== 'mbl-recruitment-hub') throw new Error('This update package is not for MBL Recruitment Hub.');
    if (expectedVersion && String(pkg.version) !== String(expectedVersion)) throw new Error(`Downloaded package version ${pkg.version || 'unknown'} does not match expected ${expectedVersion}.`);
    if (compareVersions(pkg.version, APP_VERSION) <= 0) throw new Error(`Version ${pkg.version || 'unknown'} is not newer than the installed version ${APP_VERSION}.`);
    copyUpdateContents(source, appDir);
    log(`Files copied successfully. Target version: ${pkg.version || 'unknown'}`);
    try { fs.rmSync(stage, { recursive: true, force: true }); } catch {}
    setTimeout(() => { try { app.relaunch(); } catch {} app.exit(0); }, 700);
    return { ok: true, version: pkg.version || null };
  } catch (e) {
    log(`Update failed: ${e.message}`);
    try { fs.rmSync(stage, { recursive: true, force: true }); } catch {}
    return { ok: false, error: `Update failed: ${e.message}` };
  }
}

let mainWindow = null;
let mcpSessionId = null;
let oauthMeta = null;
let requestId = 100;
let cachedWhoAmI = null;
let connection = { ok: false, state: 'disconnected', message: 'Sign in required', at: null };
const timers = new Map();

const BRIDGE_PORT = 53684;
const SUPPORT_PORT = 53685;
let bridgeServer = null;
let supportServer = null;
let supportServerState = { state: 'stopped', message: 'Not started', at: null };
let bridgeServerState = { state: 'stopped', message: 'Not started', at: null };
function emptyBridgeData(){return {contracts:[],onboarding:[],contractSync:null,onboardingSync:null,lastPayload:null}}
function readBridgeData(){return readJson(dataFile('bridge-test-data.json'),emptyBridgeData())}
function saveBridgeData(v){writeJson(dataFile('bridge-test-data.json'),v)}
function bridgeRowKey(r){return String(r?.href||r?.providerId||`${r?.document||''}|${r?.status||''}|${r?.updatedDisplay||''}|${r?.name||''}`)}
function mergeContractBridge(existing,rows){
  let out=Array.isArray(existing)?existing.slice():[];
  for(const raw of (Array.isArray(rows)?rows:[])){
    const r={...raw,receivedAt:new Date().toISOString()};
    if(r.href) out=out.filter(x=>x.href!==r.href);
    else {const k=bridgeRowKey(r);out=out.filter(x=>bridgeRowKey(x)!==k)}
    out.push(r);
  }
  return out.sort((a,b)=>Date.parse(b.sourceUpdatedAt||b.updated||b.receivedAt||0)-Date.parse(a.sourceUpdatedAt||a.updated||a.receivedAt||0)).slice(0,1500);
}
function mergeOnboardingBridge(existing,rows){
  const out=Array.isArray(existing)?existing.slice():[];
  for(const raw of (Array.isArray(rows)?rows:[])){
    const id=String(raw.providerId||raw.href||raw.name||'').trim(); if(!id)continue;
    const idx=out.findIndex(x=>String(x.providerId||x.href||x.name||'').trim()===id);
    const prior=idx>=0?out[idx]:{};
    const merged={...prior,...Object.fromEntries(Object.entries(raw).filter(([,v])=>v!==''&&v!=null)),receivedAt:new Date().toISOString()};
    if(idx>=0)out[idx]=merged;else out.push(merged);
  }
  return out.slice(-400);
}
function acceptBridgePayload(payload){
  const data=readBridgeData(),now=new Date().toISOString();
  if(payload?.source==='contracts'){
    data.contracts=mergeContractBridge(data.contracts,payload.rows);
    data.contractSync=now;
  }else if(payload?.source==='onboarding'){
    data.onboarding=mergeOnboardingBridge(data.onboarding,payload.rows);
    data.onboardingSync=now;
  }else throw new Error('Unknown bridge source.');
  data.lastPayload={source:payload.source,bucket:payload.bucket||null,url:payload.url||null,rows:Array.isArray(payload.rows)?payload.rows.length:0,at:now};
  saveBridgeData(data);
  try{mainWindow?.webContents.send('bridge:data',data)}catch{}
  return data;
}
function startBridgeServer(){
  if(bridgeServer)return;
  bridgeServer=http.createServer((req,res)=>{
    const origin=String(req.headers.origin||'');
    const reply=(code,obj)=>{res.writeHead(code,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj))};
    if(req.method==='GET'&&req.url==='/health')return reply(200,{ok:true,app:'MBL Recruitment Hub',version:APP_VERSION});
    if(req.method!=='POST'||req.url!=='/ingest')return reply(404,{ok:false,error:'Not found'});
    if(origin && !origin.startsWith('chrome-extension://'))return reply(403,{ok:false,error:'Bridge accepts the installed browser companion only.'});
    let body='',tooLarge=false;
    req.on('data',c=>{body+=c;if(body.length>2_000_000){tooLarge=true;req.destroy()}});
    req.on('end',()=>{
      if(tooLarge)return;
      try{const payload=JSON.parse(body||'{}');const data=acceptBridgePayload(payload);reply(200,{ok:true,source:payload.source,rows:Array.isArray(payload.rows)?payload.rows.length:0,stored:{contracts:data.contracts.length,onboarding:data.onboarding.length}})}
      catch(e){reply(400,{ok:false,error:e.message})}
    });
  });
  bridgeServer.on('error',e=>{bridgeServerState={state:'error',message:e.message,at:new Date().toISOString()}});
  bridgeServer.listen(BRIDGE_PORT,'127.0.0.1',()=>{bridgeServerState={state:'listening',message:`Reader listening on this PC`,at:new Date().toISOString()}});
}


function dataFile(name) { return path.join(app.getPath('userData'), name); }
function readJson(file, fallback = {}) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
  fs.renameSync(tmp, file);
}


function emptySupportSnapshot(){
  return { appVersion: APP_VERSION, generatedAt: null, lastMblRefresh: null, connectionOk: false, currentPage: null, candidates: [] };
}
function readSupportSnapshot(){ return readJson(dataFile('support-snapshot.json'), emptySupportSnapshot()); }
function saveSupportSnapshot(v){ writeJson(dataFile('support-snapshot.json'), v); }
function acceptSupportSnapshot(payload){
  const safe = payload && typeof payload === 'object' ? payload : {};
  const candidates = Array.isArray(safe.candidates) ? safe.candidates.slice(0, 2500).map(c => ({
    id: String(c?.id || ''),
    mblId: String(c?.mblId || ''),
    name: String(c?.name || ''),
    status: String(c?.status || ''),
    displayStatus: String(c?.displayStatus || c?.status || ''),
    officialStage: String(c?.officialStage || ''),
    officialCallStage: c?.officialCallStage == null ? '' : String(c.officialCallStage),
    officialInduction: String(c?.officialInduction || ''),
    induction: String(c?.induction || ''),
    attempts: Number(c?.attempts || 0),
    officialAttempts: Number(c?.officialAttempts || 0),
    applied: String(c?.applied || ''),
    source: String(c?.source || ''),
    localOnly: !!c?.localOnly,
    syncState: String(c?.syncState || '')
  })) : [];
  const out = {
    appVersion: String(safe.appVersion || APP_VERSION),
    generatedAt: new Date().toISOString(),
    lastMblRefresh: safe.lastMblRefresh || null,
    connectionOk: !!safe.connectionOk,
    currentPage: safe.currentPage || null,
    candidates
  };
  saveSupportSnapshot(out);
  return out;
}
function supportPageHtml(){
  try { return fs.readFileSync(path.join(__dirname, 'support.html'), 'utf8'); }
  catch { return '<!doctype html><title>MBL Recruitment Hub Support</title><h1>Support page unavailable</h1>'; }
}
function startSupportServer(){
  if(supportServer)return;
  supportServer=http.createServer((req,res)=>{
    const url=String(req.url||'/').split('?')[0];
    if(req.method!=='GET'){res.writeHead(405);return res.end('Read-only');}
    if(url==='/snapshot'){
      const body=JSON.stringify(readSupportSnapshot());
      res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','content-length':Buffer.byteLength(body)});return res.end(body);
    }
    if(url==='/health'){
      const body=JSON.stringify({ok:true,app:'MBL Recruitment Hub Support',version:APP_VERSION,port:SUPPORT_PORT});
      res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','content-length':Buffer.byteLength(body)});return res.end(body);
    }
    const body=supportPageHtml();
    res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store','content-length':Buffer.byteLength(body)});res.end(body);
  });
  supportServer.on('error',e=>{supportServerState={state:'error',message:e.message,at:new Date().toISOString()}});
  supportServer.listen(SUPPORT_PORT,'127.0.0.1',()=>{supportServerState={state:'listening',message:'Read-only support view ready',at:new Date().toISOString()}});
}
function b64url(buf) { return Buffer.from(buf).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_'); }
function randomUrlSafe(bytes = 48) { return b64url(crypto.randomBytes(bytes)); }
function normalizePhone(v = '') { return String(v).replace(/[^\d+]/g, ''); }
function toApiDate(dmy = '') {
  const m = String(dmy).match(/^(\d{2})[\/\-](\d{2})[\/\-](\d{4})$/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : dmy;
}
function datePart(v = '') {
  const m = String(v).match(/(\d{2})[-\/](\d{2})[-\/](\d{4})/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : '';
}

function timePart(v = '') {
  const m = String(v || '').match(/(?:^|\s)(\d{2}:\d{2})(?:$|\s)/);
  return m ? m[1] : '';
}

function encryptText(value) {
  if (!value) return null;
  try {
    if (safeStorage.isEncryptionAvailable()) return { enc: true, value: safeStorage.encryptString(value).toString('base64') };
  } catch {}
  return { enc: false, value };
}
function decryptText(obj) {
  if (!obj) return null;
  if (typeof obj === 'string') return obj;
  try {
    if (obj.enc) return safeStorage.decryptString(Buffer.from(obj.value, 'base64'));
  } catch {}
  return obj.value || null;
}
function loadAuth() {
  const raw = readJson(dataFile('mbl-auth.json'), {});
  return {
    client_id: raw.client_id || null,
    access_token: decryptText(raw.access_token),
    refresh_token: decryptText(raw.refresh_token),
    expires_at: raw.expires_at || 0,
  };
}
function saveAuth(auth) {
  writeJson(dataFile('mbl-auth.json'), {
    client_id: auth.client_id || null,
    access_token: encryptText(auth.access_token),
    refresh_token: encryptText(auth.refresh_token),
    expires_at: auth.expires_at || 0,
  });
}
function clearTokensKeepClient() {
  const a = loadAuth();
  saveAuth({ client_id: a.client_id, access_token: null, refresh_token: null, expires_at: 0 });
  mcpSessionId = null;
  cachedWhoAmI = null;
}

async function fetchJson(url, opts = {}) {
  const res = await fetch(url, opts);
  const text = await res.text();
  let body = null;
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!res.ok) {
    const err = new Error(body?.error_description || body?.error?.message || body?.message || `${res.status} ${res.statusText}`);
    err.status = res.status; err.body = body; throw err;
  }
  return body;
}
async function loadOAuthMeta() {
  if (oauthMeta) return oauthMeta;
  oauthMeta = await fetchJson(META_URL);
  return oauthMeta;
}
async function registerClientIfNeeded() {
  const auth = loadAuth();
  if (auth.client_id) return auth.client_id;
  const meta = await loadOAuthMeta();
  const reg = await fetchJson(meta.registration_endpoint, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      client_name: 'MBL Recruitment Hub Desktop',
      redirect_uris: [REDIRECT_URI],
      grant_types: ['authorization_code', 'refresh_token'],
      response_types: ['code'],
      token_endpoint_auth_method: 'none'
    })
  });
  if (!reg.client_id) throw new Error('MBL did not return an OAuth client ID.');
  saveAuth({ ...auth, client_id: reg.client_id });
  return reg.client_id;
}
async function waitForOAuthCallback(expectedState) {
  return await new Promise((resolve, reject) => {
    let done = false;
    let timeout = null;
    const finish = (err, value) => {
      if (done) return; done = true;
      if (timeout) clearTimeout(timeout); try { server.close(); } catch {}
      err ? reject(err) : resolve(value);
    };
    const server = http.createServer((req, res) => {
      try {
        const u = new URL(req.url, `http://127.0.0.1:${REDIRECT_PORT}`);
        const html = `<!doctype html><html><body style="font-family:Segoe UI;background:#101316;color:#eee;padding:48px"><h2 style="color:#f22f3d">MBL Recruitment Hub</h2><p>Sign-in received. You can close this tab and return to Recruitment Hub.</p></body></html>`;
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-length': Buffer.byteLength(html) }); res.end(html);
        const error = u.searchParams.get('error');
        if (error) return finish(new Error(`${error}: ${u.searchParams.get('error_description') || ''}`));
        const returnedState = u.searchParams.get('state');
        if (returnedState !== expectedState) return finish(new Error('OAuth state mismatch. Sign-in was cancelled for safety.'));
        const code = u.searchParams.get('code');
        if (!code) return finish(new Error('No authorization code was returned by MBL.'));
        finish(null, code);
      } catch (e) { finish(e); }
    });
    server.on('error', e => finish(new Error(`Could not listen for MBL sign-in on port ${REDIRECT_PORT}: ${e.message}`)));
    server.listen(REDIRECT_PORT, '127.0.0.1');
    timeout = setTimeout(() => finish(new Error('Timed out waiting for MBL sign-in.')), 5 * 60 * 1000);
  });
}
async function refreshAccessToken() {
  const auth = loadAuth();
  if (!auth.refresh_token || !auth.client_id) throw new Error('Sign in required.');
  const meta = await loadOAuthMeta();
  const body = new URLSearchParams({
    grant_type: 'refresh_token', refresh_token: auth.refresh_token, client_id: auth.client_id, resource: MCP_URL
  });
  const token = await fetchJson(meta.token_endpoint, {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: body.toString()
  });
  const next = {
    client_id: auth.client_id,
    access_token: token.access_token,
    refresh_token: token.refresh_token || auth.refresh_token,
    expires_at: Date.now() + Math.max(60, Number(token.expires_in || 3600) - 60) * 1000
  };
  saveAuth(next); mcpSessionId = null; return next.access_token;
}
async function interactiveConnect() {
  connection = { ok: false, state: 'connecting', message: 'Waiting for MBL sign-in…', at: new Date().toISOString() };
  const meta = await loadOAuthMeta();
  const clientId = await registerClientIfNeeded();
  const verifier = randomUrlSafe(64);
  const challenge = b64url(crypto.createHash('sha256').update(verifier, 'ascii').digest());
  const state = randomUrlSafe(24);
  const params = new URLSearchParams({
    response_type: 'code', client_id: clientId, redirect_uri: REDIRECT_URI,
    code_challenge: challenge, code_challenge_method: 'S256', state, resource: MCP_URL
  });
  if (Array.isArray(meta.scopes_supported) && meta.scopes_supported.length) params.set('scope', meta.scopes_supported.join(' '));
  const authUrl = `${meta.authorization_endpoint}?${params.toString()}`;

  const callbackPromise = waitForOAuthCallback(state);
  await new Promise(r => setTimeout(r, 180));
  await shell.openExternal(authUrl);
  const code = await callbackPromise;

  const tokenBody = new URLSearchParams({
    grant_type: 'authorization_code', code, redirect_uri: REDIRECT_URI,
    client_id: clientId, code_verifier: verifier, resource: MCP_URL
  });
  const token = await fetchJson(meta.token_endpoint, {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: tokenBody.toString()
  });
  if (!token.access_token) throw new Error('MBL did not return an access token.');
  saveAuth({
    client_id: clientId, access_token: token.access_token, refresh_token: token.refresh_token || null,
    expires_at: Date.now() + Math.max(60, Number(token.expires_in || 3600) - 60) * 1000
  });
  mcpSessionId = null;
  const who = await callTool('whoami', {}, true);
  cachedWhoAmI = who;
  connection = { ok: true, state: 'live', message: 'Connected', at: new Date().toISOString(), account: who };
  return connection;
}

function parseMcpBody(text) {
  if (!text || !String(text).trim()) return null;
  const trim = String(text).trim();
  try { return JSON.parse(trim); } catch {}
  for (const line of trim.split(/\r?\n/)) {
    if (line.startsWith('data:')) {
      try { return JSON.parse(line.slice(5).trim()); } catch {}
    }
  }
  return null;
}
async function mcpFetch(payload, token, sessionId = '') {
  const headers = {
    'authorization': `Bearer ${token}`,
    'accept': 'application/json, text/event-stream',
    'content-type': 'application/json'
  };
  if (sessionId) headers['mcp-session-id'] = sessionId;
  return await fetch(MCP_URL, { method: 'POST', headers, body: JSON.stringify(payload) });
}
async function ensureMcpSession(token) {
  if (mcpSessionId) return mcpSessionId;
  const init = {
    jsonrpc: '2.0', id: ++requestId, method: 'initialize', params: {
      protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'MBL Recruitment Hub', version: APP_VERSION }
    }
  };
  const res = await mcpFetch(init, token);
  const text = await res.text();
  if (res.status === 401) { const e = new Error('Unauthorized'); e.status = 401; throw e; }
  if (!res.ok) throw new Error(`MCP initialize failed: ${res.status} ${text.slice(0, 200)}`);
  const parsed = parseMcpBody(text);
  if (parsed?.error) throw new Error(parsed.error.message || 'MCP initialize error');
  mcpSessionId = res.headers.get('mcp-session-id') || '';
  try {
    const notif = { jsonrpc: '2.0', method: 'notifications/initialized', params: {} };
    const nr = await mcpFetch(notif, token, mcpSessionId); await nr.text();
  } catch {}
  return mcpSessionId;
}
async function getValidToken(interactive = false) {
  let auth = loadAuth();
  if (auth.access_token && (!auth.expires_at || auth.expires_at > Date.now())) return auth.access_token;
  if (auth.refresh_token) {
    try { return await refreshAccessToken(); } catch { clearTokensKeepClient(); }
  }
  if (interactive) { await interactiveConnect(); return loadAuth().access_token; }
  throw new Error('Sign in required.');
}
async function rawToolCall(name, args = {}, interactive = false, retried = false) {
  let token = await getValidToken(interactive);
  try {
    await ensureMcpSession(token);
    const payload = { jsonrpc: '2.0', id: ++requestId, method: 'tools/call', params: { name, arguments: args } };
    const res = await mcpFetch(payload, token, mcpSessionId);
    const text = await res.text();
    if (res.status === 401) { const e = new Error('Unauthorized'); e.status = 401; throw e; }
    if (!res.ok) throw new Error(`${name} failed: HTTP ${res.status}`);
    const parsed = parseMcpBody(text);
    if (!parsed) throw new Error(`${name} returned an unreadable response.`);
    if (parsed.error) throw new Error(parsed.error.message || `${name} returned an MCP error.`);
    if (parsed.result?.isError) {
      const msg = parsed.result.content?.map(x => x.text).filter(Boolean).join('\n') || `${name} failed.`;
      throw new Error(msg);
    }
    return parsed.result || {};
  } catch (e) {
    if (e.status === 401 && !retried) {
      try { await refreshAccessToken(); mcpSessionId = null; return await rawToolCall(name, args, interactive, true); }
      catch { clearTokensKeepClient(); throw new Error('MBL sign-in has expired. Please reconnect.'); }
    }
    throw e;
  }
}
function extractStructured(result) {
  if (result?.structuredContent && Object.keys(result.structuredContent).length) return result.structuredContent;
  for (const item of result?.content || []) {
    if (item?.type === 'text' && item.text) {
      const candidates = [item.text, ...(item.text.match(/\{[\s\S]*\}$/) ? [item.text.slice(item.text.indexOf('{'))] : [])];
      for (const t of candidates) { try { return JSON.parse(t); } catch {} }
    }
  }
  return {};
}
async function callTool(name, args = {}, interactive = false) {
  return extractStructured(await rawToolCall(name, args, interactive));
}
async function checkConnection() {
  try {
    const who = await callTool('whoami', {}, false);
    cachedWhoAmI = who;
    connection = { ok: true, state: 'live', message: 'Connected', at: new Date().toISOString(), account: who };
  } catch (e) {
    connection = { ok: false, state: /sign in|required|expired/i.test(e.message) ? 'signin' : 'offline', message: e.message, at: new Date().toISOString() };
  }
  return connection;
}

async function searchRecentCandidates(maxPages = 8) {
  const all = [];
  let page = 1, pageCount = 1;
  do {
    const r = await callTool('search_candidates', { view: 'all', depot: DEPOT, page });
    const rows = r.candidates || [];
    all.push(...rows);
    pageCount = Math.min(Number(r.pageCount || 1), maxPages);
    page++;
  } while (page <= pageCount);
  return all;
}
async function getCandidateSafe(id) {
  try { return await callTool('get_candidate', { contact_id: id }); } catch { return null; }
}
async function buildSnapshot(knownIds = []) {
  const [board, sessions, recent] = await Promise.all([
    callTool('get_call_board', { depot: DEPOT }),
    callTool('list_sessions', { when: 'upcoming', depot: DEPOT }),
    searchRecentCandidates(8)
  ]);
  const contactMap = new Map((recent || []).map(c => [c.id, c]));
  const candidates = [];
  const seen = new Set();
  for (const col of board.columns || []) {
    for (const b of col.candidates || []) {
      seen.add(b.id);
      let d = contactMap.get(b.id);
      if (!d) {
        const full = await getCandidateSafe(b.id);
        d = full?.candidate || {};
      }
      candidates.push({
        mblId: b.id, name: d?.name || b.name || 'Unknown candidate', phone: d?.phone || '', email: d?.email || '',
        applied: d?.applied || '', source: d?.source || 'MBL', officialStage: d?.stage || null,
        officialCallStage: col.stage === 'to_call' ? (d?.callStage || null) : (col.stage || d?.callStage || null), officialInduction: d?.induction || b.induction || null,
        attempts: Number(b.calls ?? d?.callAttempts ?? 0), lastCalledBy: b.lastCalledBy || null, offboard: false
      });
    }
  }
  const extraIds = [...new Set((knownIds || []).filter(Boolean))].filter(id => !seen.has(id)).slice(0, 40);
  for (const id of extraIds) {
    const full = await getCandidateSafe(id); if (!full?.candidate) continue;
    const d = full.candidate;
    candidates.push({
      mblId: id, name: d.name || 'Unknown candidate', phone: d.phone || '', email: d.email || '', applied: d.applied || '', source: d.source || 'MBL',
      officialStage: d.stage || null, officialCallStage: d.callStage || null, officialInduction: d.induction || null,
      attempts: Number(d.callAttempts || 0), lastCalledBy: null, offboard: true
    });
  }
  return {
    at: new Date().toISOString(), depot: DEPOT, candidates,
    sessions: sessions.sessions || [], account: cachedWhoAmI, connection
  };
}
function timelineNotes(timeline = []) {
  return timeline.filter(t => String(t.kind || '').toLowerCase() === 'note' || /note/i.test(t.title || '')).map(t => t.detail).filter(Boolean);
}
async function candidateDetails(mblId, email, phone) {
  const detail = await callTool('get_candidate', { contact_id: mblId });
  const timeline = detail.timeline || [];
  return { candidate: detail.candidate || null, timeline, notes: timelineNotes(timeline), previousApplications: await previousApplications(mblId, email, phone) };
}
async function previousApplications(currentId, email, phone) {
  // search_candidates can return broad/fuzzy results. Never trust the search hit alone for
  // previous-application identity: fetch each candidate and require an exact phone or email match.
  const emailKey = v => String(v || '').trim().toLowerCase();
  const phoneKey = v => {
    let d = String(v || '').replace(/\D/g, '');
    if (d.startsWith('0044')) d = d.slice(4);
    else if (d.startsWith('44')) d = d.slice(2);
    else if (d.startsWith('0')) d = d.slice(1);
    return d.length >= 10 ? d.slice(-10) : d;
  };
  const wantedEmail = emailKey(email);
  const wantedPhone = phoneKey(phone);
  const candidateIds = new Set();
  for (const term of [email, normalizePhone(phone)].filter(Boolean)) {
    try {
      const r = await callTool('search_candidates', { text: term, view: 'all', depot: DEPOT, page: 1 });
      for (const c of r.candidates || []) if (c.id && c.id !== currentId) candidateIds.add(c.id);
    } catch {}
  }

  const out = [];
  for (const id of [...candidateIds]) {
    const d = await getCandidateSafe(id);
    const candidate = d?.candidate || null;
    if (!candidate) continue;
    const exactEmail = wantedEmail && emailKey(candidate.email) === wantedEmail;
    const exactPhone = wantedPhone && phoneKey(candidate.phone) === wantedPhone;
    if (!exactEmail && !exactPhone) continue;

    const timeline = d?.timeline || [];
    const notes = timelineNotes(timeline);
    const callStage = candidate.callStage || null;
    const stage = candidate.stage || null;
    const outcome = callStage || stage || 'Previous application';

    // Invitations contain generic phrases such as "driving licence" and "right to work", so
    // they must never be used as a failure reason. Prefer explicit outcome events, then genuine
    // recruiter notes containing a relevant licence/DBS/eligibility detail.
    const reverse = timeline.slice().reverse();
    const explicitOutcome = reverse.find(t => /not attend|no[- ]?show|not coming|declin|not meeting|failed|ineligible|not qualified|cancel|withdraw/i.test(`${t.title || ''} ${t.detail || ''}`));
    const relevantNote = reverse.find(t => {
      const noteish = String(t.kind || '').toLowerCase() === 'note' || /note/i.test(t.title || '');
      return noteish && /\b(?:IN10|DR10|SP\d{2}|CD\d{2}|DD\d{2}|DG\d{2}|LC\d{2}|MS\d{2}|TS\d{2})\b|licen[cs]e|driving record|points?|right to work|background|dbs/i.test(t.detail || '');
    });
    const explicit = explicitOutcome || relevantNote;
    let reason = explicit ? [explicit.title || explicit.kind || '', explicit.detail || ''].filter(Boolean).join(' · ') : '';
    if (!reason && callStage === 'not_attended') reason = 'Marked Not Attended / No Show on official MBL.';
    if (!reason && callStage === 'declined') reason = 'Marked Not Coming / Declined on official MBL.';
    if (!reason && (callStage === 'not_meeting_requirements' || stage === 'not_qualified')) reason = 'Marked as not meeting requirements on official MBL.';
    if (!reason && callStage === 'no_answer') reason = 'Previous application ended at No Answer.';

    out.push({ id, name:candidate.name || '', phone:candidate.phone || '', email:candidate.email || '', date:candidate.applied || '', outcome, stage, callStage, induction:candidate.induction || null, note:notes.slice(-2).join(' · ') || 'Previous MBL application found.', reason, notes, timeline:timeline.slice(-20).map(t => ({at:t.at || '', title:t.title || t.kind || 'Activity', detail:t.detail || ''})) });
    if (out.length >= 6) break;
  }
  return out;
}
async function officialOpenSessions(mblId) {
  return await callTool('list_open_sessions', { contact_id: mblId });
}

function conflictChanged(current, action) {
  if (action.force || !action.expected) return false;
  const exp = action.expected;
  // The call-board column is named `to_call`, while get_candidate reports the same untouched
  // candidate with callStage=null. Treat those as the same state so first-call actions do not
  // trigger a false conflict prompt.
  const normCallStage = v => (v === 'to_call' || v == null || v === '') ? null : v;
  // Always protect against another manager genuinely changing the call outcome while this record is open.
  if (Object.prototype.hasOwnProperty.call(exp, 'callStage') && normCallStage(current.callStage) !== normCallStage(exp.callStage)) return true;
  // Only induction-sensitive actions care if the official induction was changed elsewhere.
  // A simple No Answer / Declined action must not be blocked just because the provisional MBL
  // session time differs from Recruitment Hub's local working time.
  const inductionSensitive = new Set(['confirm','correct','attended','not_attended']);
  if (inductionSensitive.has(action.type) && Object.prototype.hasOwnProperty.call(exp, 'induction') && String(current.induction || '') !== String(exp.induction || '')) return true;
  return false;
}

function actionAlreadyApplied(current, action) {
  if (!current || !action || action.type === 'note') return false;
  const stage = current.callStage || null;
  const currentDate = datePart(current.induction || '');
  const currentTime = timePart(current.induction || '');
  const selectedDate = action.date ? toApiDate(action.date) : '';
  const selectedTime = action.time || '10:45';

  if (action.type === 'no_answer') return stage === 'no_answer';
  if (action.type === 'declined') return stage === 'declined';
  if (action.type === 'not_proceeding') return stage === 'not_hired';
  if (action.type === 'hired') return stage === 'hired';
  if (action.type === 'answered') return stage === 'answered';
  if (action.type === 'attended') return stage === 'attended';
  if (action.type === 'not_attended') return stage === 'not_attended';
  if (action.type === 'not_meeting_requirements') {
    return stage === 'not_meeting_requirements' || current.stage === 'not_qualified' || current.qualification === 'not_qualified';
  }
  if (action.type === 'confirm') {
    const dateOk = !selectedDate || currentDate === selectedDate;
    const timeOk = !selectedTime || currentTime === selectedTime;
    const isConfirmedNow = stage === 'confirmed' || stage === 'rescheduled';
    // If this queued confirm started when the candidate was not yet confirmed, but MBL
    // now shows them confirmed for the same date, the outcome has already been achieved
    // elsewhere. Clear the stale write rather than forcing an old time over the newer record.
    const expectedStage = action.expected?.callStage ?? null;
    const expectedWasConfirmed = expectedStage === 'confirmed' || expectedStage === 'rescheduled';
    if (dateOk && isConfirmedNow && !expectedWasConfirmed) return true;
    return dateOk && timeOk && isConfirmedNow;
  }
  if (action.type === 'correct') {
    if (action.targetStatus === 'confirmed' && action.date) {
      const dateOk = !selectedDate || currentDate === selectedDate;
      const timeOk = !selectedTime || currentTime === selectedTime;
      return dateOk && timeOk && (stage === 'confirmed' || stage === 'rescheduled');
    }
    const stageMap = {
      to_call: null,
      spoke_to: 'answered',
      no_answer: 'no_answer',
      archived: 'no_answer',
      not_interested: 'declined',
      attended: 'attended',
      no_show: 'not_attended'
    };
    if (Object.prototype.hasOwnProperty.call(stageMap, action.targetStatus)) {
      const wanted = stageMap[action.targetStatus];
      return wanted == null ? (stage == null || stage === 'to_call') : stage === wanted;
    }
  }
  return false;
}

async function performAction(action) {
  if (!action?.mblId) throw new Error('No official MBL candidate ID is linked to this record.');
  const beforeWrap = await callTool('get_candidate', { contact_id: action.mblId });
  const before = beforeWrap.candidate || {};
  // Pending writes can be retried after a refresh or app restart. If the official record
  // already reflects the requested outcome, treat the write as complete instead of
  // repeating it (important for No Answer because repeating it increments attempts).
  if (actionAlreadyApplied(before, action)) return { conflict: false, verified: beforeWrap, alreadyApplied: true };
  if (action.type !== 'note' && conflictChanged(before, action)) {
    return { conflict: true, current: before, message: 'This candidate changed on MBL since your last refresh.' };
  }
  const note = action.note || '';
  if (action.type === 'note') {
    await callTool('add_note', { contact_id: action.mblId, note });
  } else if (action.type === 'no_answer') {
    // set_call_stage already records the call-board outcome and increments the official attempt count.
    // Do not also call log_call here or one real phone call is counted twice.
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'no_answer' });
  } else if (action.type === 'declined') {
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'declined' });
  } else if (action.type === 'answered') {
    // Local "Will Let Us Know" maps to the official MBL Spoke To / answered column.
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'answered' });
    if (note) { try { await callTool('add_note', { contact_id: action.mblId, note }); } catch {} }
  } else if (action.type === 'confirm') {
    const selectedApiDate = toApiDate(action.date);
    const currentDate = datePart(before.induction || '');
    const currentTime = timePart(before.induction || '');
    const selectedTime = action.time || '10:45';
    const needsMove = !!selectedApiDate && (selectedApiDate !== currentDate || (!!selectedTime && selectedTime !== currentTime));
    if (needsMove) {
      if (action.sessionId && selectedApiDate !== currentDate) await callTool('reschedule_candidate', { contact_id: action.mblId, session_id: action.sessionId, ...(note ? { note } : {}) });
      else await callTool('reschedule_candidate', { contact_id: action.mblId, date: selectedApiDate, time: selectedTime, ...(note ? { note } : {}) });
    }
    // Choosing Confirmed in Recruitment Hub must finish in the official Confirmed column,
    // even when the candidate was already provisionally booked or the date/time was adjusted.
    // Do not swallow this write: if MBL rejects it the Hub must keep the sync pending.
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'confirmed' });
  } else if (action.type === 'correct') {
    if (note) { try { await callTool('add_note', { contact_id: action.mblId, note }); } catch {} }
    const target = action.targetStatus;
    if (target === 'confirmed' && action.date) {
      const selectedApiDate = toApiDate(action.date);
      if (action.sessionId) await callTool('reschedule_candidate', { contact_id: action.mblId, session_id: action.sessionId, ...(note ? { note } : {}) });
      else await callTool('reschedule_candidate', { contact_id: action.mblId, date: selectedApiDate, time: action.time || '10:45', ...(note ? { note } : {}) });
      await callTool('set_call_stage', { contact_id: action.mblId, stage: 'confirmed' });
    } else {
      const stageMap = { to_call:'to_call', spoke_to:'answered', no_answer:'no_answer', archived:'no_answer', not_interested:'declined', attended:'attended', no_show:'not_attended' };
      const stage = stageMap[target];
      if (stage) await callTool('set_call_stage', { contact_id: action.mblId, stage });
    }
  } else if (action.type === 'attended') {
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'attended' });
  } else if (action.type === 'not_attended') {
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'not_attended' });
  } else if (action.type === 'hired') {
    // Only a separately confirmed final pipeline decision may call this action.
    // The UI requires all manual steps and checks that the DA has started work.
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'hired' });
  } else if (action.type === 'not_proceeding') {
    // This is a post-induction outcome: they attended, then chose not to continue.
    // Official MBL represents that as Not Hired, not Not Coming/Declined (which is pre-induction).
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'not_hired' });
    // Add the explanatory note only after the stage change succeeds so a failed retry
    // cannot duplicate the same note over and over.
    if (note) { try { await callTool('add_note', { contact_id: action.mblId, note }); } catch {} }
  } else if (action.type === 'not_meeting_requirements') {
    const allowed = new Set(['experience','licence','right_to_work','documents','background_check','other']);
    const reason = allowed.has(action.reason) ? action.reason : 'other';
    const finalNote = note || (reason === 'other' ? 'Does not meet requirements' : '');
    if (note && reason !== 'other') { try { await callTool('add_note', { contact_id: action.mblId, note }); } catch {} }
    await callTool('set_call_stage', { contact_id: action.mblId, stage: 'not_meeting_requirements', reason, ...(reason === 'other' ? { note: finalNote } : {}) });
  } else {
    throw new Error(`Unknown sync action: ${action.type}`);
  }
  const verified = await callTool('get_candidate', { contact_id: action.mblId });
  if (action.type === 'hired' && verified?.candidate?.callStage !== 'hired') {
    throw new Error('Official MBL did not confirm Hired. The change remains pending and can be retried safely.');
  }
  if (action.type === 'not_proceeding' && verified?.candidate?.callStage !== 'not_hired') {
    throw new Error('Official MBL did not confirm Not Hired. The change remains pending and can be retried safely.');
  }
  if (action.type === 'confirm') {
    const stage = verified?.candidate?.callStage || null;
    if (stage !== 'confirmed' && stage !== 'rescheduled') {
      throw new Error('MBL did not retain the Confirmed call stage. The Hub will keep this change pending and retry safely.');
    }
  }
  // Attendance must be verified exactly like Hired. Previously an apparently
  // successful API response could cause the Hub to delete its queued write
  // even if official MBL still had the original Confirmed / Spoke To stage.
  if (action.type === 'attended' || action.type === 'not_attended' ||
      (action.type === 'correct' && ['attended','no_show'].includes(action.targetStatus))) {
    const wanted=action.type==='not_attended'||action.targetStatus==='no_show'
      ?'not_attended':'attended';
    const actual=verified?.candidate?.callStage || null;
    if(actual!==wanted) {
      throw new Error('Official MBL did not confirm '+wanted+
        '. Still recorded as '+(actual||'unrecorded')+
        '. The Hub has kept your local attendance and will flag this for review.');
    }
  }
  return { conflict: false, verified };
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1480, height: 900, minWidth: 1050, minHeight: 700, show: false,
    backgroundColor: '#090b0d', autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.once('ready-to-show', () => { mainWindow.show(); if (process.argv.includes('--maximized')) mainWindow.maximize(); });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

app.setName('MBL Recruitment Hub');
app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  startBridgeServer();
  startSupportServer();
  createWindow();
  await checkConnection();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });


ipcMain.handle('support:push',(_e,payload)=>{try{const data=acceptSupportSnapshot(payload);return {ok:true,url:`http://127.0.0.1:${SUPPORT_PORT}/`,stored:data.candidates.length,server:supportServerState}}catch(e){return {ok:false,error:e.message}}});
ipcMain.handle('support:url',()=>({ok:true,url:`http://127.0.0.1:${SUPPORT_PORT}/`,server:supportServerState}));
ipcMain.handle('bridge:snapshot',()=>({ok:true,data:readBridgeData(),server:bridgeServerState,port:BRIDGE_PORT}));
ipcMain.handle('bridge:openFolder',async()=>{try{const dir=path.join(__dirname,'bridge-extension');const err=await shell.openPath(dir);return err?{ok:false,error:err}:{ok:true,path:dir}}catch(e){return {ok:false,error:e.message}}});
ipcMain.handle('bridge:clear',(_e,source)=>{const d=readBridgeData();if(source==='contracts'){d.contracts=[];d.contractSync=null}else if(source==='onboarding'){d.onboarding=[];d.onboardingSync=null}else return {ok:false,error:'Unknown bridge source'};saveBridgeData(d);try{mainWindow?.webContents.send('bridge:data',d)}catch{};return {ok:true,data:d}});
ipcMain.handle('mbl:status', async () => await checkConnection());
ipcMain.handle('mbl:connect', async () => {
  try { const c = await interactiveConnect(); return { ok: true, connection: c }; }
  catch (e) { connection = { ok: false, state: 'signin', message: e.message, at: new Date().toISOString() }; return { ok: false, error: e.message, connection }; }
});
ipcMain.handle('mbl:disconnect', async () => { clearTokensKeepClient(); connection = { ok: false, state: 'signin', message: 'Sign in required', at: new Date().toISOString() }; return { ok: true }; });
ipcMain.handle('mbl:refresh', async (_e, knownIds = []) => {
  try { await checkConnection(); if (!connection.ok) throw new Error(connection.message || 'MBL is not connected.'); return { ok: true, data: await buildSnapshot(knownIds) }; }
  catch (e) { connection = { ok: false, state: /sign in|required|expired/i.test(e.message) ? 'signin' : 'offline', message: e.message, at: new Date().toISOString() }; return { ok: false, error: e.message, connection }; }
});
ipcMain.handle('mbl:action', async (_e, action) => {
  try { return { ok: true, data: await performAction(action) }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('mbl:details', async (_e, args) => {
  try { return { ok: true, data: await candidateDetails(args.mblId, args.email, args.phone) }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('mbl:openSessions', async (_e, mblId) => {
  try { return { ok: true, data: await officialOpenSessions(mblId) }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('shell:open', async (_e, url) => { try { await shell.openExternal(url); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; } });
ipcMain.handle('app:version', () => ({ version: APP_VERSION }));
ipcMain.handle('ui:setScale', (_e, factor) => {
  const n = Number(factor);
  const safe = Math.max(0.8, Math.min(2.0, Number.isFinite(n) ? n : 1.25));
  try {
    mainWindow?.webContents.setZoomFactor(safe);
    return { ok: true, factor: safe };
  } catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('app:notify', (_e, title, body) => { try { new Notification({ title, body, icon: path.join(__dirname, 'assets', 'icon.png') }).show(); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; } });
ipcMain.handle('timer:set', (_e, mins, label = 'Recruitment timer') => {
  const minutes = Math.max(1, Math.min(720, Number(mins) || 1));
  const id = `timer-${Date.now()}`; const dueAt = Date.now() + minutes * 60000;
  const handle = setTimeout(() => {
    timers.delete(id);
    try { new Notification({ title: 'MBL Recruitment Hub', body: `${label} finished.` }).show(); } catch {}
    try { mainWindow?.webContents.send('timer:fired', { id, label, dueAt }); } catch {}
  }, minutes * 60000);
  timers.set(id, { handle, label, dueAt });
  return { ok: true, id, label, dueAt };
});
ipcMain.handle('timer:cancel', (_e, id) => {
  const t = timers.get(id); if (t) clearTimeout(t.handle); timers.delete(id); return { ok: true };
});
ipcMain.handle('app:checkUpdate', async () => {
  try {
    const manifest = await fetchUpdateManifest();
    return { ok: true, currentVersion: APP_VERSION, available: compareVersions(manifest.version, APP_VERSION) > 0, manifest };
  } catch (e) {
    return { ok: false, currentVersion: APP_VERSION, error: e.message };
  }
});

ipcMain.handle('app:installOnlineUpdate', async (_e, manifestFromRenderer) => {
  try {
    const fresh = await fetchUpdateManifest();
    const manifest = fresh && fresh.version === manifestFromRenderer?.version ? fresh : fresh;
    if (compareVersions(manifest.version, APP_VERSION) <= 0) return { ok: false, error: 'You already have the latest Recruitment Hub version.' };
    const res = await fetch(manifest.packageUrl, { cache: 'no-store', headers: { 'User-Agent': 'MBL-Recruitment-Hub' } });
    if (!res.ok) throw new Error(`Could not download update package (HTTP ${res.status}).`);
    let bytes;
    if (String(manifest.encoding || '').toLowerCase() === 'base64') {
      const b64 = (await res.text()).replace(/\s+/g, '');
      bytes = Buffer.from(b64, 'base64');
    } else {
      bytes = Buffer.from(await res.arrayBuffer());
    }
    const got = crypto.createHash('sha256').update(bytes).digest('hex');
    if (got.toLowerCase() !== String(manifest.sha256).toLowerCase()) throw new Error('Update package verification failed.');
    const zip = path.join(app.getPath('temp'), `MBL_Recruitment_Hub_Update_${manifest.version}.zip`);
    fs.writeFileSync(zip, bytes);
    return await applyUpdateZip(zip, manifest.version);
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('app:installUpdate', async () => {
  const pick = await dialog.showOpenDialog(mainWindow, {
    title: 'Select MBL Recruitment Hub update package',
    properties: ['openFile'],
    filters: [{ name: 'Recruitment Hub Update', extensions: ['zip'] }]
  });
  if (pick.canceled || !pick.filePaths[0]) return { ok: false, canceled: true };
  return await applyUpdateZip(pick.filePaths[0]);
});


/* v1.1.56 — offline PC-to-laptop transfer. These handlers never contact
   official MBL, and deliberately exclude authentication and sync queues from
   the exported file. Backups remain in the local Windows app-data directory. */
const TRANSFER_FORMAT='mbl-hub-pipeline-transfer';
function validTransferEnvelope(v){
  return !!v&&typeof v==='object'&&!Array.isArray(v)&&
    v.format===TRANSFER_FORMAT&&v.version===1&&
    Array.isArray(v.records)&&v.records.length<=10000;
}
ipcMain.handle('app:savePipelineTransfer',async(_e,payload)=>{
  try{
    if(!validTransferEnvelope(payload))throw Error('Invalid Pipeline transfer data');
    const content=JSON.stringify(payload,null,2);
    if(Buffer.byteLength(content,'utf8')>10*1024*1024)throw Error('Pipeline transfer is too large');
    const date=new Date().toISOString().replace(/[:.]/g,'-');
    const result=await dialog.showSaveDialog(mainWindow,{
      title:'Save Pipeline progress from this PC',
      defaultPath:path.join(app.getPath('downloads'),'MBL_Hub_Pipeline_Transfer_'+date+'.json'),
      filters:[{name:'Pipeline transfer JSON',extensions:['json']}]
    });
    if(result.canceled||!result.filePath)return {ok:false,canceled:true};
    fs.writeFileSync(result.filePath,content,{encoding:'utf8',mode:0o600});
    return {ok:true,path:result.filePath,count:payload.records.length};
  }catch(e){return {ok:false,error:e.message};}
});
ipcMain.handle('app:readPipelineTransfer',async()=>{
  try{
    const result=await dialog.showOpenDialog(mainWindow,{
      title:'Select Pipeline progress exported from your PC',
      properties:['openFile'],filters:[{name:'Pipeline transfer JSON',extensions:['json']}]
    });
    if(result.canceled||!result.filePaths?.[0])return {ok:false,canceled:true};
    const filename=result.filePaths[0];
    const stat=fs.statSync(filename);
    if(stat.size>10*1024*1024)throw Error('Pipeline transfer file is too large');
    const payload=JSON.parse(fs.readFileSync(filename,'utf8'));
    if(!validTransferEnvelope(payload))throw Error('Not a valid MBL Hub Pipeline transfer file. Choose the JSON exported from the PC, not a Hub update ZIP.');
    return {ok:true,filename,payload};
  }catch(e){return {ok:false,error:e.message};}
});
ipcMain.handle('app:backupPipelineBeforeImport',async(_e,localSnapshot)=>{
  try{
    if(!localSnapshot||typeof localSnapshot!=='object'||
      !Array.isArray(localSnapshot.candidates))throw Error('Invalid local Hub state');
    const body=JSON.stringify({backupType:'MBL Hub pre-Pipeline-import backup',
      createdAt:new Date().toISOString(),state:localSnapshot},null,2);
    if(Buffer.byteLength(body,'utf8')>30*1024*1024)throw Error('Local backup is too large');
    const folder=path.join(app.getPath('userData'),'pipeline-transfer-backups');
    fs.mkdirSync(folder,{recursive:true});
    const filename=path.join(folder,'before-pipeline-import-'+
      new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomBytes(3).toString('hex')+'.json');
    fs.writeFileSync(filename,body,{encoding:'utf8',mode:0o600,flag:'wx'});
    return {ok:true,path:filename};
  }catch(e){return {ok:false,error:e.message};}
});
