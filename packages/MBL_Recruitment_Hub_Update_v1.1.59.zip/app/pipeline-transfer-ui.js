/* MBL Hub v1.1.56 — one-time private Windows PC / laptop transfer UI.
   This is an offline file transfer, not automatic cloud synchronisation. */
(function(){
  'use strict';
  const core=window.hubPipelineTransferV1156;
  if(!core)return;
  let busy=false;
  const oldSettings=renderSettings;
  function addPanel(root){
    const card=root?.querySelector('.card');if(!card)return;
    const section=document.createElement('section');
    section.className='pipeline-transfer-panel-v1156';
    const eligible=(state.candidates||[]).filter(c=>
      c.proceeding===true||!!c.pipeline||
      ['contract_pending','contract_quiet','contract_signed','hired'].includes(c.status)).length;
    section.innerHTML=
      '<h3>PC ↔ Laptop · Pipeline transfer</h3>'+
      '<p><b>Pipeline steps are saved on each Windows device.</b> Updating the app or signing into MBL does not bring the local checklist from another PC.</p>'+
      '<p class="pipeline-transfer-note-v1156"><strong>1.</strong> On the PC with your completed Pipelines, choose <b>Export from this PC</b>.'+
      ' Move the private JSON file securely onto your laptop. <strong>2.</strong> On the laptop, choose <b>Import from PC</b>.'+
      ' It matches candidates by official MBL ID, restores checklist steps and stopwatch start times, and backs up the laptop before making changes.</p>'+
      '<div class="pipeline-transfer-buttons-v1156">'+
      '<button class="cta red" onclick="exportPipelinesV1156()">↗ Export from this PC</button>'+
      '<button class="cta" onclick="importPipelinesV1156()">↙ Import from PC</button>'+
      '</div>'+
      '<p class="pipeline-transfer-note-v1156">This device currently has <b>'+eligible+
      '</b> candidate(s) with local Pipeline data. <b>One-time transfer, not live device sync.</b>'+
      ' The export contains candidate names and contact details; keep it private and delete the transfer file once you have verified the laptop.</p>';
    const updates=[...card.querySelectorAll('h3')].find(h=>h.textContent.trim()==='App Updates');
    if(updates)card.insertBefore(section,updates);
    else card.appendChild(section);
  }
  renderSettings=function(el){
    oldSettings(el);
    addPanel(el);
  };
  window.exportPipelinesV1156=async function(){
    if(busy)return;busy=true;
    try{
      const payload=core.make(state.candidates);
      if(!payload.records.length){alert('There are no recorded Pipelines on this device to export. Open the Hub on your main PC and export there.');return;}
      const result=await window.mbl.savePipelineTransfer(payload);
      if(result?.canceled)return;
      if(!result?.ok){alert('Could not save Pipeline transfer: '+(result?.error||'Unknown error'));return;}
      alert('Pipeline export saved.\n\n'+payload.records.length+
        ' candidate(s) exported.\n\n'+result.path+
        '\n\nMove this JSON file securely to your laptop. On the laptop, open Settings → PC ↔ Laptop · Pipeline transfer → Import from PC. Do not use Install package manually for this JSON.');
    }catch(e){alert('Pipeline export failed: '+e.message);}
    finally{busy=false;}
  };
  window.importPipelinesV1156=async function(){
    if(busy)return;busy=true;
    try{
      const opened=await window.mbl.readPipelineTransfer();
      if(opened?.canceled)return;
      if(!opened?.ok){alert('Could not open Pipeline transfer: '+(opened?.error||'Unknown error'));return;}
      const plan=core.plan(opened.payload,state.candidates);
      if(!plan.actions.length){
        alert('No Pipelines could be matched or added. Nothing has been changed.\n'+
          plan.skipped.slice(0,8).map(x=>x.name+': '+x.reason).join('\n'));
        return;
      }
      const skipped=plan.skipped.length
        ?'\n\nSkipped: '+plan.skipped.length+
         '\n'+plan.skipped.slice(0,6).map(x=>x.name+': '+x.reason).join('\n')
        :'';
      if(!confirm('Import this PC Pipeline transfer into this laptop?\n\n'+
        'Update '+plan.updates+' existing candidate(s)\n'+
        'Add '+plan.adds+' missing candidate(s) locally\n'+
        'Skipped '+plan.skipped.length+
        '\n\nPC Pipeline steps and timers will replace the laptop copies for matched candidates.'+
        '\nOfficial MBL stages, messages, candidate notes, existing attendance and pending official writes are NOT replaced.'+
        '\nAn automatic backup of this laptop is made BEFORE the import.'+
        skipped+'\n\nContinue?'))return;
      const original=JSON.stringify(state);
      if(original.length>30*1024*1024)throw Error('Local Hub state is too large to back up');
      const backup=await window.mbl.backupPipelineBeforeImport(JSON.parse(original));
      if(!backup?.ok)throw Error('Laptop backup failed, so nothing was imported: '+(backup?.error||'Unknown error'));
      const next=JSON.parse(original);
      const imported=core.apply(opened.payload,next.candidates,plan);
      // Only one atomic localStorage write; don't make the actual database
      // visible to the app until saving the merged copy succeeds.
      localStorage.setItem(STORAGE_KEY,JSON.stringify(next));
      state=next;
      try{renderNav();render();}catch(e){/* Saved data is still valid; a restart will show it. */}
      alert('Pipeline transfer complete!\n\n'+imported.updated+' existing candidates updated\n'+
        imported.added+' missing candidates added\n'+
        imported.skipped+' skipped.\n\nBackup saved at:\n'+backup.path+
        '\n\nOpen Pipeline to check the steps and timers. These devices are not yet continuously synced.');
    }catch(e){alert('Pipeline import was stopped: '+e.message+'\n\nNo official MBL data was changed.');}
    finally{busy=false;}
  };
})();
