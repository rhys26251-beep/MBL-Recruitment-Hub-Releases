(() => {
  const clean=v=>String(v||'').replace(/\s+/g,' ').trim();
  const lower=v=>clean(v).toLowerCase();
  const uniq=arr=>[...new Set(arr.filter(Boolean))];
  const now=()=>new Date().toISOString();
  let fullScanBusy=false;

  function parseSiteUpdated(v){
    const raw=clean(v),d=new Date();
    if(!raw)return '';
    if(/^Yesterday$/i.test(raw)){d.setDate(d.getDate()-1);return d.toISOString()}
    let m=raw.match(/^(\d{1,2}):(\d{2})(am|pm)?$/i);
    if(m){let h=Number(m[1]),min=Number(m[2]);if(m[3]){if(/^pm$/i.test(m[3])&&h<12)h+=12;if(/^am$/i.test(m[3])&&h===12)h=0}d.setHours(h,min,0,0);return d.toISOString()}
    m=raw.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})$/);
    if(m){let y=Number(m[3]);if(y<100)y+=2000;return new Date(y,Number(m[2])-1,Number(m[1]),12).toISOString()}
    const p=Date.parse(raw);return Number.isFinite(p)?new Date(p).toISOString():'';
  }

  function textOf(el){return clean(el?.innerText||el?.textContent||'')}
  function visible(el){
    if(!el)return false;
    try{const s=getComputedStyle(el);const r=el.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0}catch{return true}
  }
  function findExact(label){
    const target=lower(label),els=[...document.querySelectorAll('body *')];
    return els.find(el=>lower(el.childElementCount?'':textOf(el))===target)||els.find(el=>lower(textOf(el))===target)||null;
  }
  function looksGreen(el){
    if(!el)return false;
    const nodes=[el,...(el.querySelectorAll?.('svg,path,i,span')||[])];
    return nodes.some(n=>{
      try{
        const s=getComputedStyle(n),vals=[s.color,s.fill,s.stroke,s.backgroundColor].join(' ');
        const rgbs=[...vals.matchAll(/rgba?\((\d+),\s*(\d+),\s*(\d+)/g)];
        if(rgbs.some(m=>Number(m[2])>Number(m[1])*1.15&&Number(m[2])>Number(m[3])*1.05&&Number(m[2])>80))return true;
        return /green|success|complete|completed|check/.test(String(n.className?.baseVal||n.className||'').toLowerCase());
      }catch{return false}
    });
  }
  function taskContainer(el){
    if(!el)return null;
    let cur=el.parentElement,best=cur||el;
    for(let i=0;cur&&i<5;i++,cur=cur.parentElement){
      const t=textOf(cur);
      if(t.length<=300)best=cur;
      else break;
    }
    return best;
  }
  function taskState(label){
    const el=findExact(label);if(!el)return 'Unknown';
    const box=taskContainer(el)||el;
    const t=lower(textOf(box));
    if(/under processing|processing/.test(t))return 'Processing';
    if(/pending|waiting/.test(t))return 'Pending';
    if(/approved|completed|complete|passed/.test(t)&&!/incomplete|not complete/.test(t))return 'Complete';
    if(looksGreen(box))return 'Complete';
    return 'Incomplete';
  }
  function detailSubstate(label){
    const el=findExact(label);if(!el)return 'Unknown';
    const box=taskContainer(el)||el,t=textOf(box);
    if(/Approved/i.test(t))return 'Approved';
    if(/Under processing|Processing/i.test(t))return 'Processing';
    if(/Pending|Waiting/i.test(t))return 'Pending';
    return taskState(label);
  }

  function deriveNameFromDocument(title){
    const s=clean(title),slash=s.split('/').map(clean).filter(Boolean);
    if(slash.length>1)return slash[slash.length-1].replace(/\b(DHU\d|DNG\d|DWN\d|DST\d|DXM\d|DPR\d)\b.*$/i,'').trim();
    const dash=s.split(/\s+-\s+/).map(clean).filter(Boolean);
    if(dash.length>1){const tail=dash[dash.length-1].replace(/\b(DHU\d|DNG\d|DWN\d|DST\d|DXM\d|DPR\d)\b.*$/i,'').trim();if(tail&&!/^D[A-Z0-9]+$/i.test(tail))return tail}
    return '';
  }

  function scanDropboxPayload(){
    const rows=[];
    for(const row of [...document.querySelectorAll('table tbody tr,[role="row"]')]){
      const txt=textOf(row);if(!/Pending signature|Signed/i.test(txt))continue;
      const cells=[...row.querySelectorAll('td,[role="cell"]')].map(textOf).filter(Boolean);
      const title=cells[0]||clean(txt.split(/Pending signature|Signed/i)[0]);
      if(!title||/^Name$/i.test(title))continue;
      const status=/Pending signature/i.test(txt)?'pending':'signed';
      const updatedDisplay=cells.find(c=>/^(Today|Yesterday|\d{1,2}:\d{2}(?:am|pm)?|\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}|\d{1,2}\s+[A-Za-z]{3})$/i.test(c))||cells[cells.length-1]||'';
      const href=row.querySelector('a[href]')?.href||'';
      rows.push({name:deriveNameFromDocument(title)||'',document:title,status,match:'unmatched',updated:now(),sourceUpdatedAt:parseSiteUpdated(updatedDisplay),updatedDisplay,href});
    }
    const unique=[],seen=new Set();
    for(const r of rows){const k=`${r.href||''}|${r.document}|${r.status}|${r.updatedDisplay}`;if(!seen.has(k)){seen.add(k);unique.push(r)}}
    if(!unique.length)return null;
    return {source:'contracts',bucket:'mixed',rows:unique,url:location.href,pageTitle:document.title,scannedAt:now()};
  }

  function associateContainer(anchor){
    let cur=anchor;
    for(let i=0;cur&&i<9;i++,cur=cur.parentElement){
      const t=textOf(cur);
      if(/\d+\s*\/\s*\d+\s*Completed/i.test(t))return cur;
    }
    return anchor.closest('tr,[role="row"]')||anchor.parentElement;
  }
  function extractAssociateName(anchor,box,providerId){
    const direct=clean(anchor.textContent||'');
    if(direct&&!/amzn1\.flex\.provider/i.test(direct)&&direct.length<100)return direct;
    const cells=[...(box?.querySelectorAll?.('td,[role="cell"]')||[])].map(textOf).filter(Boolean);
    if(cells.length){const first=cells.find(x=>x&&!/amzn1\.flex\.provider/i.test(x)&&!/\d+\s*\/\s*\d+\s*Completed/i.test(x));if(first)return first}
    const txt=textOf(box);if(providerId&&txt.includes(providerId))return clean(txt.split(providerId)[0]);
    return '';
  }
  function amazonListRows(){
    const byId=new Map(),detailUrls=[];
    const containers=[];
    document.querySelectorAll('table tbody tr,[role="row"],tbody tr').forEach(x=>containers.push(x));
    document.querySelectorAll('a[href*="/delivery-associates/detail/"]').forEach(a=>{
      const box=associateContainer(a)||a.closest('tr,[role="row"]')||a.parentElement;
      if(box)containers.push(box);
    });
    for(const box of containers){
      const txt=textOf(box);
      const pm=txt.match(/(\d+)\s*\/\s*(\d+)(?:\s*Completed)?/i);
      if(!pm)continue;
      const href=box.querySelector?.('a[href*="/delivery-associates/detail/"]')?.href||'';
      const providerId=(href||txt).match(/amzn1\.flex\.provider\.v1\.[A-Za-z0-9-]+/i)?.[0]||'';
      if(!providerId)continue;
      const anchor=box.querySelector?.('a[href*="/delivery-associates/detail/"]');
      const name=extractAssociateName(anchor||box,box,providerId);
      if(href)detailUrls.push(href);
      const done=Number(pm[1]),total=Number(pm[2]);
      const action=(total===15&&done===14)?'Send online training':(total===15&&done>=15)?'Onboarding complete':'Onboarding in progress';
      byId.set(providerId,{name,providerId,summary:`${done}/${total}`,detail:'',background:'',driverRecord:'',training:(total===15&&done===14)?'Needs sending':'',action,updated:now(),href});
    }
    return {rows:[...byId.values()],detailUrls:uniq(detailUrls)};
  }

  function amazonDetail(){
    if(!/\/delivery-associates\/detail\//i.test(location.pathname))return null;
    const body=textOf(document.body);
    const providerId=location.pathname.match(/amzn1\.flex\.provider\.v1\.[A-Za-z0-9-]+/i)?.[0]||body.match(/amzn1\.flex\.provider\.v1\.[A-Za-z0-9-]+/i)?.[0]||'';
    const pm=body.match(/(\d+)\s+of\s+(\d+)\s+Completed/i);
    const background=detailSubstate('Background Check');
    const driverRecord=taskState('Driver Record Verification');
    const training=taskState('Onboarding Training');
    let action='';
    if([background,driverRecord].some(x=>/Processing|Pending/i.test(x)))action='Waiting on checks';
    return {source:'onboarding',bucket:'detail',rows:[{name:'',providerId,summary:'',detail:pm?`${pm[1]} of ${pm[2]}`:'',background,driverRecord,training,action,updated:now(),href:location.href}],url:location.href,pageTitle:document.title,scannedAt:now()};
  }

  function scanAmazonPayload(){
    const detail=amazonDetail();if(detail)return detail;
    const {rows,detailUrls}=amazonListRows();if(!rows.length&&!detailUrls.length)return null;
    return {source:'onboarding',bucket:'summary',rows,detailUrls,url:location.href,pageTitle:document.title,scannedAt:now()};
  }
  function buildPayload(){
    const host=location.hostname.toLowerCase();
    if(host==='logistics.amazon.co.uk')return scanAmazonPayload();
    if(/hellosign|dropboxsign/.test(host))return scanDropboxPayload();
    return null;
  }
  function emit(payload){
    if(payload)chrome.runtime.sendMessage({type:'MBL_BRIDGE_DATA',payload}).catch?.(()=>{});
    return payload;
  }
  function scan(){return emit(buildPayload())}

  function pageFingerprint(){
    const rows=[...document.querySelectorAll('table tbody tr,[role="row"]')].slice(0,8).map(textOf).join('|');
    return `${location.href}|${rows}`;
  }
  function pagerSignature(el){
    const attrs=['aria-label','title','rel','id','class','data-testid','data-test','data-qa','name'].map(a=>el.getAttribute?.(a)||'').join(' ');
    return clean(`${textOf(el)} ${attrs} ${String(el.innerHTML||'').slice(0,500)}`).toLowerCase();
  }
  function isDisabled(el){return !!(el.disabled||el.getAttribute('aria-disabled')==='true'||/disabled/.test(String(el.className||'').toLowerCase()))}
  function pagerButton(direction){
    const all=[...document.querySelectorAll('button,a,[role="button"]')].filter(el=>visible(el)&&!isDisabled(el));
    const rx=direction==='next'?/(^|\b)(next|forward|nextpage|page-next|next-page)(\b|$)|chevron[-_ ]?right|arrow[-_ ]?right|caret[-_ ]?right|›|»|→/i:/(^|\b)(previous|prev|back|previouspage|page-prev|prev-page)(\b|$)|chevron[-_ ]?left|arrow[-_ ]?left|caret[-_ ]?left|‹|«|←/i;
    const semantic=all.find(el=>rx.test(pagerSignature(el)));if(semantic)return semantic;

    const navs=[...document.querySelectorAll('[class*="pagin"],[id*="pagin"],[aria-label*="pagin"],[data-testid*="pagin"],[role="navigation"]')].filter(visible);
    for(const nav of navs){
      const buttons=[...nav.querySelectorAll('button,a,[role="button"]')].filter(el=>visible(el)&&!isDisabled(el));
      if(buttons.length>=2){
        const nonNumeric=buttons.filter(el=>!/^\d+$/.test(textOf(el)));
        const pool=nonNumeric.length>=2?nonNumeric:buttons;
        return direction==='next'?pool[pool.length-1]:pool[0];
      }
    }
    return null;
  }
  async function clickPager(direction){
    const btn=pagerButton(direction);if(!btn)return false;
    const before=pageFingerprint();btn.click();
    const start=Date.now();
    while(Date.now()-start<12000){
      await new Promise(r=>setTimeout(r,300));
      if(pageFingerprint()!==before){await new Promise(r=>setTimeout(r,650));return true}
    }
    return false;
  }

  async function scanAllPages(){
    if(fullScanBusy)return {ok:false,error:'Full scan already running'};
    fullScanBusy=true;
    try{
      let guard=0;
      while(guard++<80&&pagerButton('prev')){if(!await clickPager('prev'))break}
      const combinedRows=[],combinedDetails=[];
      let pages=0,last='';
      while(pages<120){
        const fp=pageFingerprint();if(fp===last)break;last=fp;
        const p=buildPayload();pages++;
        if(p?.rows?.length)combinedRows.push(...p.rows);
        if(p?.detailUrls?.length)combinedDetails.push(...p.detailUrls);
        if(!pagerButton('next'))break;
        if(!await clickPager('next'))break;
      }
      if(combinedRows.length){
        const base=buildPayload()||{};
        const source=base.source||(/logistics\.amazon\.co\.uk/i.test(location.hostname)?'onboarding':'contracts');
        const dedup=new Map();
        for(const r of combinedRows){
          const key=source==='onboarding'?String(r.providerId||r.href||r.name):`${r.href||''}|${r.document||''}|${r.status||''}|${r.updatedDisplay||''}`;
          if(key)dedup.set(key,r);
        }
        const payload={source,bucket:source==='onboarding'?'summary':'mixed',rows:[...dedup.values()],detailUrls:uniq(combinedDetails),url:location.href,pageTitle:document.title,scannedAt:now()};
        await chrome.runtime.sendMessage({type:'MBL_BRIDGE_DATA',payload}).catch(()=>{});
        return {ok:true,pages,rows:payload.rows.length,details:payload.detailUrls.length};
      }
      return {ok:true,pages,rows:0,details:0};
    }finally{fullScanBusy=false}
  }

  chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
    if(msg?.type==='MBL_SCAN_NOW'){
      const payload=scan();sendResponse({ok:!!payload,source:payload?.source||null,rows:payload?.rows?.length||0});return;
    }
    if(msg?.type==='MBL_SCAN_ALL'){
      scanAllPages().then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message||String(e)}));return true;
    }
  });

  let timer=null;
  const schedule=()=>{clearTimeout(timer);timer=setTimeout(scan,900)};
  schedule();
  const observer=new MutationObserver(schedule);
  observer.observe(document.documentElement,{subtree:true,childList:true,attributes:false});
  setInterval(scan,60000);
})();
