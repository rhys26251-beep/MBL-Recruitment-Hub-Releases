/* Recruitment Hub v1.1.41 — PC/laptop workflow helpers. Clipboard only. */
(() => {
  'use strict';
  const emailSubject = 'MBL Logistics — Delivery Driver Application';
  const emailBody = [
    'Hi,',
    '',
    "It's Reece from MBL Logistics Recruitment. I tried to call you regarding your application for a delivery driver role but wasn't able to get through.",
    '',
    "If you're still interested, please reply to this email with a convenient time to speak and I'll be happy to discuss the next steps with you.",
    '',
    'Thanks,',
    'Reece',
    'MBL Logistics Recruitment'
  ].join('\n');

  function isEmail(value) {
    return /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(String(value || '').trim());
  }
  function newNode(tag,cls,textValue) {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    if (textValue !== undefined) el.textContent = textValue;
    return el;
  }
  function btn(textValue,fn,cls='smallbtn') {
    const el=newNode('button',cls,textValue);
    el.type='button';
    el.onclick=fn;
    return el;
  }
  function addText(parent,tag,cls,value) {
    const e=newNode(tag,cls,value);
    parent.appendChild(e);
    return e;
  }

  // The existing PC Hub removes candidates from the active queue once handled.
  // Preserve only their IDs so the final No Answer email list is session-specific.
  function rememberSession() {
    if (currentPage !== 'callmode' || !Array.isArray(state.callQueue) || !state.callQueue.length) return;
    state.callEmailBatch = {
      queueIds:[...new Set(state.callQueue)],
      beganAt:new Date().toISOString(),
      finishedAt:null
    };
    save();
  }
  const beforeStart=startCalling;
  startCalling=function(...args) {
    const r=beforeStart(...args);
    rememberSession();
    return r;
  };
  if (typeof window.startPreviousCallsV1131==='function') {
    const previous=window.startPreviousCallsV1131;
    window.startPreviousCallsV1131=function(...args){
      const r=previous(...args);
      rememberSession();
      return r;
    };
  }
  if (typeof window.startAllCallsV1131==='function') {
    const all=window.startAllCallsV1131;
    window.startAllCallsV1131=function(...args){
      const r=all(...args);
      rememberSession();
      return r;
    };
  }
  function sessionNoAnswers() {
    const ids=state.callEmailBatch?.queueIds || [];
    const candidates=ids.map(id=>state.candidates.find(c=>String(c.id)===String(id)))
      .filter(c=>c && c.status==='no_answer');
    const unique=new Set();
    const addresses=[];
    for(const c of candidates) {
      const address=String(c.email||'').trim();
      const key=address.toLowerCase();
      if(isEmail(address) && !unique.has(key)) {
        unique.add(key);
        addresses.push(address);
      }
    }
    return {candidates,addresses,bcc:addresses.join('; ')};
  }
  function copyAddresses() {
    const b=sessionNoAnswers();
    if(!b.addresses.length) return toast('No usable email addresses from this calling session');
    return copyText(b.bcc, 'Email addresses copied — paste into BCC');
  }

  function appendEmailSummary(host,showReturn) {
    host.replaceChildren();
    const batch=state.callEmailBatch;
    const data=sessionNoAnswers();
    const n=batch?.queueIds?.length || 0;
    const heading=newNode('div','pc-email-head');
    addText(heading,'h2','',showReturn?'✓ Calls complete — email follow-up':'📧 No Answer email follow-up');
    addText(heading,'p','',
      'Only candidates from your most recent Call Mode session who are still marked No Answer. '+
      'Paste addresses into BCC so recipients cannot see one another. Nothing is emailed automatically.');
    host.appendChild(heading);
    const stats=newNode('div','pc-email-stats');
    for(const [num,label] of [
      [n,'Started in this calling session'],
      [data.candidates.length,'Currently marked No Answer'],
      [data.addresses.length,'Usable email addresses'],
      [data.candidates.length-data.addresses.length,'Missing / invalid / duplicate emails']
    ]) {
      const tile=newNode('div','pc-email-stat');
      addText(tile,'b','',String(num));
      addText(tile,'span','',label);
      stats.appendChild(tile);
    }
    host.appendChild(stats);
    const people=newNode('div','pc-email-people');
    for(const c of data.candidates) {
      const row=newNode('div','pc-email-person');
      addText(row,'b','',c.name);
      addText(row,'span',isEmail(c.email)?'':'pc-email-missing',isEmail(c.email)?String(c.email).trim():'No usable email recorded');
      people.appendChild(row);
    }
    if(people.children.length) host.appendChild(people);
    else addText(host,'p','sub','No candidates in this session are currently marked No Answer.');

    function field(label,value,height,copyLabel,handler) {
      const wrap=newNode('div','pc-email-field');
      const top=newNode('div','pc-email-field-top');
      addText(top,'strong','',label);
      top.appendChild(btn(copyLabel,handler));
      wrap.appendChild(top);
      if(height){
        const textarea=newNode('textarea','pc-email-text');
        textarea.readOnly=true;
        textarea.value=value;
        textarea.rows=height;
        wrap.appendChild(textarea);
      }else{
        const input=newNode('input','pc-email-text');
        input.readOnly=true;
        input.value=value;
        wrap.appendChild(input);
      }
      host.appendChild(wrap);
    }
    field('1. Recipient addresses — BCC',data.bcc,3,'▣ Copy all emails ('+data.addresses.length+')',copyAddresses);
    field('2. Email subject',emailSubject,0,'▣ Copy subject',()=>copyText(emailSubject,'Email subject copied'));
    field('3. Generic follow-up email',emailBody,9,'▣ Copy message',()=>copyText(emailBody,'Email message copied'));
    if(showReturn){
      const actions=newNode('div','pc-email-actions');
      actions.appendChild(btn('Back to Call List',()=>go('calllist'),'cta red'));
      actions.appendChild(btn('Undo last call outcome',()=>undoLast()));
      host.appendChild(actions);
    }
  }

  const oldMode=renderCallMode;
  renderCallMode=function(el){
    oldMode(el);
    if(currentPage!=='callmode' || !Array.isArray(state.callQueue) ||
       state.callQueue.length || !state.callEmailBatch?.queueIds?.length) return;
    if(!state.callEmailBatch.finishedAt){
      state.callEmailBatch.finishedAt=new Date().toISOString();
      save();
    }
    header('Calls complete','Copy addresses and an email for the No Answer candidates.');
    appendEmailSummary(el,true);
  };
  function openEmailSummary(){
    appendEmailSummary(document.getElementById('callEmailsBodyV1141'),false);
    openModal('callEmailsModalV1141');
  }
  const oldList=renderCallList;
  renderCallList=function(el){
    oldList(el);
    if(!state.callEmailBatch?.queueIds?.length) return;
    const toolbar=el.querySelector('.toolbar');
    if(toolbar) toolbar.appendChild(btn('📧 No Answer email summary',openEmailSummary,'act'));
  };
  window.openNoAnswerEmailSummaryV1141=openEmailSummary;

  // New people cannot be created through the current MBL connector. These
  // clipboard buttons simply mirror the official Add a Lead form.
  function isLocalManual(c){
    return !!(c && !c.mblId &&
      (c.localOnly || /manual|inbound/i.test(String(c.source||''))));
  }
  function fieldsFor(c) {
    const name=String(c.name||'').trim();
    const p=name.indexOf(' ');
    const first=(c.officialForm?.firstName || (p===-1?name:name.slice(0,p))).trim();
    const last=(c.officialForm?.lastName || (p===-1?'':name.slice(p+1))).trim();
    return [
      ['First name',first],
      ['Last name',last],
      ['Phone',String(c.phone||'').trim()],
      ['Email (optional)',String(c.email||'').trim()],
      ['Depot','Hull (HULL)'],
      ['Source','Added by hand'],
      ['Driving experience',c.officialForm?.drivingExperience || 'Not given'],
      ['Driving licence',c.officialForm?.drivingLicence || 'Not given']
    ];
  }
  window.openManualLeadCopyV1141=function(id){
    const c=state.candidates.find(x=>String(x.id)===String(id));
    if(!c)return toast('Candidate not found');
    if(!isLocalManual(c))return toast('This person is already linked to official MBL');
    document.getElementById('manualCopyTitleV1141').textContent='Copy to MBL — '+c.name;
    const root=document.getElementById('manualCopyBodyV1141');
    root.replaceChildren();
    const notice=newNode('div','pc-lead-help');
    addText(notice,'strong','',"Locally added candidate — not yet in official MBL.");
    addText(notice,'p','',"Copy each field into the official Add a lead form. Official MBL may then automatically book and invite the lead. Check for an existing record first to avoid duplicates.");
    root.appendChild(notice);
    const grid=newNode('div','pc-lead-grid');
    const fields=fieldsFor(c);
    for(const [label,value] of fields) {
      const tile=newNode('div','pc-lead-field');
      addText(tile,'label','',label);
      const line=newNode('div','pc-lead-line');
      addText(line,'span','',value||'Not provided');
      const button=btn('▣ Copy',()=>copyText(String(value),label+' copied'));
      button.disabled=!value;
      line.appendChild(button);
      tile.appendChild(line);
      grid.appendChild(tile);
    }
    root.appendChild(grid);
    const actions=newNode('div','pc-email-actions');
    actions.appendChild(btn('▣ Copy all details',()=>{
      const full=fields.map(([key,value])=>key+': '+(value||'Not provided')).join('\n');
      copyText(full,c.name+' details copied');
    },'cta red'));
    actions.appendChild(btn('Open official MBL',async()=>{
      const result=await window.mbl.openExternal('https://inductions.mbllogistics.cloud');
      if(result && !result.ok)toast(result.error||'Could not open official MBL');
    }));
    root.appendChild(actions);
    addText(root,'p','sub',"This tool only copies values. It does not create or confirm any official record. When you add someone on MBL, the Hub's normal refresh will try to match the phone/email.");
    openModal('manualCopyModalV1141');
  };

  const oldSaveCandidate=saveAddedCandidate;
  saveAddedCandidate=function(...args){
    const first=document.getElementById('addFirstName')?.value?.trim()||'';
    const last=document.getElementById('addSurname')?.value?.trim()||'';
    const existing=new Set(state.candidates.map(c=>String(c.id)));
    const result=oldSaveCandidate(...args);
    const added=state.candidates.find(c=>!existing.has(String(c.id))&&isLocalManual(c));
    if(added){
      added.officialForm={firstName:first,lastName:last,drivingExperience:'Not given',drivingLicence:'Not given'};
      save();
      window.openManualLeadCopyV1141(added.id);
    }
    return result;
  };
  const oldProfile=renderProfile;
  renderProfile=function(el){
    oldProfile(el);
    const c=state.candidates.find(x=>String(x.id)===String(profileId));
    if(!isLocalManual(c))return;
    const card=el.querySelector('.profile-grid .card');
    if(card && !card.querySelector('.pc-lead-profile-button'))
      card.appendChild(btn('▣ Copy details to official MBL',()=>window.openManualLeadCopyV1141(c.id),'pc-lead-profile-button'));
  };
  if(typeof window.openLocalLeadsPrompt==='function'){
    const originalPrompt=window.openLocalLeadsPrompt;
    window.openLocalLeadsPrompt=function(...args){
      const result=originalPrompt(...args);
      const rows=document.querySelectorAll('#localLeadsBody .local-lead-row');
      const locals=state.candidates.filter(isLocalManual);
      rows.forEach((row,i)=>{
        if(locals[i] && !row.querySelector('.pc-lead-list-copy'))
          row.appendChild(btn('▣ Copy to MBL',()=>window.openManualLeadCopyV1141(locals[i].id),'smallbtn pc-lead-list-copy'));
      });
      return result;
    };
  }

  function makeModal(id,title,bodyId,titleId){
    const wrap=newNode('div','modalwrap');
    wrap.id=id;
    const modal=newNode('div','modal pc-extras-modal');
    const head=newNode('div','modalhead');
    const h3=newNode('h3','',title);
    if(titleId)h3.id=titleId;
    head.appendChild(h3);
    head.appendChild(btn('×',()=>closeModal(id),'x'));
    modal.appendChild(head);
    const content=newNode('div');
    content.id=bodyId;
    modal.appendChild(content);
    wrap.appendChild(modal);
    document.body.appendChild(wrap);
  }
  makeModal('callEmailsModalV1141','No Answer email summary','callEmailsBodyV1141');
  makeModal('manualCopyModalV1141','Copy to official MBL','manualCopyBodyV1141','manualCopyTitleV1141');
})();
