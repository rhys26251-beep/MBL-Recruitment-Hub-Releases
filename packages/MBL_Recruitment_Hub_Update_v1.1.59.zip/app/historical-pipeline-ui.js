/* v1.1.57 — visible, explicit local Proceeding route for verified past
 * attendance. Official MBL sync errors remain visible and are not retried.
 */
(function(){
  'use strict';
  const helper=window.hubHistoricalPipelineV1157;
  if(!helper)return;
  function savedEvidence(c){
    const hasQueue=(state.syncQueue||[]).some(q=>
      q.candidateId===c.id&&q.action?.type==='attended'&&q.status!=='done');
    return helper.eligible(c,window.hubAttendanceAuditV1153,hasQueue);
  }
  function needsEntry(c){
    return !c.proceeding || !c.pipeline?.steps?.proceeded || !c.pipeline?.startedAt;
  }
  window.startSavedAttendeePipelineV1157=function(id){
    const c=state.candidates.find(x=>String(x.id)===String(id));
    if(!c)return toast('Candidate no longer available');
    const evidence=savedEvidence(c);
    if(!evidence)return toast('No saved Attended outcome found. Check historical attendance first.');
    if(['hired','not_hired','not_meeting_requirements'].includes(c.officialCallStage)||
       ['not_proceeding','requirements_failed','hired'].includes(c.status)||
       c.pipeline?.archivedAt||c.pipeline?.decision||c.pipeline?.pendingDecision){
      alert('This candidate has a final, rejected or Removed outcome. Review that decision first; Pipeline will not override it.');
      return;
    }
    if(c.proceeding===false){
      alert('This candidate is recorded as NOT PROCEEDING. Review or correct that outcome before starting the Pipeline.');
      return;
    }
    const warning='Local Hub attendance: '+evidence.date+'\\n'+
      'Official MBL: '+(c.officialCallStage||'unknown')+
      ' · booked '+(parseApiDate(c.officialInduction)||'unknown')+'\\n\\n'+
      'This updates ONLY your local Pipeline, not the official MBL record. '+
      'The attendance correction warning stays active. '+
      'Contract Sent stays UNCHECKED unless you had already recorded evidence it was sent.\\n\\n';
    if(!confirm('Start / repair '+c.name+' as YES — PROCEEDING?\\n\\n'+warning+
      'This starts local Pipeline tracking without retrying the blocked attendance update.'))return;
    let updated;
    try{
      updated=helper.start(c,evidence,new Date().toISOString());
    }catch(e){alert(e.message);return;}
    snapshot(c.id);
    Object.assign(c,updated);
    // We don't touch syncQueue, MBL booking or the existing error state.
    c.attendanceSync='review';
    save();
    toast(c.name+' added to your local Pipeline');
    if(window.pipelineWindowsUiV1142?.openCandidate){
      window.pipelineWindowsUiV1142.openCandidate(c.id);
    }else{
      go('pipeline');
    }
  };
  const previousRenderProfile=renderProfile;
  renderProfile=function(el){
    previousRenderProfile(el);
    const c=state.candidates.find(x=>String(x.id)===String(profileId));
    if(!c)return;
    const evidence=savedEvidence(c);
    if(!evidence)return;
    const card=el.querySelector('.profile-grid .card');
    if(!card)return;
    const wrap=document.createElement('div');
    wrap.className='historical-pipeline-entry-v1157';
    const title=document.createElement('strong');
    title.textContent='Historical induction · '+evidence.date;
    wrap.appendChild(title);
    const status=document.createElement('p');
    status.textContent='Attendance was recorded in this Hub. Official MBL still says '+
      (c.officialCallStage||'unknown')+' for '+
      (parseApiDate(c.officialInduction)||'another date')+
      '. The official correction remains outstanding.';
    wrap.appendChild(status);
    if(needsEntry(c)){
      const button=document.createElement('button');
      button.type='button';button.className='cta red';
      button.style.cssText='width:100%;margin-top:8px;padding:10px';
      button.textContent='✓ YES — Proceeding · Add to Pipeline';
      button.onclick=()=>window.startSavedAttendeePipelineV1157(c.id);
      wrap.appendChild(button);
      const hint=document.createElement('p');
      hint.textContent='Hub-only progress. Starts at Awaiting Contract; does NOT mark contract sent or change MBL.';
      wrap.appendChild(hint);
    }else{
      const button=document.createElement('button');
      button.type='button';button.className='cta';
      button.style.cssText='width:100%;margin-top:8px;padding:10px';
      button.textContent='▤ View existing Pipeline';
      button.onclick=()=>window.pipelineWindowsUiV1142?.openCandidate(c.id)||go('pipeline');
      wrap.appendChild(button);
    }
    card.appendChild(wrap);
  };
})();
