/* v1.1.57 — safely start local Pipeline for recorded historical attendance.
 * No network calls. Never changes or acknowledges an official MBL status.
 */
(function(root){
  'use strict';
  const fmt=/^\d{2}\/\d{2}\/\d{4}$/;
  const validDate=s=>{
    if(typeof s!=='string'||!fmt.test(s))return false;
    const [dd,mm,yyyy]=s.split('/').map(Number);
    const d=new Date(yyyy,mm-1,dd);
    return d.getFullYear()===yyyy&&d.getMonth()===mm-1&&d.getDate()===dd;
  };
  function evidence(candidate,audit){
    if(!candidate)return null;
    const saved=audit?.saved(candidate);
    if(saved?.outcome==='attended'&&validDate(saved.date)){
      return {date:saved.date,source:saved.source||'Hub attendance record'};
    }
    // Old Hub builds could save historical attendance before the new
    // attendanceRecord property was introduced. Require an explicit YES
    // history event and a matching saved historical correction date.
    const old=candidate.historicalDateCorrection?.date;
    const titles=new Set(['Attended','Attended · historical check','Attended — Not Proceeding']);
    const attended=(candidate.history||[]).some(x=>
      titles.has(String(x?.[1]||'')) || (
        String(x?.[1]||'')==='Historical induction date corrected'&&
        (candidate.syncState==='failed'||candidate.attendanceSync==='review')
      ));
    if(validDate(old)&&attended&&candidate.attendanceSync==='review')
      return {date:old,source:'saved Hub historical attendance'};
    return null;
  }
  function eligible(candidate,audit,hasQueuedWrite=false){
    // Explicit NO is authoritative: never resurrect an older YES event.
    const current=audit?.saved(candidate);
    if(current?.outcome==='not_attended'||
       candidate?.attendanceRecord?.outcome==='not_attended')return null;
    const explicit=candidate?.attendanceRecord;
    if(explicit?.outcome==='attended'&&validDate(explicit.date))
      return {date:explicit.date,source:'saved attendance record'};
    // The pre-v1.1.53 historical UI could log the Yes decision on a
    // later date; the explicit corrected induction date takes priority.
    const old=candidate?.historicalDateCorrection?.date;
    const titles=['Attended','Attended · historical check','Attended — Not Proceeding'];
    if(validDate(old)&&hasQueuedWrite&&(candidate.history||[]).some(
      h=>titles.includes(String(h?.[1]||''))))
      return {date:old,source:'Hub history + pending MBL attendance write'};
    return evidence(candidate,audit);
  }
  function start(candidate,attendance,when=new Date().toISOString()){
    if(!candidate||!attendance||!validDate(attendance.date))
      throw Error('Verified Hub attendance is required before starting Pipeline');
    const c=JSON.parse(JSON.stringify(candidate));
    if(['not_hired','not_meeting_requirements','hired'].includes(c.officialCallStage)||
      ['hired','requirements_failed','not_proceeding'].includes(c.status)||
      c.pipeline?.archivedAt||c.pipeline?.decision||c.pipeline?.pendingDecision)
      throw Error('This candidate has a final or removed outcome; review it before changing their Pipeline');
    if(typeof c.proceeding==='boolean'&&!c.proceeding)
      throw Error('Existing Not Proceeding decision must be reviewed before changing it');
    if(c.attendanceRecord?.outcome==='not_attended')
      throw Error('The Hub records this candidate as absent; review that outcome first');
    c.proceeding=true;
    c.induction=attendance.date;
    c.lastInduction=attendance.date;
    c.attendanceRecord={...c.attendanceRecord,date:attendance.date,
      outcome:'attended',source:c.attendanceRecord?.source||'verified Hub history',
      recordedAt:c.attendanceRecord?.recordedAt||when};
    const p=c.pipeline&&typeof c.pipeline==='object'?c.pipeline:{};
    p.steps=p.steps&&typeof p.steps==='object'?p.steps:{};
    if(!p.startedAt)p.startedAt=when;
    if(!p.steps.proceeded)p.steps.proceeded=p.startedAt;
    // Preserve evidence of an already sent/signed contract; otherwise start
    // at Contract Sent with its own timer, and NEVER tick Contract Sent.
    const recordedContractSent=!!c.contractSentAt||!!c.contractSignedAt||
      p.steps.contract_sent===true||
      typeof p.steps.contract_sent==='string'&&!!p.steps.contract_sent;
    const recordedContractSigned=!!c.contractSignedAt||
      p.steps.contract_signed===true||
      typeof p.steps.contract_signed==='string'&&!!p.steps.contract_signed;
    if(!recordedContractSent&&!recordedContractSigned){
      c.status='attended';
      p.steps.contract_sent=false;
      c.docsSent=false;
    }else if(recordedContractSigned)c.status='contract_signed';
    else c.status='contract_pending';
    if(!p.ridealong||typeof p.ridealong!=='object')
      p.ridealong={days:2,day1:'',day2:''};
    if(!p.stepClocks||typeof p.stepClocks!=='object')p.stepClocks={};
    if(!p.stepClocksVersion){p.stepClocksVersion=1;}
    const next=recordedContractSigned?'onboarding_started':
      recordedContractSent?'contract_signed':'contract_sent';
    if(!p.stepClockActiveKey||!p.stepClocks[p.stepClockActiveKey]){
      p.stepClockActiveKey=next;
      if(!p.stepClocks[next])p.stepClocks[next]={startedAt:when};
      p.activeStageKey=next;
      p.stageEnteredAt=p.stepClocks[next].startedAt||when;
    }
    c.pipeline=p;
    c.history=Array.isArray(c.history)?c.history:[];
    c.history.push([when.slice(8,10)+'/'+when.slice(5,7)+' '+
      when.slice(11,16),'Proceeding · Pipeline started',
      'Attended induction '+attendance.date+
      '; recruiter confirmed proceeding in the local Hub. Contract sent NOT assumed. '+
      'Existing official MBL booking/attendance discrepancy remains for administrator review.']);
    return c;
  }
  root.hubHistoricalPipelineV1157={validDate,evidence,eligible,start};
})(typeof window==='object'?window:globalThis);
