param(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [Parameter(Mandatory=$true)][string]$AppDir,
  [Parameter(Mandatory=$true)][string]$ExePath,
  [Parameter(Mandatory=$true)][int]$ProcessId
)
$ErrorActionPreference='Stop'
$stage = Join-Path $env:TEMP ("MBLHubUpdate_" + [Guid]::NewGuid().ToString('N'))
$logDir = Join-Path $env:LOCALAPPDATA 'MBL Recruitment Hub'
$log = Join-Path $logDir 'update.log'
New-Item -ItemType Directory -Path $stage -Force | Out-Null
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
function Log([string]$m){ ("{0} {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$m) | Add-Content -Path $log -Encoding UTF8 }
try {
  Log "Starting update from $ZipPath"
  Expand-Archive -LiteralPath $ZipPath -DestinationPath $stage -Force
  $source = Join-Path $stage 'app'
  if (-not (Test-Path (Join-Path $source 'main.js')) -or -not (Test-Path (Join-Path $source 'index.html'))) {
    throw 'This is not a valid MBL Recruitment Hub update package.'
  }
  try { Wait-Process -Id $ProcessId -Timeout 60 -ErrorAction SilentlyContinue } catch {}
  Start-Sleep -Milliseconds 1200
  Copy-Item -Path (Join-Path $source '*') -Destination $AppDir -Recurse -Force
  Log 'Files copied successfully.'
  Start-Process -FilePath $ExePath
  Log 'Recruitment Hub restarted successfully.'
} catch {
  Log ("Update failed: " + $_.Exception.Message)
  $desktopLog = Join-Path ([Environment]::GetFolderPath('Desktop')) 'MBL Recruitment Hub Update Error.txt'
  ("Update failed: " + $_.Exception.Message + "`r`n`r`nLog: " + $log) | Set-Content -Path $desktopLog -Encoding UTF8
} finally {
  Start-Sleep -Seconds 1
  Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
}
