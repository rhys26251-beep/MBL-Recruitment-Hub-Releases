/* MBL Recruitment Hub v1.1.52 — restore Call Mode history and all candidate navigation. */
(() => {
  'use strict';
  const pipeline=window.hubPipelineV1142;
  if(!pipeline)return;
  const {STEPS}=pipeline;
  let expandedId=null;
  let currentFilter='all';
  try { currentFilter=window.sessionStorage?.getItem('mblPipelineSelectedFilter')||'all'; } catch (_) {}
  function chooseFilter(key){
    currentFilter=key;
    expandedId=null;
    resetSortedOrder();
    try { window.sessionStorage?.setItem('mblPipelineSelectedFilter',key); } catch (_) {}
    render();
  }
  let searchTerm='';
  let pendingFinalId=null;
  // Snapshot the ranked list when entering a view, so ticking a box doesn't
  // move a candidate away while the recruiter is working through the queue.
  let frozenOrder=null;

  const node=(tag,cls='',label)=>{
    const e=document.createElement(tag);
    if(cls)e.className=cls;
    if(label!==undefined)e.textContent=label;
    return e;
  };
  function button(text,fn,cls='smallbtn'){
    const e=node('button',cls,text);
    e.type='button';
    e.onclick=fn;
    return e;
  }
  function info(parent,tag,cls,text){
    const e=node(tag,cls,text);
    parent.appendChild(e);return e;
  }
  function nameSort(a,b){return String(a.name||'').localeCompare(String(b.name||''));}
  const stepCount=c=>pipeline.completed(c);
  const stepFraction=c=>stepCount(c)+'/'+STEPS.length;
  function stepStatus(c){
    const steps=stepFraction(c);
    if(c.pipeline?.archivedAt)return 'Removed · '+steps;
    if(c.pipeline?.alreadyHiredAt&&!pipeline.final(c))return 'MBL check needed · '+steps;
    if(c.pipeline?.decision==='not_hired')return 'Not Hired · '+steps;
    if(pipeline.final(c))return '✓ Hired · '+steps;
    return steps;
  }
  function rankBySteps(a,b){
    return stepCount(b)-stepCount(a)||nameSort(a,b)||
      String(a.id).localeCompare(String(b.id));
  }
  function resetSortedOrder(){frozenOrder=null;}
  function stableOrder(records){
    if(!frozenOrder){
      frozenOrder=new Map(
        [...state.candidates].sort(rankBySteps).map((c,index)=>[String(c.id),index]));
    }
    // A candidate added while this view is open goes at the bottom until
    // Re-sort is clicked, rather than pushing other candidates away.
    for(const c of records){
      const id=String(c.id);
      if(!frozenOrder.has(id))frozenOrder.set(id,frozenOrder.size);
    }
    return [...records].sort((a,b)=>frozenOrder.get(String(a.id))-frozenOrder.get(String(b.id)));
  }
  function allRecords(){return state.candidates.filter(pipeline.included);}
  function active(){return allRecords().filter(c=>!pipeline.final(c));}
  function finished(){return allRecords().filter(pipeline.final);}
  function actionCandidates(){return active().filter(c=>pipeline.nextAction(c).kind==='action');}
  function waitingCandidates(){return active().filter(c=>pipeline.nextAction(c).kind==='waiting');}
  function percentBar(c){
    const outer=node('div','simple-progress');
    const fill=node('div','simple-progress-fill');
    fill.style.width=Math.round(100*stepCount(c)/STEPS.length)+'%';
    outer.appendChild(fill);
    return outer;
  }
  // Show the step the recruiter is working towards, not the last ticked box.
  // Reuse nextAction so Waiting and official decision states are accurate.
  function currentStage(c){
    const a=pipeline.nextAction(c);
    if(c.pipeline?.archivedAt)return 'Removed from pipeline';
    if(c.pipeline?.pendingDecision)return 'Official MBL · awaiting hiring confirmation';
    if(c.pipeline?.alreadyHiredAt && !pipeline.final(c))return 'Official MBL · confirm Hired';
    if(pipeline.final(c))return c.pipeline?.decision==='not_hired'?'Not Hired':'Hired';
    switch(a.key){
      case 'proceeded':return 'Induction · proceeding decision';
      case 'contract_sent':return 'Contract · send to candidate';
      case 'contract_signed':return a.kind==='waiting'
        ?'Contract · awaiting signature':'Contract · check signature';
      case 'onboarding_started':return 'Cortex · start onboarding';
      case 'training_ready':return a.kind==='waiting'
        ?'Cortex · waiting for training access':'Cortex · check training readiness';
      case 'training_sent':return 'Online training · send login details';
      case 'training_reported':return 'Online training · awaiting completion';
      case 'training_verified':return a.kind==='waiting'
        ?'Online training · Cortex verification pending':'Online training · verify in Cortex';
      case 'ridealong_complete':return 'Ridealong · arrange / complete';
      case 'van_allocated':return 'Van allocation';
      case 'first_shift':return 'First working shift';
      case 'decision':return 'Final hiring decision';
      default:return a.text||'Recruitment in progress';
    }
  }
  function digitalDuration(ms){
    // An always-increasing digital stopwatch, including seconds.
    const seconds=Math.max(0,Math.floor(ms/1000));
    const days=Math.floor(seconds/86400);
    const rem=seconds%86400;
    const hh=String(Math.floor(rem/3600)).padStart(2,'0');
    const mm=String(Math.floor(rem%3600/60)).padStart(2,'0');
    const ss=String(rem%60).padStart(2,'0');
    return (days?days+'d ':'')+hh+':'+mm+':'+ss;
  }
  function limitLabel(hours){
    return hours%24===0?hours/24+'d':hours+'h';
  }
  function refreshDigital(el){
    const c=pipeline.get(el._candidateId);
    if(!c)return;
    const type=el._timerType;
    const t=pipeline.timer(c,type,Date.now(),el._stepKey);
    const value=t.known?(t.minimum?'≥':'')+digitalDuration(t.elapsedMs):'—';
    el.className='pipeline-digital pipeline-digital-'+t.tone+
      (t.running?' is-ticking':'')+(type==='step'?' pipeline-digital-step':'');
    const valueNode=el.querySelector('.pipeline-digital-value');
    if(valueNode)valueNode.textContent=value;
    if(!t.known){
      el.title=t.untracked?'This step finished before stopwatch tracking was enabled':
        t.notStarted?'This stopwatch starts automatically when this step becomes active':
        t.stopped?'The step is no longer active':
        'The pipeline start time was not recorded precisely; no time has been invented.';
    }else if(t.minimum){
      el.title='At least '+digitalDuration(t.elapsedMs)+
        ' since the earliest saved timestamp. The exact pipeline start time is not recorded.';
    }else{
      el.title=(type==='total'?'Overall pipeline':type==='stage'?'Current step':'Checklist step')+
        ' started '+new Date(t.startedAt).toLocaleString('en-GB')+
        '. Green under '+limitLabel(t.limits[0])+', orange from '+
        limitLabel(t.limits[0])+', red from '+limitLabel(t.limits[1])+'.';
    }
  }
  function digitalClock(c,type,stepId=null){
    const box=node('span','pipeline-digital');
    box._candidateId=String(c.id);
    box._timerType=type;
    box._stepKey=stepId;
    info(box,'span','pipeline-digital-label',
      type==='total'?'OVERALL':type==='stage'?'THIS STEP':'STEP TIME');
    info(box,'strong','pipeline-digital-value','00:00:00');
    refreshDigital(box);
    return box;
  }
  function progressCard(c,withAction){
    const card=node('div','pipeline-card');
    const press=button('',()=>{},'pipeline-summary');
    // Reassign real click handler; avoid an empty click surface.
    press.onclick=()=>{
      expandedId=expandedId===String(c.id)?null:String(c.id);
      render();
    };
    const row=node('div','pipeline-name-row');
    info(row,'b','',c.name);
    info(row,'span','pipeline-pct',stepStatus(c));
    press.appendChild(row);
    const statusRow=node('div','pipeline-progress-row');
    const left=node('div','pipeline-status-left');
    const compact=node('div','pipeline-progress-compact');
    compact.appendChild(percentBar(c));
    left.appendChild(compact);
    const stage=node('div','pipeline-current-stage');
    info(stage,'span','pipeline-stage-prefix','Current stage:');
    info(stage,'strong','pipeline-stage-name',currentStage(c));
    left.appendChild(stage);
    statusRow.appendChild(left);
    const clocks=node('div','pipeline-timers');
    clocks.appendChild(digitalClock(c,'stage'));
    clocks.appendChild(digitalClock(c,'total'));
    statusRow.appendChild(clocks);
    statusRow.appendChild(node('div','pipeline-time-spacer'));
    press.appendChild(statusRow);
    // The full next-action instructions stay in the expanded candidate view.
    if(withAction){
      info(press,'span','pipeline-mini-next',pipeline.nextAction(c).text);
    }
    const summaryRow=node('div','pipeline-card-summaryrow');
    summaryRow.appendChild(press);
    if(pipeline.nextAction(c).key==='contract_signed'&&!c.pipeline?.archivedAt){
      const quick=node('div','pipeline-inline-actions');
      quick.appendChild(button('▣ Copy name',()=>copyCandidateName(c.id),'pipeline-inline-copy'));
      quick.appendChild(button('↗ Dropbox',()=>openDropbox(c.id),'pipeline-inline-dropbox'));
      summaryRow.appendChild(quick);
    }
    card.appendChild(summaryRow);
    if(expandedId===String(c.id))renderExpanded(card,c);
    return card;
  }
  async function openCortex(id){
    // Reuse the Hub's existing Amazon/Cortex onboarding page.
    const c=pipeline.get(id);
    if(c?.name && typeof window.copyCandidateNameV1126==='function')
      await window.copyCandidateNameV1126(c.id);
    if(typeof window.openAmazonOnboardingV1125==='function')
      return window.openAmazonOnboardingV1125();
    toast('Cortex shortcut is unavailable');
  }
  async function copyCandidateName(id){
    const c=pipeline.get(id);
    if(!c)return;
    if(typeof window.copyCandidateNameV1126==='function'){
      await window.copyCandidateNameV1126(c.id);
    }else{
      try { await navigator.clipboard.writeText(c.name||'');toast('Candidate name copied'); }
      catch (_) { toast('Unable to copy candidate name'); }
    }
  }
  function openDropbox(id){
    return typeof window.openContractPortalV1125==='function'
      ?window.openContractPortalV1125(Number(id),'pending')
      :toast('Dropbox shortcut is unavailable');
  }
  function copyTraining(id){
    const c=pipeline.get(id);
    if(!c)return;
    if(typeof window.copyHomeTrainingPackV1138==='function'){
      window.copyHomeTrainingPackV1138();
      c.history=c.history||[];
      c.history.push([nowStamp(),'Training message copied','AmiGO instructions copied. Credentials sent separately. Not yet marked sent.']);
      save();
    }else toast('Training pack shortcut is unavailable');
  }
  function actionButtons(host,c,key){
    const actions=node('div','pipeline-action-buttons');
    if(key==='contract_signed'){
      actions.appendChild(button('▣ Copy candidate name',()=>copyCandidateName(c.id),'cta red'));
      actions.appendChild(button('↗ Open Dropbox',()=>openDropbox(c.id),'cta'));
      actions.appendChild(button('Checked — not signed',()=>{
        c.contractLastChecked=new Date().toISOString();
        c.history=c.history||[];
        c.history.push([nowStamp(),'Contract checked','Still waiting for signature']);
        save();render();
      }));
    }
    if(['onboarding_started','training_ready','training_verified'].includes(key))
      actions.appendChild(button('↗ Open Cortex',()=>openCortex(c.id),'cta'));
    if(key==='training_sent'){
      actions.appendChild(button('▣ Copy training pack',()=>copyTraining(c.id),'cta red'));
      actions.appendChild(button('↗ Open Cortex · get username',()=>openCortex(c.id)));
    }
    if(actions.children.length)host.appendChild(actions);
  }
  function renderRidealong(host,c){
    const r=c.pipeline?.ridealong||{days:2,day1:'',day2:''};
    const box=node('div','pipeline-ridealong');
    info(box,'strong','', 'Ridealong days (flexible)');
    const row=node('div','pipeline-ridealong-fields');
    const days=node('label','pipeline-field');
    info(days,'span','', 'Days required');
    const select=node('select','field');
    [[1,'1 day'],[2,'2 days']].forEach(([value,label])=>{
      const opt=node('option','',label);
      opt.value=String(value);select.appendChild(opt);
    });
    select.value=String(r.days||2);
    select.disabled=pipeline.final(c)||!!c.pipeline?.archivedAt;
    select.onchange=()=>pipeline.ridealong(c.id,'days',select.value);
    days.appendChild(select);
    row.appendChild(days);
    for(const [key,label] of [['day1','Day 1'],...(Number(r.days||2)===2?[['day2','Day 2']]:[])]){
      const field=node('label','pipeline-field');
      info(field,'span','',label+' date');
      const input=node('input','field');
      input.type='date';
      input.value=r[key]||'';
      input.disabled=pipeline.final(c)||!!c.pipeline?.archivedAt;
      input.onchange=()=>pipeline.ridealong(c.id,key,input.value);
      field.appendChild(input);
      row.appendChild(field);
    }
    box.appendChild(row);
    info(box,'p','pipeline-hint','Days can be on different dates. Choose 1 day if one was sufficient; otherwise record both.');
    host.appendChild(box);
  }
  function stepRow(c,s,ix){
    const checked=pipeline.done(c,s.id);
    const line=node('div','pipeline-step'+(checked?' is-done':''));
    const label=node('label','pipeline-check-label');
    const checkbox=node('input');
    checkbox.type='checkbox';
    checkbox.checked=checked;
    checkbox.disabled=s.id==='proceeded'||pipeline.final(c)||!!c.pipeline?.pendingDecision||
      !!c.pipeline?.archivedAt;
    checkbox.onchange=()=>{const ok=pipeline.tick(c.id,s.id,checkbox.checked);if(!ok)checkbox.checked=pipeline.done(c,s.id);};
    label.appendChild(checkbox);
    info(label,'span','',s.label);
    const main=node('div','pipeline-step-main');
    main.appendChild(label);
    const tracked=pipeline.timer(c,'step',Date.now(),s.id);
    // Newly activated steps tick; completed tracked steps remain frozen.
    // A legacy completed step has no trustworthy elapsed time.
    if(tracked.known||checked){
      main.appendChild(digitalClock(c,'step',s.id));
    }
    line.appendChild(main);
    if(checked){
      const date=c.pipeline?.steps?.[s.id] ||
        (s.id==='contract_sent'?c.contractSentAt:
        s.id==='contract_signed'?c.contractSignedAt:null);
      const parsed=typeof date==='string'?new Date(date):null;
      if(parsed && !Number.isNaN(parsed.getTime()))
        info(line,'time','pipeline-done-time',
          parsed.toLocaleDateString('en-GB',{day:'2-digit',month:'short'}));
    }
    if(s.id==='ridealong_complete')renderRidealong(line,c);
    return line;
  }
  function renderExpanded(card,c){
    const detail=node('div','pipeline-detail');
    if(c.pipeline?.archivedAt){
      const banner=node('div','pipeline-next waiting');
      info(banner,'span','pipeline-overline','REMOVED FROM PIPELINE');
      info(banner,'strong','','Reason: '+(c.pipeline.archiveReason||'No reason given'));
      info(banner,'p','pipeline-hint','Your completed steps and candidate history are still saved. Official MBL was not changed.');
      detail.appendChild(banner);
      const footer=node('div','pipeline-detail-footer');
      footer.appendChild(button('↶ Restore to pipeline',()=>{if(pipeline.restore(c.id)){
        currentFilter='all';expandedId=String(c.id);render();}},'cta'));
      footer.appendChild(button('Full candidate history',()=>openProfile(c.id)));
      detail.appendChild(footer);
      card.appendChild(detail);
      return;
    }
    const action=pipeline.nextAction(c);
    const nextBox=node('div','pipeline-next'+(action.kind==='waiting'?' waiting':''));
    info(nextBox,'span','pipeline-overline',action.kind==='finished'?'FINAL RESULT':
      action.kind==='waiting'?'WAITING':'YOUR NEXT ACTION');
    info(nextBox,'strong','',action.text);
    const expandedClocks=node('div','pipeline-expanded-clocks');
    expandedClocks.appendChild(digitalClock(c,'stage'));
    expandedClocks.appendChild(digitalClock(c,'total'));
    nextBox.appendChild(expandedClocks);
    actionButtons(nextBox,c,action.key);
    detail.appendChild(nextBox);
    const steps=node('div','pipeline-steps');
    STEPS.forEach((s,i)=>steps.appendChild(stepRow(c,s,i)));
    detail.appendChild(steps);
    const footer=node('div','pipeline-detail-footer');
    if(pipeline.completedAll(c) && !pipeline.final(c) && !c.pipeline?.pendingDecision){
      footer.appendChild(button('✓ All steps complete — Hired or Not Hired?',()=>openDecision(c.id),'cta red'));
    }
    if(c.pipeline?.pendingDecision){
      info(footer,'p','pipeline-pending','Official MBL update is pending. Check Settings → Official MBL Connection if it does not complete.');
      footer.appendChild(button('Review official sync',()=>go('settings')));
      footer.appendChild(button('Reset if sync was discarded',()=>pipeline.cancelPending(c.id)));
    }
    if(pipeline.final(c)){
      if(c.pipeline?.alreadyHiredAt){
        info(footer,'strong','pipeline-finished-result','✓ Already Hired');
        info(footer,'p','pipeline-hint',c.pipeline?.decision==='hired'
          ?'Official MBL has confirmed Hired. The older checklist steps were intentionally skipped.'
          :'Official Hired status detected. The older Hub-only marker is retained for history.');
      }else{
        if(c.status==='hired' && !c.pipeline?.decision)
          info(footer,'p','pipeline-hint','Imported official Hired record — earlier checklist steps may not have been recorded on this device.');
        info(footer,'strong','pipeline-finished-result',
          c.pipeline?.decision==='not_hired'?'Not Hired':'✓ Hired');
        if(c.pipeline?.reason)info(footer,'p','pipeline-hint','Reason: '+c.pipeline.reason);
      }
      if(c.status==='hired'||c.officialCallStage==='hired')
        info(footer,'span','pipeline-hint','Official MBL: Hired');
    }else if(!c.pipeline?.pendingDecision){
      if(c.pipeline?.alreadyHiredAt){
        info(footer,'p','pipeline-pending',
          'Previously marked Already Hired on this device only. Confirm below to update official MBL.');
      }
      const shortcuts=node('div','pipeline-shortcuts');
      shortcuts.appendChild(button(c.pipeline?.alreadyHiredAt
        ?'✓ Confirm Hired with MBL':'✓ Already Hired',async()=>{
        if(!c.mblId){toast('No official MBL candidate link. Link or refresh the candidate before marking Hired.');return;}
        if(!confirm('Mark '+c.name+' as HIRED on the OFFICIAL MBL list?\n\nThis skips the remaining checklist steps. The official record will be changed.'))return;
        if(!confirm('ARE YOU SURE?\n\nThis will submit HIRED to official MBL for '+c.name+'.\n\nSelect OK only if they are already working as a driver.'))return;
        const result=await pipeline.markAlreadyHired(c.id);
        if(result?.error){toast(result.error);return;}
        expandedId=String(c.id);
        currentFilter='finished';
        render();
        toast(c.name+' confirmed Hired on official MBL');
      },'smallbtn pipeline-hired-action'));
      if(c.pipeline?.alreadyHiredAt && !pipeline.final(c)){
        shortcuts.appendChild(button('Clear old local mark',()=>{
          if(confirm('Clear the local-only Already Hired marker for '+c.name+'?'))
            pipeline.undoAlreadyHired(c.id);
        }));
      }
      shortcuts.appendChild(button('Remove from Pipeline',()=>openArchive(c.id),'smallbtn pipeline-remove-action'));
      footer.appendChild(shortcuts);
    }
    footer.appendChild(button('Full candidate history',()=>openProfile(c.id),'smallbtn'));
    detail.appendChild(footer);
    card.appendChild(detail);
  }
  function candidatesForFilter(){
    let list=currentFilter==='archived'?pipeline.archived():
      currentFilter==='finished'?finished():active();
    if(currentFilter==='action')list=list.filter(c=>pipeline.nextAction(c).kind==='action');
    if(currentFilter==='waiting')list=list.filter(c=>pipeline.nextAction(c).kind==='waiting');
    if(currentFilter.startsWith('step:')){
      const stepKey=currentFilter.slice(5);
      list=list.filter(c=>pipeline.nextAction(c).key===stepKey);
    }
    // Keep an expanded candidate visible while marking a checklist item;
    // otherwise they vanish from a stage tab before the recruiter is finished.
    const term=searchTerm.toLowerCase().trim();
    if(!term&&(currentFilter==='action'||currentFilter==='waiting'||currentFilter.startsWith('step:'))&&expandedId){
      const editing=pipeline.get(expandedId);
      if(editing&&pipeline.included(editing)&&!pipeline.final(editing)&&
        !list.some(c=>String(c.id)===String(editing.id)))list.push(editing);
    }
    if(term){
      // Global search still includes applicants not yet marked Proceeding.
      list=(currentFilter==='archived'?pipeline.archived():
        state.candidates.filter(c=>!c.pipeline?.archivedAt)).filter(c=>
        (String(c.name||'')+' '+String(c.phone||'')+' '+String(c.email||'')).toLowerCase().includes(term));
    }
    return stableOrder(list);
  }
  function renderPipelineRows(host){
    host.replaceChildren();
    const people=candidatesForFilter();
    if(!people.length){
      const empty=node('div','pipeline-empty');
      info(empty,'strong','','Nothing to do here');
      info(empty,'p','','You are caught up in this view.');
      host.appendChild(empty);return;
    }
    for(const c of people){
      if(pipeline.included(c)||c.pipeline?.archivedAt)host.appendChild(progressCard(c,false));
      else{
        const box=node('div','pipeline-card');
        const b=button('',()=>{},'pipeline-summary');
        b.onclick=()=>openProfile(c.id);
        info(b,'b','',c.name);
        info(b,'span','pipeline-mini-next','Not yet in the pipeline · Open candidate profile');
        box.appendChild(b);
        host.appendChild(box);
      }
    }
  }
  function officialAttendanceWarning(root){
    const ids=new Set((state.attendanceIssues||[]).map(x=>x.mblId));
    for(const q of state.syncQueue||[]){
      if(q.status!=='review'&&q.status!=='failed')continue;
      if(['attended','not_attended'].includes(q.action?.type))ids.add(q.mblId);
    }
    if(!ids.size)return;
    const alert=node('div','pipeline-attendance-warning');
    const textBlock=node('div','pipeline-attendance-warning-message');
    info(textBlock,'strong','', '⚠ '+ids.size+' attendance result'+(ids.size===1?'':'s')+
      ' NOT confirmed on official MBL');
    info(textBlock,'span','',
      'Your saved YES/NO choices are preserved. MBL needs verification or an official booking correction. Do not mark anyone absent just to clear a warning.');
    alert.appendChild(textBlock);
    alert.appendChild(button('Review MBL attendance →',()=>window.openSyncPanel?.(),'cta red'));
    root.appendChild(alert);
  }
  function renderPipeline(el){
    header('Pipeline','Recruitment stages, actions and live step timers.');
    const root=node('div','pipeline-root pipeline-v1151');
    const head=node('div','pipeline-top');
    const t=node('div');
    info(t,'h2','', 'Recruitment Pipeline');
    info(t,'p','sub','Choose a stage to see only the people waiting there. Timers continue automatically.');
    head.appendChild(t);
    const search=node('input','pipeline-search');
    search.type='search';
    search.placeholder='Find any candidate...';
    search.value=searchTerm;
    search.setAttribute('aria-label','Search all candidates');
    search.oninput=()=>{searchTerm=search.value;renderPipelineRows(list);};
    head.appendChild(search);
    root.appendChild(head);
    officialAttendanceWarning(root);

    const stages=node('div','pipeline-stage-nav');
    stages.setAttribute('aria-label','Recruitment stages');
    const stageTabs=[
      ['all','All active'],
      ...STEPS.map(s=>['step:'+s.id,({
        proceeded:'Induction',contract_sent:'Contract sent',contract_signed:'Sign check',
        onboarding_started:'Onboarding',training_ready:'Training ready',
        training_sent:'Details sent',training_reported:'Training done',
        training_verified:'Verified',ridealong_complete:'Ridealong',
        van_allocated:'Van',first_shift:'First shift'
      })[s.id]||s.label]),
      ['step:decision','Decision'],['finished','Finished'],['archived','Removed']
    ];
    const activePeople=active();
    const stageCount=key=>key==='all'?activePeople.length:
      key==='finished'?finished().length:key==='archived'?pipeline.archived().length:
      activePeople.filter(c=>pipeline.nextAction(c).key===key.slice(5)).length;
    for(const [key,label] of stageTabs){
      const b=button('',()=>chooseFilter(key),
        'pipeline-stage-tab'+(currentFilter===key?' selected':''));
      info(b,'span','pipeline-stage-title',label);
      info(b,'b','pipeline-stage-count',String(stageCount(key)));
      b.title=key.startsWith('step:')?(STEPS.find(s=>s.id===key.slice(5))?.label||label):label;
      b.setAttribute('aria-pressed',String(currentFilter===key));
      stages.appendChild(b);
    }
    root.appendChild(stages);

    const layout=node('div','pipeline-workspace');
    const sidebar=node('aside','pipeline-analytics');
    info(sidebar,'div','pipeline-sidebar-title','OVERVIEW');
    const metrics=[
      [activePeople.length,'Active','all'],
      [actionCandidates().length,'Need attention','action'],
      [waitingCandidates().length,'Waiting','waiting'],
      [finished().length,'Finished','finished']
    ];
    for(const [count,label,key] of metrics){
      const box=button('',()=>chooseFilter(key),
        'pipeline-analytic-tile'+(currentFilter===key?' selected':''));
      info(box,'b','',String(count));
      info(box,'span','',label);
      sidebar.appendChild(box);
    }
    info(sidebar,'p','pipeline-sidebar-hint','Select a stage above or use the overview to find urgent work.');
    layout.appendChild(sidebar);

    const main=node('section','pipeline-main');
    const sorting=node('div','pipeline-sort-row');
    info(sorting,'span','pipeline-sort-hint',
      'Most steps complete first · Rows stay in place while you work');
    sorting.appendChild(button('↕ Re-sort',()=>{resetSortedOrder();render();},'pipeline-resort'));
    main.appendChild(sorting);
    const list=node('div','pipeline-list');
    renderPipelineRows(list);
    main.appendChild(list);
    layout.appendChild(main);
    root.appendChild(layout);
    info(root,'p','pipeline-storage-note',
      'Checklist and Removed records are stored on this Windows device only. Already Hired submits an official MBL update after two confirmations and waits for verification. Shared PC/laptop checklist syncing is not enabled yet.');
    el.replaceChildren(root);
  }

  function dashboard(el){
    header('Home','A short list of what needs doing next.');
    const root=node('div','pipeline-home');
    const heading=node('div','pipeline-home-heading');
    info(heading,'span','pipeline-overline','MBL · HULL RECRUITMENT');
    info(heading,'h2','', 'What needs doing?');
    info(heading,'p','sub','Open a candidate, check the next step, tick it and move on.');
    root.appendChild(heading);
    officialAttendanceWarning(root);
    const overview=node('div','pipeline-numbers');
    const callCount=state.candidates.filter(c=>c.status==='to_call').length;
    const values=[[actionCandidates().length,'Pipeline actions',()=>go('pipeline')],
      [waitingCandidates().length,'Waiting / checks',()=>{currentFilter='waiting';go('pipeline');}],
      [callCount,'Call List',()=>go('calllist')],
      [state.candidates.filter(c=>c.status==='confirmed'&&c.induction===todayDMY()).length,
        'Inductions today',()=>go('inductions')]];
    values.forEach(([count,title,fn])=>{
      const tile=button('',()=>{},'pipeline-metric pipeline-metric-action');
      tile.onclick=fn;
      info(tile,'b','',String(count));info(tile,'span','',title);overview.appendChild(tile);
    });
    root.appendChild(overview);
    const shortcuts=node('div','pipeline-quick-row');
    shortcuts.appendChild(button('☎ Call List',()=>go('calllist'),'cta red'));
    shortcuts.appendChild(button('♙ All Candidates',()=>go('candidates'),'cta'));
    shortcuts.appendChild(button('▤ Pipeline',()=>go('pipeline'),'cta'));
    shortcuts.appendChild(button('▣ Calendar',()=>go('inductions')));
    shortcuts.appendChild(button('▣ Copy Training Pack',()=>window.copyHomeTrainingPackV1138?.()));
    root.appendChild(shortcuts);
    const title=node('div','pipeline-section-heading');
    info(title,'h3','','Your next actions');
    title.appendChild(button('View all →',()=>{currentFilter='action';go('pipeline');}));
    root.appendChild(title);
    const priority=actionCandidates().sort((a,b)=>{
      const ad=pipeline.ageH(a.pipeline?.steps?.contract_sent||a.contractSentAt);
      const bd=pipeline.ageH(b.pipeline?.steps?.contract_sent||b.contractSentAt);
      return bd-ad||nameSort(a,b);
    }).slice(0,10);
    if(!priority.length){
      const no=node('div','pipeline-empty');
      info(no,'strong','','Nothing needs your attention right now');
      info(no,'p','','Waiting candidates are still saved in Pipeline.');
      root.appendChild(no);
    }else{
      const cards=node('div','pipeline-home-action-list');
      for(const c of priority){
        const card=button('',()=>{},'pipeline-home-action');
        card.onclick=()=>{expandedId=String(c.id);currentFilter='all';go('pipeline');};
        const person=node('div','pipeline-home-action-top');
        info(person,'b','',c.name);
        info(person,'span','',stepFraction(c));
        card.appendChild(person);
        info(card,'div','pipeline-mini-next',pipeline.nextAction(c).text);
        card.appendChild(percentBar(c));
        cards.appendChild(card);
      }
      root.appendChild(cards);
    }
    el.replaceChildren(root);
  }

  // A custom modal avoids Electron's unsupported native prompt() dialog.
  let pendingArchiveId=null;
  function archiveModal(){
    const wrap=node('div','modalwrap');
    wrap.id='pipelineArchiveModalV1143';
    const modal=node('div','modal pipeline-decision-modal');
    const top=node('div','modalhead');
    info(top,'h3','','Remove from pipeline');
    top.appendChild(button('×',()=>closeModal(wrap.id),'x'));
    modal.appendChild(top);
    const body=node('div');
    body.id='pipelineArchiveBodyV1143';
    modal.appendChild(body);
    wrap.appendChild(modal);
    document.body.appendChild(wrap);
    return body;
  }
  const archiveBody=archiveModal();
  function openArchive(id){
    const c=pipeline.get(id);
    if(!c||!pipeline.included(c)||pipeline.final(c)||c.pipeline?.pendingDecision)return;
    pendingArchiveId=String(c.id);
    archiveBody.replaceChildren();
    info(archiveBody,'strong','pipeline-final-name',c.name);
    info(archiveBody,'p','pipeline-hint',
      'Remove from your active pipeline without deleting documents, progress or history. This will not update official MBL.');
    const field=node('label','pipeline-archive-field');
    info(field,'span','','Reason (optional)');
    const select=node('select','field');
    for(const value of ['No longer interested','Unresponsive','Failed checks','Other / no reason']){
      const option=node('option','',value);option.value=value;select.appendChild(option);
    }
    const other=node('textarea','notearea');
    other.rows=2;other.placeholder='Optional details...';
    other.style.display='none';
    select.onchange=()=>{other.style.display=select.value==='Other / no reason'?'block':'none';};
    field.appendChild(select);
    field.appendChild(other);
    archiveBody.appendChild(field);
    const buttons=node('div','pipeline-final-buttons');
    buttons.appendChild(button('Cancel',()=>closeModal('pipelineArchiveModalV1143')));
    buttons.appendChild(button('Remove from pipeline',()=>{
      const target=pipeline.get(pendingArchiveId);
      if(!target)return;
      const reason=select.value==='Other / no reason'
        ?other.value.trim():select.value+(other.value.trim()?' — '+other.value.trim():'');
      if(pipeline.archive(target.id,reason)){
        closeModal('pipelineArchiveModalV1143');
        expandedId=null;
        render();
        toast(target.name+' removed from active pipeline. Restore from Removed.');
      }
    },'cta red'));
    archiveBody.appendChild(buttons);
    openModal('pipelineArchiveModalV1143');
  }

  function decisionModal(){
    const wrap=node('div','modalwrap');
    wrap.id='pipelineFinalModalV1142';
    const modal=node('div','modal pipeline-decision-modal');
    const top=node('div','modalhead');
    info(top,'h3','', 'Final hiring decision');
    top.appendChild(button('×',()=>closeModal(wrap.id),'x'));
    modal.appendChild(top);
    const body=node('div');body.id='pipelineDecisionBodyV1142';
    modal.appendChild(body);
    wrap.appendChild(modal);document.body.appendChild(wrap);
    return body;
  }
  const decisionBody=decisionModal();
  function openDecision(id){
    const c=pipeline.get(id);
    if(!c||!pipeline.completedAll(c)||pipeline.final(c))return;
    pendingFinalId=String(c.id);
    decisionBody.replaceChildren();
    info(decisionBody,'strong','pipeline-final-name',c.name);
    info(decisionBody,'p','pipeline-hint','Every checklist step is complete. Has this person actually been hired and started work?');
    const buttons=node('div','pipeline-final-buttons');
    buttons.appendChild(button('✓ Yes — Hired',()=>submitDecision('hired'),'cta red'));
    buttons.appendChild(button('✕ No — Not Hired',()=>showNotHiredReason()));
    decisionBody.appendChild(buttons);
    const reason=node('div','pipeline-no-reason');
    reason.id='pipelineNoReasonV1142';
    reason.style.display='none';
    info(reason,'label','', 'Why was this person not hired?');
    const input=node('textarea','notearea');
    input.id='pipelineHiringReasonV1142';
    input.placeholder='Enter the reason here...';
    input.rows=4;
    reason.appendChild(input);
    reason.appendChild(button('Save Not Hired with reason',()=>submitDecision('not_hired'),'cta red'));
    decisionBody.appendChild(reason);
    info(decisionBody,'p','pipeline-hint',
      'The official MBL call list will only update after you confirm. We verify that MBL accepted the result.');
    openModal('pipelineFinalModalV1142');
  }
  function showNotHiredReason(){
    const area=document.getElementById('pipelineNoReasonV1142');
    area.style.display='block';
    document.getElementById('pipelineHiringReasonV1142').focus();
  }
  async function submitDecision(choice){
    const id=pendingFinalId;
    if(!id)return;
    const reason=document.getElementById('pipelineHiringReasonV1142')?.value.trim()||'';
    if(choice==='not_hired'&&!reason){toast('Please enter a reason');return;}
    const c=pipeline.get(id);
    if(!c)return;
    if(!confirm(choice==='hired'
      ?'Mark '+c.name+' as Hired on the OFFICIAL MBL call list?'
      :'Mark '+c.name+' as Not Hired on OFFICIAL MBL with this reason?\n\n'+reason))return;
    closeModal('pipelineFinalModalV1142');
    const outcome=await pipeline.decide(id,choice,reason);
    if(outcome?.error){
      toast(outcome.error);
      return;
    }
    toast(c.name+' confirmed '+(choice==='hired'?'Hired':'Not Hired')+' on official MBL');
    expandedId=String(c.id);
    currentFilter='finished';
    go('pipeline');
  }
  window.openPipelineDecisionV1142=openDecision;

  // v1.1.52: Keep the original Call Mode layout with always-visible
  // Notes, History, previous applications and Recent Calls. The pipeline
  // redesign had hidden them inside a collapsed details section.
  const originalMode=renderCallMode;
  renderCallMode=function(el){
    originalMode(el);
    if(currentPage!=='callmode'||!el.querySelector('.call-layout'))return;
    const head=el.querySelector('.call-head');
    if(head&&!head.querySelector('.pipeline-call-mode-links')){
      const links=node('div','pipeline-call-mode-links');
      links.appendChild(button('← Call List',()=>go('calllist'),'smallbtn'));
      links.appendChild(button('All Candidates',()=>go('candidates'),'smallbtn'));
      head.appendChild(links);
    }
    const history=el.querySelector('.sidepanel .history');
    const panel=history?.closest('.panel');
    if(panel&&!panel.querySelector('.pipeline-history-profile-link')){
      const candidate=callCandidates()[state.callIndex];
      if(candidate)panel.appendChild(button('View full candidate history →',
        ()=>openProfile(candidate.id),'smallbtn pipeline-history-profile-link'));
    }
  };

  // Pipeline supplements, rather than removes, the original Call List,
  // Candidates database and Follow-ups categories.
  navItems.splice(0,navItems.length,
    ['home','⌂','Home'],['calllist','☎','Call List'],
    ['candidates','♙','Candidates'],['pipeline','▤','Pipeline'],
    ['inductions','▣','Calendar'],['followups','↻','Follow-ups']);
  const originalGo=go;
  go=function(page){
    if(page==='contracts'||page==='onboarding'||page==='onboardingtest')page='pipeline';
    if(page==='pipeline'&&currentPage!=='pipeline')resetSortedOrder();
    return originalGo(page);
  };
  const originalHome=renderHome;
  renderHome=function(el){dashboard(el);};
  const originalRender=render;
  render=function(){
    if(currentPage==='pipeline'){
      pipeline.reconcile();
      maintainContracts();
      return renderPipeline(document.getElementById('content'));
    }
    return originalRender();
  };
  // Profile is still available from Call Mode, search and candidate history.
  const originalProfile=renderProfile;
  renderProfile=function(el){
    originalProfile(el);
    const c=state.candidates.find(x=>String(x.id)===String(profileId));
    if(!c||!pipeline.included(c))return;
    const card=el.querySelector('.profile-grid .card');
    if(card){
      card.appendChild(button('▤ Open in Pipeline',()=>{
        expandedId=String(c.id);currentFilter='all';go('pipeline');
      },'cta red'));
    }
  };

  // Stopwatches update every second without rerendering cards, moving any
  // candidates, or interrupting an opened checkbox or date field.
  if(typeof setInterval==='function')setInterval(()=>{
    if(currentPage!=='pipeline'||typeof document.querySelectorAll!=='function')return;
    for(const clock of document.querySelectorAll('.pipeline-digital'))refreshDigital(clock);
  },1000);

  renderNav();
  if(currentPage==='home')render();
  window.pipelineWindowsUiV1142={show:()=>go('pipeline'),openCandidate:(id)=>{
    expandedId=String(id);currentFilter='all';go('pipeline');
  }};
})();
