/* v1.1.58 — Sign check contacts. No credentials or candidate data leave
 * the Hub until the user explicitly opens WhatsApp / Phone Link.
 * Opening a chat / copying text does NOT mark a reminder as sent.
 */
(function(root){
  'use strict';
  function firstName(name){
    const s=String(name||'').trim();
    return s?s.split(/\s+/)[0]:'';
  }
  function message(candidate){
    const who=firstName(candidate?.name);
    return 'Hello'+(who?' '+who:'')+',\n\n'+
      'You should have received your contract by email. If you are happy to sign it, '+
      'please let me know once you have signed it.\n\n'+
      'Thanks,\nReece\nMBL Logistics';
  }
  // WhatsApp expects an E.164 number without '+' in wa.me links.
  // A bare UK mobile beginning 07 or 7 is converted to country code 44.
  // An explicit '+' or 00 international prefix can work for other countries.
  function internationalNumber(raw){
    const input=String(raw||'').trim();
    if(!input||/[a-z]/i.test(input)||!/^\+?[\d\s().-]+$/.test(input))return '';
    let digits=input.replace(/\D/g,'');
    if(input.startsWith('+')){
      if(!/^\+[1-9]/.test(input))return '';
    }else if(digits.startsWith('00')){
      digits=digits.slice(2);
    }else if(/^07\d{9}$/.test(digits)){
      digits='44'+digits.slice(1);
    }else if(/^7\d{9}$/.test(digits)){
      digits='44'+digits;
    }else if(!/^44\d{10}$/.test(digits)){
      // Without an international marker, do not guess the country.
      return '';
    }
    if(!/^[1-9]\d{7,14}$/.test(digits))return '';
    // A UK number should be a mobile, not a premium/landline number.
    if(digits.startsWith('44')&&!/^447\d{9}$/.test(digits))return '';
    return digits;
  }
  function whatsappUrl(raw){
    const phone=internationalNumber(raw);
    return phone?'https://wa.me/'+phone:'';
  }
  function whatsappAppUrl(raw){
    const phone=internationalNumber(raw);
    return phone?'whatsapp://send?phone='+phone:'';
  }
  function smsUrl(raw){
    const phone=internationalNumber(raw);
    return phone?'sms:+'+phone:'';
  }
  root.hubContractContactV1158={firstName,message,internationalNumber,whatsappUrl,whatsappAppUrl,smsUrl};
})(typeof window==='object'?window:globalThis);
