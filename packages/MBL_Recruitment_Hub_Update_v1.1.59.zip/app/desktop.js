/* MBL Recruitment Hub Desktop v1.1.53 — verified and recoverable induction attendance. */
(() => {
  if (!window.mbl) return;

  state.syncQueue = state.syncQueue || [];
  state.statusMappings = state.statusMappings || {};
  state.syncIssues = state.syncIssues || [];
  state.attendanceIssues = state.attendanceIssues || [];
  const attendanceAudit=window.hubAttendanceAuditV1153;
  state.mblSessions = state.mblSessions || [];
  state.connection = state.connection || null;
  state.appVersion = '1.1.46';
  state.latestUpdate = state.latestUpdate || null;
  state.defaultInductionTime = state.defaultInductionTime || localStorage.getItem('mblDefaultInductionTime') || '10:45';
  localStorage.setItem('mblDefaultInductionTime', state.defaultInductionTime);

  function getDefaultInductionTime() {
    const v = String(localStorage.getItem('mblDefaultInductionTime') || state.defaultInductionTime || '10:45');
    return /^([01]\d|2[0-3]):[0-5]\d$/.test(v) ? v : '10:45';
  }
  window.getDefaultInductionTime = getDefaultInductionTime;

  // UI scale is deliberately local to this PC and survives app updates.
  // 125% is the default because the Hub is commonly used maximised on a large monitor.
  const savedScale = Number(localStorage.getItem('mblUiScale') || '1.25');
  const initialScale = Number.isFinite(savedScale) ? Math.max(.8, Math.min(2.0, savedScale)) : 1.25;
  localStorage.setItem('mblUiScale', String(initialScale));
  window.mbl.setUiScale(initialScale).catch(()=>{});

  let refreshBusy = false;
  let detailsBusy = new Set();
  let selectedSessionMeta = null;
  let activeTimer = null;
  const baseNextInductionDates = nextInductionDates;
  const baseStatusLabel = statusLabel;
  const baseStatusClass = statusClass;
  const originalRenderHome = renderHome;
  const originalRenderProfile = renderProfile;
  const originalRenderCallMode = renderCallMode;
  const originalApplyNoAnswer = applyNoAnswer;
  const originalSetStatus = setStatus;
  const originalAddNote = addNote;
  const originalUndoLast = undoLast;
  const originalSetProceedDecision = setProceedDecision;

  function injectDesktopUi() {
    const style = document.createElement('style');
    style.textContent = `
      .sync-live-btn{padding:8px 10px;border-radius:999px!important;border:1px solid #2d343a!important;font-weight:800!important;white-space:nowrap}
      .sync-live-btn.live{color:#7ce0aa!important;border-color:#245d43!important;background:#10251b!important}
      .sync-live-btn.wait{color:#ffd176!important;border-color:#69511f!important;background:#2a210d!important}
      .sync-live-btn.bad{color:#ff8790!important;border-color:#6e3038!important;background:#291519!important}
      .sync-alert{display:flex;justify-content:space-between;gap:14px;align-items:center;background:#24171a;border:1px solid #6e3038;border-radius:10px;padding:11px 13px;margin-bottom:12px;font-size:10px}
      .sync-alert b{font-size:11px}.sync-alert span{color:#ffadb3}
      .sync-state-mini{display:inline-flex;align-items:center;gap:5px;font-size:9px;margin-top:8px}
      .local-chip{color:#ffc266}.live-chip{color:#7ce0aa}.pending-chip{color:#ffd176}.failed-chip{color:#ff8790}
      .sync-modal-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:12px 0}.sync-kpi{background:#13171a;border:1px solid #293038;border-radius:8px;padding:10px}.sync-kpi span{display:block;color:#87929c;font-size:8px;text-transform:uppercase}.sync-kpi b{display:block;margin-top:4px;font-size:12px}
      .issue-row{border:1px solid #3b3134;background:#171315;border-radius:8px;padding:10px;margin-top:8px}.issue-row b{font-size:11px}.issue-row p{font-size:9px;color:#aeb6bd;margin:4px 0 8px}.issue-controls{display:flex;gap:7px}.issue-controls select{flex:1;background:#0e1114;color:white;border:1px solid #384048;border-radius:7px;padding:8px;font-size:10px}
      .timer-options{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px}.timer-options button{padding:13px}.timer-running{background:#12191a;border:1px solid #2c4f43;border-radius:9px;padding:12px;margin-top:10px}.timer-running b{color:#8ee5b3}
      .connect-banner{background:linear-gradient(90deg,#211416,#13171a);border:1px solid #71303a;border-radius:10px;padding:12px 14px;margin:0 0 12px;display:flex;align-items:center;justify-content:space-between;gap:12px}.connect-banner b{font-size:12px}.connect-banner span{display:block;color:#b7bfc6;font-size:9px;margin-top:3px}
      .needs-review{color:#d8b2ff!important;border-color:#62467d!important;background:#21172d!important}
      .quick-actions-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.quick-actions-grid button{min-height:46px}
      .quick-note-box{margin-top:12px;padding-top:12px;border-top:1px solid #2d343a}.quick-note-box textarea{width:100%;min-height:88px;background:#0d1013;color:#fff;border:1px solid #343c43;border-radius:8px;padding:10px;resize:vertical}
      .outcome-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.outcome-grid button{min-height:50px;text-align:left}.outcome-help{color:#9aa4ad;font-size:9px;margin-top:4px;display:block}
      .session-status-chip{display:inline-flex;align-items:center;border:1px solid #394149;border-radius:999px;padding:5px 8px;font-size:8px;color:#aeb7be;background:#15191c;margin-top:5px}
      .scale-help{color:#9aa4ad;font-size:9px;margin-top:8px}.scale-options-desktop{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}.scale-options-desktop button.active{border-color:#8d323b;background:#2a1519;color:#ffb1b7}
      .requirements-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.requirements-grid button{min-height:48px;text-align:left}.requirements-grid button.active{border-color:#9a3a45;background:#30161b;color:#ffb5bb}.requirements-note{width:100%;min-height:86px;background:#0d1013;color:#fff;border:1px solid #343c43;border-radius:8px;padding:10px;resize:vertical;margin-top:10px}
      .add-candidate-cal{border:1px solid #2b3238;background:#0e1114;border-radius:10px;padding:11px;margin-top:4px}
      .add-candidate-cal-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px}
      .add-candidate-cal-head b{font-size:12px}.add-candidate-cal-nav{display:flex;gap:6px}.add-candidate-cal-nav button{border:1px solid #343c44;background:#171b1f;color:#fff;border-radius:7px;padding:6px 10px;cursor:pointer}
      .add-candidate-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:5px}.add-candidate-cal-dow{font-size:8px;color:#77818b;text-transform:uppercase;text-align:center;padding:3px 0}
      .add-candidate-cal-day{min-height:46px;border:1px solid #252c32;background:#121619;color:#fff;border-radius:8px;padding:5px;cursor:pointer;position:relative;text-align:left}.add-candidate-cal-day:hover{border-color:#f22f3d;box-shadow:0 0 10px rgba(242,47,61,.12)}
      .add-candidate-cal-day.selected{border-color:#f22f3d;background:#251216}.add-candidate-cal-day.disabled{opacity:.28;cursor:not-allowed;box-shadow:none}.add-candidate-cal-day.empty{visibility:hidden}.add-candidate-cal-day .daynum{font-size:11px;font-weight:800}
      .add-candidate-cal-day .mbl-dot{position:absolute;right:5px;top:5px;width:6px;height:6px;border-radius:99px;background:#63d69a}.add-candidate-cal-summary{margin-top:9px;padding:8px 9px;border:1px solid #303840;border-radius:8px;background:#14191d;font-size:9px;color:#c5ccd2}
      .add-candidate-cal-none{width:100%;margin-top:8px;border:1px solid #394149;background:#171b1f;color:#dfe4e8;border-radius:8px;padding:8px;cursor:pointer}.add-candidate-cal-none.active{border-color:#f22f3d;background:#251216;color:#fff}
      .local-lead-list{display:flex;flex-direction:column;gap:7px;max-height:320px;overflow:auto;margin-top:12px}.local-lead-row{display:flex;justify-content:space-between;gap:10px;align-items:center;border:1px solid #2c343b;background:#121619;border-radius:8px;padding:9px 10px}.local-lead-row b{font-size:10px}.local-lead-row span{font-size:9px;color:#9da7af}
      .local-to-mbl-chip{border-color:#6d5224!important;background:linear-gradient(180deg,#211b0d,#121518)!important}.local-to-mbl-chip b{color:#ffd176}.local-to-mbl-chip span{color:#c7b27d!important}
      .profile-prior-btn{width:100%;margin-top:10px;border:1px solid #414951;background:#15191d;color:#e9edf0;border-radius:8px;padding:10px 11px;text-align:left;display:flex;align-items:center;justify-content:space-between;gap:10px;cursor:pointer}.profile-prior-btn:hover{border-color:#a63a46;background:#211416;box-shadow:0 0 13px rgba(242,47,61,.10)}.profile-prior-btn.found{border-color:#6e3038;background:#25171a}.profile-prior-btn b{font-size:10px}.profile-prior-btn span{font-size:8px;color:#ff9da4}.profile-prior-btn.none span{color:#87929c}.prior-app-detail{border:1px solid #303840;background:#121619;border-radius:10px;padding:12px;margin-top:10px}.prior-app-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.prior-app-head b{font-size:12px}.prior-app-date{font-size:9px;color:#98a1aa;white-space:nowrap}.prior-app-meta{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}.prior-app-meta div{background:#0e1114;border:1px solid #272e34;border-radius:7px;padding:8px}.prior-app-meta span{display:block;color:#7f8992;font-size:7px;text-transform:uppercase}.prior-app-meta strong{display:block;margin-top:3px;font-size:9px}.prior-reason{margin-top:9px;border-left:3px solid #f22f3d;background:#211316;border-radius:6px;padding:8px 9px;font-size:9px;line-height:1.45}.prior-reason.none{border-left-color:#46515b;background:#111519;color:#98a1aa}.prior-timeline{margin-top:9px;display:flex;flex-direction:column;gap:6px;max-height:240px;overflow:auto}.prior-timeline-row{display:grid;grid-template-columns:92px 1fr;gap:8px;border-top:1px solid #242b31;padding-top:6px}.prior-timeline-row:first-child{border-top:0}.prior-timeline-row time{font-size:8px;color:#84909a}.prior-timeline-row b{font-size:9px}.prior-timeline-row p{margin:2px 0 0;color:#aeb6bd;font-size:8px;line-height:1.4}@media(max-width:720px){.prior-app-meta{grid-template-columns:1fr}.prior-timeline-row{grid-template-columns:1fr}}
      #confirmModal .modal{width:min(720px,calc(100vw - 24px))!important;max-width:720px;max-height:calc(100vh - 24px);overflow:auto}
      #confirmModal #sessionChoices{max-height:none;overflow:visible;padding-right:0}
      .confirm-calendar{border:1px solid #293038;border-radius:10px;background:#0e1114;padding:12px;width:100%;min-width:0;overflow:hidden}
      .confirm-cal-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}.confirm-cal-head b{font-size:13px}.confirm-cal-nav{display:flex;gap:6px}.confirm-cal-nav button{border:1px solid #343c44;background:#171b1f;color:#fff;border-radius:7px;padding:6px 10px;cursor:pointer}
      .confirm-cal-grid{display:grid!important;grid-template-columns:repeat(7,minmax(0,1fr))!important;gap:5px;width:100%;min-width:0}
      .confirm-cal-dow{display:block!important;font-size:8px;color:#77818b;text-transform:uppercase;text-align:center;padding:4px 0;min-width:0}
      .confirm-cal-day{display:block!important;width:100%!important;min-width:0!important;min-height:48px;border:1px solid #242b31;background:#121619;color:#fff;border-radius:8px;padding:6px;cursor:pointer;text-align:left;position:relative;overflow:hidden}
      .confirm-cal-day:hover{border-color:#f22f3d;box-shadow:0 0 12px rgba(242,47,61,.12)}.confirm-cal-day.selected{border-color:#f22f3d;background:#251216;box-shadow:0 0 14px rgba(242,47,61,.18)}.confirm-cal-day.disabled{opacity:.28;cursor:not-allowed;box-shadow:none}.confirm-cal-day.empty{visibility:hidden}.confirm-cal-day .daynum{font-size:11px;font-weight:800}.confirm-cal-day .mbl-dot{position:absolute;right:5px;top:5px;width:6px;height:6px;border-radius:999px;background:#63d69a}
      .confirm-cal-selected{margin-top:10px;padding:9px 10px;border:1px solid #303840;border-radius:8px;background:#14191d;font-size:10px;color:#c5ccd2}
      @media(max-width:900px){#confirmModal.modalwrap{padding:10px}#confirmModal .modal{width:calc(100vw - 20px)!important;padding:15px}.confirm-calendar{padding:9px}.confirm-cal-grid{gap:3px}.confirm-cal-day{min-height:40px;padding:4px}.confirm-cal-day .daynum{font-size:10px}.confirm-cal-dow{font-size:7px}.confirm-cal-selected{font-size:9px}.modalhead h3{font-size:16px}}
      @media(max-width:620px){.confirm-cal-grid{gap:2px}.confirm-cal-day{min-height:36px;border-radius:6px}.confirm-cal-nav button{padding:5px 8px}.confirm-cal-head b{font-size:12px}}
      .update-top-btn{display:none;color:#9ef0bb!important;border-color:#2b6548!important;background:#10251b!important;font-weight:800}.update-top-btn.show{display:inline-flex}.update-top-btn.busy{color:#ffd176!important;border-color:#69511f!important;background:#2a210d!important}.update-notes{white-space:pre-line;background:#101417;border:1px solid #2c343b;border-radius:8px;padding:10px;margin:10px 0;color:#c4cbd1;font-size:9px}
    `;
    document.head.appendChild(style);

    const syncModal = document.createElement('div');
    syncModal.className = 'modalwrap'; syncModal.id = 'syncModal';
    syncModal.innerHTML = `<div class="modal" style="width:min(720px,96vw)"><div class="modalhead"><h3>Official MBL Connection</h3><button class="x" onclick="closeModal('syncModal')">×</button></div><div id="syncModalBody"></div></div>`;
    document.body.appendChild(syncModal);

    const timerModal = document.createElement('div');
    timerModal.className = 'modalwrap'; timerModal.id = 'timerModal';
    timerModal.innerHTML = `<div class="modal" style="width:min(470px,94vw)"><div class="modalhead"><h3>Quick Timer</h3><button class="x" onclick="closeModal('timerModal')">×</button></div><div class="sub">Set a simple recruitment timer. You'll get a Windows notification when it finishes.</div><div class="timer-options"><button class="cta" onclick="setQuickTimer(5)">5 min</button><button class="cta" onclick="setQuickTimer(10)">10 min</button><button class="cta" onclick="setQuickTimer(15)">15 min</button><button class="cta" onclick="setQuickTimer(30)">30 min</button><button class="cta" onclick="setQuickTimer(60)">1 hour</button><button class="cta" onclick="customTimer()">Custom</button></div><div id="timerStatus"></div></div>`;
    document.body.appendChild(timerModal);

    const quickActionsModal = document.createElement('div');
    quickActionsModal.className = 'modalwrap'; quickActionsModal.id = 'quickActionsModal';
    quickActionsModal.innerHTML = `<div class="modal" style="width:min(520px,94vw)"><div class="modalhead"><h3 id="quickActionsTitle">Candidate actions</h3><button class="x" onclick="closeModal('quickActionsModal')">×</button></div><div id="quickActionsBody"></div></div>`;
    document.body.appendChild(quickActionsModal);

    const inductionOutcomeModal = document.createElement('div');
    inductionOutcomeModal.className = 'modalwrap'; inductionOutcomeModal.id = 'inductionOutcomeModal';
    inductionOutcomeModal.innerHTML = `<div class="modal" style="width:min(560px,94vw)"><div class="modalhead"><h3 id="inductionOutcomeTitle">Induction outcome</h3><button class="x" onclick="closeModal('inductionOutcomeModal')">×</button></div><div id="inductionOutcomeBody"></div></div>`;
    document.body.appendChild(inductionOutcomeModal);

    const requirementsModal = document.createElement('div');
    requirementsModal.className = 'modalwrap'; requirementsModal.id = 'requirementsModal';
    requirementsModal.innerHTML = `<div class="modal" style="width:min(620px,94vw)"><div class="modalhead"><h3 id="requirementsTitle">Doesn't meet requirements</h3><button class="x" onclick="closeModal('requirementsModal')">×</button></div><div id="requirementsBody"></div></div>`;
    document.body.appendChild(requirementsModal);

    const localLeadsModal = document.createElement('div');
    localLeadsModal.className = 'modalwrap'; localLeadsModal.id = 'localLeadsModal';
    localLeadsModal.innerHTML = `<div class="modal" style="width:min(620px,94vw)"><div class="modalhead"><h3>Local candidates still to add to MBL</h3><button class="x" onclick="closeModal('localLeadsModal')">×</button></div><div id="localLeadsBody"></div></div>`;
    document.body.appendChild(localLeadsModal);

    const previousAppsModal = document.createElement('div');
    previousAppsModal.className = 'modalwrap'; previousAppsModal.id = 'previousAppsModal';
    previousAppsModal.innerHTML = `<div class="modal" style="width:min(760px,96vw);max-height:92vh;overflow:auto"><div class="modalhead"><h3 id="previousAppsTitle">Previous applications</h3><button class="x" onclick="closeModal('previousAppsModal')">×</button></div><div id="previousAppsBody"></div></div>`;
    document.body.appendChild(previousAppsModal);

    const topRight = document.querySelector('.top-right');
    if (topRight && !document.getElementById('updateTopBtn')) {
      const b = document.createElement('button');
      b.className = 'pill update-top-btn'; b.id = 'updateTopBtn'; b.textContent = 'Update available';
      b.addEventListener('click', () => installLatestUpdate());
      topRight.insertBefore(b, document.getElementById('syncText'));
    }
    document.getElementById('syncText')?.addEventListener('click', openSyncPanel);
    document.getElementById('timerTopBtn')?.addEventListener('click', () => { renderTimerStatus(); openModal('timerModal'); });
  }

  function parseApiDate(v) {
    const m = String(v || '').match(/(\d{2})[-\/](\d{2})[-\/](\d{4})/);
    return m ? `${m[1]}/${m[2]}/${m[3]}` : null;
  }
  function apiDateOnly(v) {
    const m = String(v || '').match(/(\d{2})[-\/](\d{2})[-\/](\d{4})/);
    return m ? `${m[1]}-${m[2]}-${m[3]}` : '';
  }
  function localDateOnly(v) {
    const m = String(v || '').match(/(\d{2})[-\/](\d{2})[-\/](\d{4})/);
    return m ? `${m[1]}-${m[2]}-${m[3]}` : '';
  }
  function formatTime12(time24=getDefaultInductionTime()) {
    const m=String(time24||getDefaultInductionTime()).match(/^(\d{1,2}):(\d{2})/); if(!m)return String(time24||getDefaultInductionTime());
    let h=Number(m[1]), mins=m[2], ap=h>=12?'PM':'AM'; h=h%12||12; return `${h}:${mins} ${ap}`;
  }
  function officialSessionForDate(dateStr) {
    return (state.mblSessions||[]).find(x=>parseApiDate(x.date)===dateStr) || null;
  }
  function inductionTimeForCandidate(c, dateStr=null) {
    // The personal Hub intentionally uses your chosen working time as the baseline.
    // Official MBL session times are retained separately so mismatches can be shown,
    // rather than silently changing what you see in your own workflow.
    return c?.inductionTime || getDefaultInductionTime();
  }
  function officialTimeForDate(dateStr) {
    return officialSessionForDate(dateStr)?.time || '';
  }
  function timeMismatchText(dateStr) {
    const official = officialTimeForDate(dateStr), local = getDefaultInductionTime();
    return official && official !== local ? `Official MBL currently ${formatTime12(official)}` : '';
  }
  // CONFIRMED ROSTER: authoritative for the induction calendar and its
  // red number badges. An MBL induction date alone does NOT mean they
  // confirmed attendance: Spoke To / Call Back / No Answer must stay out.
  function isConfirmedInductionCandidate(c,dateStr){
    if(!c)return false;
    if(c.mblId&&!c.localOnly){
      // MBL's actual CONFIRMED / RESCHEDULED stage is authoritative.
      // An old local No Answer label must not hide an officially confirmed
      // arrival, but a recorded attendance / downstream pipeline decision
      // must not count as someone still expected to turn up.
      const finished=['attended','no_show','not_proceeding','contract_pending',
        'contract_quiet','contract_signed','requirements_failed','hired'];
      return !finished.includes(c.status) &&
        ['confirmed','rescheduled'].includes(String(c.officialCallStage||'')) &&
        parseApiDate(c.officialInduction)===dateStr;
    }
    return c.status==='confirmed' && c.induction===dateStr;
  }
  function confirmedInductionPeopleForDate(dateStr){
    return (state.candidates||[]).filter(c=>isConfirmedInductionCandidate(c,dateStr));
  }
  function inductionPeopleForDate(dateStr) {
    const isPastOrToday=parseDMY(dateStr)<=parseDMY(todayDMY());
    const confirmed=confirmedInductionPeopleForDate(dateStr);
    if(!isPastOrToday)return confirmed;
    // On past/today dates also keep genuine outcomes the recruiter has
    // recorded, including people who have already progressed into Contracts.
    // This is NOT an invitation to show every provisionally booked person.
    const ids=new Set(confirmed.map(c=>c.id));
    const outcomes=(state.candidates||[]).filter(c=>{
      if(ids.has(c.id))return false;
      const localMatch=c.induction===dateStr||
        c.lastInduction===dateStr||
        c.historicalDateCorrection?.date===dateStr;
      const officialMatch=parseApiDate(c.officialInduction)===dateStr;
      const saved=recordedAttendance(c);
      if(saved?.date===dateStr&&(localMatch||officialMatch))return true;
      if(localMatch&&['attended','no_show','contract_pending','contract_quiet',
        'contract_signed','not_proceeding','requirements_failed','hired'].includes(c.status))return true;
      return officialMatch&&['attended','not_attended'].includes(String(c.officialCallStage||''));
    });
    return confirmed.concat(outcomes);
  }
  function nextLocalId() {
    const nums = state.candidates.map(c => Number(c.id)).filter(Number.isFinite);
    return (nums.length ? Math.max(...nums) : 0) + 1;
  }
  function expectedFor(c) {
    return { callStage: c.officialCallStage || null, induction: c.officialInduction || null, attempts: Number(c.officialAttempts ?? c.attempts ?? 0) };
  }
  function isAttendanceWrite(action) {
    return action?.type==='attended'||action?.type==='not_attended'||
      (action?.type==='correct'&&['attended','no_show'].includes(action.targetStatus));
  }
  function futureOfficialAttendanceConflict(c, action) {
    if(!isAttendanceWrite(action))return false;
    const booked=parseApiDate(c?.officialInduction||action.expected?.induction||'');
    return !!booked && parseDMY(booked)>parseDMY(todayDMY());
  }
  function attendanceNeedsManualReview(action, error) {
    return isAttendanceWrite(action) &&
      /cannot go from|invalid (?:stage |status )?transition|transition not allowed|not allowed from|not permitted from/i.test(String(error||''));
  }
  function attendanceReviewMessage(c, action) {
    const date=parseApiDate(c?.officialInduction||action.expected?.induction||'');
    return 'Official MBL booking: '+(date||'different date')+
      '. Review the actual attendance date and official booking before retrying. No official attendance change was made.';
  }
  function holdRejectedAttendanceWrites() {
    let changed=false;
    for(const q of (state.syncQueue||[])){
      if(q.status==='failed'&&attendanceNeedsManualReview(q.action,q.error)){
        q.status='review';
        q.reviewReason=q.reviewReason||'Official MBL stage transition rejected';
        changed=true;
      }
    }
    if(changed)save();
    return changed;
  }
  function localAttendanceRecord(c,outcome,date,source='choice'){
    const valid=attendanceAudit?.validDate(date);
    if(!c||!valid||!['attended','not_attended'].includes(outcome))return null;
    // Keep the recruiter's actual decision separately from the MBL call stage.
    // An ordinary MBL refresh must never rewrite this local evidence.
    const previous=c.attendanceRecord;
    if(previous?.date===valid&&previous.outcome===outcome)return previous;
    c.attendanceRecord={date:valid,outcome,source,recordedAt:new Date().toISOString()};
    return c.attendanceRecord;
  }
  function recordedAttendance(c){
    return attendanceAudit?.saved(c)||null;
  }
  function auditAttendanceAgainstMbl(notify=false){
    const issues=[];
    for(const c of state.candidates||[]){
      if(!c?.mblId)continue;
      const evidence=recordedAttendance(c);
      if(evidence&&!c.attendanceRecord){
        // Recover recent, explicit YES/NO entries from older Hub history.
        localAttendanceRecord(c,evidence.outcome,evidence.date,'history');
      }
      const diff=attendanceAudit?.disagreement(c);
      if(!diff){
        if(evidence && [evidence.outcome,'hired','not_hired','not_meeting_requirements'].includes(
          String(c.officialCallStage||'')))c.attendanceSync='verified';
        continue;
      }
      issues.push(diff);
      // If yesterday's explicit attendance was overwritten by an old
      // official call column, restore the Hub's local recorded outcome
      // WITHOUT changing MBL. Never rewrite a different-date booking.
      const booked=parseApiDate(c.officialInduction);
      if(diff.date===booked &&
          ['to_call','spoke_to','no_answer','confirmed'].includes(c.status)){
        c.status=diff.outcome==='attended'?'attended':'no_show';
        if(diff.outcome==='attended')c.induction=diff.date;
        else c.lastInduction=diff.date;
      }
      c.attendanceSync='review';
    }
    state.attendanceIssues=issues;
    save();
    if(notify&&issues.length&&state.connection?.ok){
      const fingerprint=issues.map(x=>x.mblId+':'+x.outcome+':'+x.date).sort().join('|');
      if(localStorage.getItem('mblAttendanceAlertFingerprint')!==fingerprint){
        localStorage.setItem('mblAttendanceAlertFingerprint',fingerprint);
        try{Promise.resolve(window.mbl.notify?.('Recruitment Hub — attendance not confirmed',
          issues.length+' saved attendance decision'+(issues.length===1?'':'s')+
          ' still differ from official MBL. Open Connection details.')).catch(()=>{});}catch{}
      }
    }
    return issues;
  }
  function unattendedOfficialMismatches(){
    return (state.attendanceIssues||[]).filter(x=>
      !(state.syncQueue||[]).some(q=>q.mblId===x.mblId&&isAttendanceWrite(q.action)&&q.status!=='done'));
  }
  // Older rejected entries are upgraded before the background retry timers.
  holdRejectedAttendanceWrites();

  function mblStatusToLocal(o, existing = null) {
    const stage = o.officialCallStage || null;
    if (stage && Object.prototype.hasOwnProperty.call(state.statusMappings, stage)) {
      const m = state.statusMappings[stage];
      return m === '__ignore__' ? (existing?.status || null) : m;
    }
    const attempts = Number(o.attempts || 0);
    switch (stage) {
      case 'to_call': return 'to_call';
      case 'no_answer': return 'no_answer';
      case 'callback': return 'no_answer';
      case 'hang_up': return 'no_answer';
      case 'answered': return 'spoke_to';
      case 'confirmed': case 'rescheduled': return 'confirmed';
      case 'declined': return 'not_interested';
      case 'attended': return 'attended';
      case 'not_attended': return 'no_show';
      case 'not_hired': return existing?.requirementsReason ? 'requirements_failed' : 'not_proceeding';
      case 'hired': return 'hired';
      case 'not_meeting_requirements': return 'requirements_failed';
      case null: case undefined:
        // A booked candidate with no official callStage is normally To Call. However, if this
        // Hub has a real local confirmation event for the exact same induction date, preserve
        // Confirmed long enough to repair the missing official call-stage write instead of
        // silently undoing the recruiter action.
        if (o.officialStage === 'booked') {
          const sameDate = !!existing?.induction && parseApiDate(o.officialInduction) === existing.induction;
          const localConfirmEvidence = sameDate && existing?.status === 'confirmed' && (existing.history || []).some(h => {
            const title = String(h?.[1] || '').toLowerCase();
            return title === 'confirmed' || title === 'confirmed locally';
          });
          if (localConfirmEvidence) return 'confirmed';
          return 'to_call';
        }
        return existing?.status || 'to_call';
      default: return null;
    }
  }
  function isPostInductionStatus(s) { return ['contract_pending','contract_quiet','contract_signed','not_proceeding','requirements_failed'].includes(s); }
  function pushSyncIssue(c, officialStage) {
    const key = `${c.mblId}:${officialStage}`;
    if (!state.syncIssues.some(x => x.key === key)) state.syncIssues.push({ key, candidateId: c.id, mblId: c.mblId, name: c.name, officialStage, createdAt: new Date().toISOString() });
  }
  function clearResolvedIssues() {
    const builtIn = new Set(['to_call','no_answer','callback','hang_up','answered','confirmed','rescheduled','declined','attended','not_attended','not_hired','not_meeting_requirements','hired']);
    state.syncIssues = (state.syncIssues || []).filter(x => !builtIn.has(x.officialStage) && !Object.prototype.hasOwnProperty.call(state.statusMappings, x.officialStage));
  }
  function addHistoryOnce(c, when, title, detail) {
    c.history = c.history || [];
    const key = `${when}|${title}|${detail || ''}`;
    if (!c.history.some(h => `${h[0]}|${h[1]}|${h[2] || ''}` === key)) c.history.push([when, title, detail || '']);
  }
  function localPhoneKey(v){
    let d=String(v||'').replace(/\D/g,'');
    if(d.startsWith('0044'))d=d.slice(4);
    else if(d.startsWith('44'))d=d.slice(2);
    else if(d.startsWith('0'))d=d.slice(1);
    return d.length>=10?d.slice(-10):d;
  }
  function localEmailKey(v){return String(v||'').trim().toLowerCase();}
  function findExactLocalCandidate(o){
    const phone=localPhoneKey(o?.phone),email=localEmailKey(o?.email);
    const matches=(state.candidates||[]).filter(c=>{
      if(c.mblId||!c.localOnly)return false;
      const phoneMatch=phone&&localPhoneKey(c.phone)===phone;
      const emailMatch=email&&localEmailKey(c.email)===email;
      return phoneMatch||emailMatch;
    });
    return matches.length===1?matches[0]:null;
  }
  function mergeOneOfficial(c, o) {
    const oldStage = c.officialCallStage || null, oldInduction = c.officialInduction || null, oldLocalStatus = c.status;
    c.mblId = o.mblId; c.localOnly = false; c.name = o.name || c.name; c.phone = o.phone || c.phone; c.email = o.email || c.email;
    c.applied = o.applied ? parseApiDate(o.applied) || o.applied : c.applied; c.source = o.source || c.source || 'MBL';
    c.officialStage = o.officialStage || null; c.officialCallStage = o.officialCallStage || null; c.officialInduction = o.officialInduction || null;
    c.officialAttempts = Number(o.attempts || 0); c.lastCalledBy = o.lastCalledBy || null;
    const preservePendingWrite = c.syncState === 'pending' || c.syncState === 'failed';
    const preservedAttendance=attendanceAudit?.saved(c);
    const officialAttendanceMismatch=preservedAttendance &&
      ![preservedAttendance.outcome,'hired','not_hired','not_meeting_requirements'].includes(String(o.officialCallStage||''));
    const preserveLocalAttendance=!!officialAttendanceMismatch &&
      ['attended','no_show','contract_pending','contract_quiet','contract_signed',
       'not_proceeding'].includes(oldLocalStatus);
    if (!preservePendingWrite&&!preserveLocalAttendance) c.syncState = 'synced';
    const mapped = mblStatusToLocal(o, c);
    if (!mapped && o.officialCallStage) {
      c.status = c.status || 'needs_review'; pushSyncIssue(c, o.officialCallStage);
    } else if (mapped) {
      const preservePersonalPostStage = isPostInductionStatus(c.status) && (o.officialCallStage === 'attended' || (c.status === 'not_proceeding' && o.officialCallStage === 'not_hired'));
      // A queued/failed write is an intentional local change waiting to reach MBL, so keep it.
      // Otherwise the official call-board stage is authoritative and repairs local drift.
      if (!preservePersonalPostStage && !preservePendingWrite && !preserveLocalAttendance) c.status = mapped;
      if (mapped === 'confirmed' && !preserveLocalAttendance &&
          !(c.historicalDateCorrection && c.historicalDateCorrection.date===c.induction))
        c.induction = parseApiDate(o.officialInduction) || c.induction;
      if (mapped === 'no_answer' && !preserveLocalAttendance) {
        // Recruitment Hub owns the local two-attempt workflow. Official MBL callAttempts can be
        // higher for historical/imported records, so do not auto-archive from that number alone.
        const localNoAnswers = (c.history || []).filter(h => String(h?.[1] || '').startsWith('Called — No Answer')).length;
        if (localNoAnswers >= 2) { c.status = 'archived'; c.attempts = 2; }
        else if (localNoAnswers === 1) { c.status = 'no_answer'; c.attempts = 1; }
        else { c.status = 'no_answer'; c.attempts = Math.max(1, Math.min(Number(c.attempts || 0), 1)); }
      }
    }
    if ((oldStage && oldStage !== c.officialCallStage) || (oldInduction && oldInduction !== c.officialInduction)) {
      addHistoryOnce(c, nowStamp(), 'Updated from MBL', `${oldStage || '—'} → ${c.officialCallStage || '—'}${oldInduction !== c.officialInduction ? ` · ${c.officialInduction || 'no induction'}` : ''}`);
    }
    if (!preservePendingWrite && oldLocalStatus && oldLocalStatus !== c.status) {
      const officialLabel = o.officialCallStage || (o.officialStage === 'booked' ? 'to_call' : o.officialStage || '—');
      addHistoryOnce(c, nowStamp(), 'Reconciled with MBL', `${oldLocalStatus} → ${c.status} · official ${officialLabel}`);
    }
  }
  function mergeSnapshot(snapshot) {
    if (!snapshot?.candidates) return;
    const seen = new Set();
    state.mblSessions = snapshot.sessions || state.mblSessions || [];
    state.connection = snapshot.connection || state.connection;
    snapshot.candidates.forEach(o => {
      seen.add(o.mblId);
      let c = state.candidates.find(x => x.mblId === o.mblId);
      if (!c) {
        const exactLocal=findExactLocalCandidate(o);
        if(exactLocal){
          c=exactLocal;
          addHistoryOnce(c,nowStamp(),'Matched to official MBL','Exact phone/email match found during official refresh');
          mergeOneOfficial(c,o);
        } else {
          const mapped = mblStatusToLocal(o, null);
          c = {
            id: nextLocalId(), mblId: o.mblId, localOnly: false, name: o.name || 'Unknown candidate', phone: o.phone || '', email: o.email || '',
            applied: parseApiDate(o.applied) || o.applied || todayDMY(), status: mapped || 'needs_review', attempts: mapped === 'no_answer' ? 1 : Number(o.attempts || 0), source: o.source || 'MBL',
            notes: [], history: [[nowStamp(),'Synced from MBL','Imported from the official HULL recruitment system']], previousApplications: [], previousChecked: false,
            induction: mapped === 'confirmed' ? parseApiDate(o.officialInduction) : null, officialInduction: o.officialInduction || null,
            officialStage: o.officialStage || null, officialCallStage: o.officialCallStage || null, officialAttempts: Number(o.attempts || 0), syncState: 'synced'
          };
          if (!mapped && o.officialCallStage) pushSyncIssue(c, o.officialCallStage);
          state.candidates.push(c);
        }
      } else mergeOneOfficial(c, o);
    });
    clearResolvedIssues();
    state.lastMblRefresh = snapshot.at || new Date().toISOString();
    save();
  }

  function officialFutureDates() {
    const now = new Date(); const today = new Date(now.getFullYear(),now.getMonth(),now.getDate());
    const [cutH,cutM]=getDefaultInductionTime().split(':').map(Number); const cutoffToday = new Date(now.getFullYear(),now.getMonth(),now.getDate(),cutH,cutM,0,0);
    const seen = new Set(), arr = [];
    for (const s of state.mblSessions || []) {
      const ds = parseApiDate(s.date); if (!ds || seen.has(ds)) continue;
      const d = parseDMY(ds); d.setHours(12,0,0,0);
      const dayOnly = new Date(d.getFullYear(),d.getMonth(),d.getDate());
      if (dayOnly < today || (dayOnly.getTime()===today.getTime() && now>=cutoffToday) || d.getDay() === 0) continue;
      seen.add(ds); arr.push(d);
    }
    return arr.sort((a,b)=>a-b);
  }
  nextInductionDates = function(count = 3) {
    const official = officialFutureDates();
    return official.length ? official.slice(0, count) : baseNextInductionDates(count);
  };

  statusLabel = function(c) {
    if (c.status === 'needs_review') return 'MBL Status — Review';
    const label = baseStatusLabel(c);
    return (!c.mblId || c.localOnly) ? `Local · ${label}` : label;
  };
  statusClass = function(s) { return s === 'needs_review' ? 'needs-review' : baseStatusClass(s); };

  function setSyncUi(kind, text) {
    const e = document.getElementById('syncText'); if (!e) return;
    e.classList.remove('live','wait','bad'); e.classList.add(kind === 'ok' ? 'live' : kind === 'wait' ? 'wait' : 'bad'); e.textContent = text;
    const hero = document.querySelector('.home-lite-hero .demo-ribbon');
    if (hero) {
      hero.textContent = kind === 'ok' ? 'Official MBL · live' : kind === 'wait' ? 'Official MBL · syncing' : 'Official MBL · attention';
      hero.style.color = kind === 'ok' ? '#7ce0aa' : kind === 'wait' ? '#ffd176' : '#ff8790';
    }
  }
  function connectedText() {
    const t = state.lastMblRefresh ? new Date(state.lastMblRefresh).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'}) : '';
    return `🟢 MBL LIVE${t ? ` · ${t}` : ''}`;
  }
  function updateSyncUiFromState() {
    const pending = (state.syncQueue || []).filter(x => x.status !== 'done').length;
    const review=(state.syncQueue||[]).filter(x=>x.status==='review').length;
    const unsyncedAttendance=unattendedOfficialMismatches().length;
    if(review||unsyncedAttendance)return setSyncUi('bad',
      '🔴 '+(review+unsyncedAttendance)+' ATTENDANCE / OFFICIAL UPDATES NEED REVIEW');
    if (pending) return setSyncUi('wait', `🟠 ${pending} SYNC PENDING`);
    if (state.connection?.ok) return setSyncUi('ok', connectedText());
    const msg = state.connection?.state === 'signin' ? '🔴 SIGN IN REQUIRED' : '🔴 MBL OFFLINE';
    setSyncUi('bad', msg);
  }

  function confirmedRepairCandidates() {
    return (state.candidates || []).filter(c => {
      if (!c?.mblId || c.localOnly || c.status !== 'confirmed') return false;
      if (c.officialStage !== 'booked' || c.officialCallStage) return false;
      if (c.syncState === 'pending' || c.syncState === 'failed') return false;
      if (!c.induction || parseApiDate(c.officialInduction) !== c.induction) return false;
      return (c.history || []).some(h => {
        const title = String(h?.[1] || '').toLowerCase();
        return title === 'confirmed' || title === 'confirmed locally';
      });
    });
  }
  async function repairConfirmedDrift() {
    const repairs = confirmedRepairCandidates();
    for (const c of repairs) {
      const expected = expectedFor(c);
      await queueSync(c,{
        type:'confirm',
        date:c.induction,
        time:c.inductionTime || getDefaultInductionTime(),
        note:`Repairing missing official Confirmed status for ${c.induction} at ${c.inductionTime || getDefaultInductionTime()} from Recruitment Hub`,
        expected
      });
    }
  }

  async function refreshFromMbl(showToast = false) {
    if (refreshBusy) return;
    refreshBusy = true; setSyncUi('wait','🟠 MBL SYNCING…');
    try {
      const known = state.candidates.filter(c => c.mblId).map(c => c.mblId);
      const r = await window.mbl.refresh(known);
      if (!r?.ok) throw new Error(r?.error || 'Unable to refresh official MBL data.');
      state.connection = { ...(r.data.connection || {}), ok: true };
      mergeSnapshot(r.data);
      auditAttendanceAgainstMbl(true);
      updateSyncUiFromState();
      if (showToast) toast(unattendedOfficialMismatches().length
        ? 'MBL refreshed · saved attendance still needs official review'
        : 'Official MBL list refreshed');
      renderNav(); render();
      const repairs = confirmedRepairCandidates();
      if (repairs.length) setTimeout(()=>repairConfirmedDrift(),150);
      if ((state.syncQueue||[]).some(x=>x.status==='failed'||x.status==='pending')) setTimeout(()=>retrySyncQueue(false),150);
    } catch (e) {
      state.connection = { ok:false, state:/sign in|required|expired/i.test(e.message)?'signin':'offline', message:e.message };
      save(); setSyncUi('bad', state.connection.state === 'signin' ? '🔴 SIGN IN REQUIRED' : '🔴 MBL OFFLINE');
      if (showToast) toast(e.message || 'MBL refresh failed');
    } finally { refreshBusy = false; }
  }
  window.refreshFromMbl = refreshFromMbl;
  window.reviewSavedAttendanceV1153=function(id){
    const c=state.candidates.find(x=>String(x.id)===String(id));
    if(!c)return;
    const evidence=recordedAttendance(c);
    if(!evidence){toast('No saved YES/NO attendance record found. Nothing sent to MBL.');return;}
    if((state.syncQueue||[]).some(q=>q.candidateId===c.id&&isAttendanceWrite(q.action)&&q.status!=='done')){
      toast('This candidate already has a pending or review-required attendance update.');
      window.openSyncPanel();return;
    }
    const label=evidence.outcome==='attended'?'ATTENDED':'DID NOT ATTEND';
    const officialDate=parseApiDate(c.officialInduction);
    const warning=officialDate!==evidence.date
      ?'WARNING: The official booking is '+(officialDate||'unknown')+
        ' and differs from the local attendance date. MBL may require an administrator to correct the booking first.':'';
    if(!confirm('Review saved attendance for '+c.name+'\\n\\n'+
      'Hub recorded: '+label+' on '+evidence.date+'\\n'+
      'Official MBL currently: '+(c.officialCallStage||'unrecorded')+
      ' · booking '+(officialDate||'unknown')+'\\n\\n'+warning+
      '\\n\\nRetry ONLY this saved outcome on official MBL? No rescheduling or other changes will be made.'))return;
    queueSync(c,{type:evidence.outcome,attendanceDate:evidence.date,expected:expectedFor(c)})
      .then(result=>{
        auditAttendanceAgainstMbl(false);
        renderSyncModal();render();updateSyncUiFromState();
        if(result?.error)toast('Official MBL rejected or needs review — saved outcome remains protected.');
        else toast(c.name+' attendance confirmed on official MBL');
      });
  };
  window.copyAttendanceDiscrepanciesV1153=function(){
    const issues=unattendedOfficialMismatches();
    if(!issues.length){toast('No unqueued attendance discrepancies to copy');return;}
    const message=['Official MBL attendance correction needed — HULL',
      'Hub attendance is recorded locally but official MBL still shows a different call stage.',
      'Please verify the original induction records and correct these official attendance outcomes:',
      ...issues.map(x=>x.name+' — '+(x.outcome==='attended'?'ATTENDED':'NOT ATTENDED')+
        ' on '+x.date+'; official '+x.official+
        '; booked '+(parseApiDate(x.officialDate)||'unknown')),
      'Do not mark any candidate as absent without checking the actual attendance record.'].join('\\n');
    copyText(message,'Attendance correction report copied');
  };

  async function connectMbl() {
    setSyncUi('wait','🟠 WAITING FOR SIGN IN…');
    const r = await window.mbl.connect();
    if (!r?.ok) { state.connection = r?.connection || {ok:false,state:'signin',message:r?.error}; save(); updateSyncUiFromState(); toast(r?.error || 'MBL sign-in failed'); return; }
    state.connection = r.connection; save(); toast('Connected to official MBL'); closeModal('syncModal'); await refreshFromMbl(true);
  }
  window.connectMbl = connectMbl;
  async function disconnectMbl() { if (!confirm('Disconnect Recruitment Hub from official MBL?')) return; await window.mbl.disconnect(); state.connection={ok:false,state:'signin',message:'Sign in required'};save();updateSyncUiFromState();render();openSyncPanel(); }
  window.disconnectMbl = disconnectMbl;

  async function queueSync(c, action) {
    if (!c?.mblId) { c.localOnly = true; c.syncState = 'local'; save(); render(); return { localOnly:true }; }
    action.expected = action.expected || expectedFor(c);
    if(isAttendanceWrite(action)){
      const chosen=action.type==='not_attended'?'not_attended':'attended';
      const recorded=recordedAttendance(c);
      const date=action.attendanceDate||c.historicalDateCorrection?.date||
        (recorded?.outcome===chosen?recorded.date:null)||
        c.lastInduction||c.induction||parseApiDate(c.officialInduction)||parseApiDate(action.expected.induction);
      const record=localAttendanceRecord(c,chosen,date);
      if(record)action.attendanceDate=record.date;
    }
    const entry = { id:`s${Date.now()}${Math.random().toString(16).slice(2)}`, candidateId:c.id, mblId:c.mblId, action, createdAt:new Date().toISOString(), status:'pending' };
    state.syncQueue.push(entry); c.syncState='pending'; save(); updateSyncUiFromState();
    if(futureOfficialAttendanceConflict(c,action)){
      entry.status='review';
      entry.error=attendanceReviewMessage(c,action);
      entry.reviewReason='Attendance date conflicts with future official booking';
      c.syncState='failed';save();updateSyncUiFromState();render();
      return {error:entry.error,needsReview:true};
    }
    try {
      let r = await window.mbl.action({ mblId:c.mblId, ...action });
      if (!r?.ok) throw new Error(r?.error || 'Official sync failed');
      if (r.data?.conflict) {
        const cur = r.data.current || {};
        if(isAttendanceWrite(action)){
          entry.status='review';
          entry.error='Official booking or call stage changed before attendance was accepted';
          entry.reviewReason='MBL record changed; review attendance against the booking';
          c.syncState='failed';save();updateSyncUiFromState();render();
          return {error:entry.error,needsReview:true};
        }
        const useMine = confirm(`${c.name} changed on the official MBL list since your last refresh.\n\nOfficial status: ${cur.callStage || cur.stage || 'unknown'}\nOfficial induction: ${cur.induction || 'none'}\n\nPress OK to apply your change anyway, or Cancel to keep the official MBL change.`);
        if (!useMine) {
          mergeOneOfficial(c,{mblId:c.mblId,name:cur.name||c.name,phone:cur.phone||c.phone,email:cur.email||c.email,applied:cur.applied,source:cur.source,officialStage:cur.stage,officialCallStage:cur.callStage,officialInduction:cur.induction,attempts:cur.callAttempts||0});
          state.syncQueue = state.syncQueue.filter(x=>x.id!==entry.id); c.syncState='synced'; save(); render(); toast('Kept the official MBL change'); return r.data;
        }
        r = await window.mbl.action({ mblId:c.mblId, ...action, force:true });
        if (!r?.ok) throw new Error(r?.error || 'Official sync failed');
      }
      entry.status='done'; state.syncQueue=state.syncQueue.filter(x=>x.id!==entry.id); c.syncState='synced'; c.lastSyncedAt=new Date().toISOString();
      const v = r.data?.verified?.candidate || r.data?.verified?.candidate;
      if (v) { c.officialStage=v.stage||c.officialStage;c.officialCallStage=v.callStage||null;c.officialInduction=v.induction||null;c.officialAttempts=Number(v.callAttempts||c.officialAttempts||0); }
      if(isAttendanceWrite(action))c.attendanceSync='verified';
      auditAttendanceAgainstMbl(false);
      save(); updateSyncUiFromState(); setTimeout(()=>refreshFromMbl(false),1200); return r.data;
    } catch (e) {
      entry.status=attendanceNeedsManualReview(action,e.message)?'review':'failed';
      entry.error=e.message;
      if(entry.status==='review')entry.reviewReason='Official attendance stage rejected';
      c.syncState='failed';
      if(isAttendanceWrite(action))c.attendanceSync='review';
      auditAttendanceAgainstMbl(false);
      save();updateSyncUiFromState();
      toast(entry.status==='review'
        ?`${c.name}: attendance needs official review — automatic retry paused`
        :`${c.name}: saved here · official sync pending`);
      return {error:e.message,needsReview:entry.status==='review'};
    }
  }
  function syncActionLabel(a={}) {
    const labels={no_answer:'No Answer',declined:'Not Interested',answered:'Will Let Us Know / Spoke To',confirm:'Confirm induction',correct:'Status correction',attended:'Attended',not_attended:'Not Attended',not_proceeding:'Not Proceeding',not_meeting_requirements:"Doesn't Meet Requirements",note:'Add note'};
    return labels[a.type] || a.type || 'Official update';
  }
  async function retrySyncQueue(showToast=true, onlyId=null) {
    // Review entries never run on the background timer or in Retry All.
    holdRejectedAttendanceWrites();
    const list = [...(state.syncQueue || [])].filter(x => onlyId
      ? x.id===onlyId && ['failed','pending','review'].includes(x.status)
      : x.status==='failed'||x.status==='pending');
    let cleared=0, failed=0;
    for (const q of list) {
      const c = state.candidates.find(x=>x.id===q.candidateId);
      const mblId = c?.mblId || q.mblId;
      if (!mblId) {
        q.status='failed'; q.error='Missing official MBL candidate ID'; failed++; continue;
      }
      if(c&&futureOfficialAttendanceConflict(c,q.action)){
        q.status='review';
        q.error=attendanceReviewMessage(c,q.action);
        q.reviewReason='Attendance date conflicts with future official booking';
        c.syncState='failed';failed++;continue;
      }
      q.status='pending'; q.error=''; if(c)c.syncState='pending'; save();
      try {
        const r = await window.mbl.action({mblId,...q.action});
        if(!r?.ok) throw new Error(r?.error || 'Official sync failed');
        if(r.data?.conflict) {
          const cur=r.data.current||{};
          q.status='failed';
          q.error=`Official record changed: ${cur.callStage||cur.stage||'unknown'}${cur.induction?` · ${cur.induction}`:''}`;
          if(c)c.syncState='failed'; failed++; continue;
        }
        state.syncQueue=state.syncQueue.filter(x=>x.id!==q.id);
        if(c){c.syncState='synced';c.lastSyncedAt=new Date().toISOString();
          if(isAttendanceWrite(q.action))c.attendanceSync='verified';}
        cleared++;
      } catch(e){
        q.error=e.message||'Official sync failed';
        q.status=attendanceNeedsManualReview(q.action,q.error)?'review':'failed';
        if(q.status==='review')q.reviewReason='Official MBL stage transition rejected';
        if(c)c.syncState='failed';failed++;
      }
    }
    auditAttendanceAgainstMbl(false);
    save(); updateSyncUiFromState(); renderSyncModal(); if(currentPage==='settings')render();
    if(showToast){
      if(cleared && !failed) toast(`${cleared} pending change${cleared===1?'':'s'} synced`);
      else if(cleared && failed) toast(`${cleared} synced · ${failed} still need attention`);
      else if(failed) toast(`${failed} pending change${failed===1?'':'s'} still need attention`);
      else toast('No pending changes');
    }
  }
  window.retrySyncQueue = retrySyncQueue;
  window.retryReviewedAttendanceWrite=function(id){
    const q=(state.syncQueue||[]).find(x=>x.id===id);
    if(!q||q.status!=='review')return;
    if(!confirm('Retry this attendance update after checking the official booking?\\n\\nMBL may reject it again if the date/status mismatch remains.'))return;
    return retrySyncQueue(true,id);
  };
  window.reviewAttendanceSyncCandidate=function(id){
    const q=(state.syncQueue||[]).find(x=>x.id===id);
    const c=q&&state.candidates.find(x=>x.id===q.candidateId);
    if(!c){toast('Candidate not found on this device');return;}
    closeModal('syncModal');
    openProfile(c.id);
  };
  window.discardSyncItem=function(id){
    const q=(state.syncQueue||[]).find(x=>x.id===id); if(!q)return;
    const c=state.candidates.find(x=>x.id===q.candidateId);
    const mismatchWarning=q.status==='review'&&isAttendanceWrite(q.action)
      ? '\\n\\nYour local attendance record may still differ from official MBL. Discarding will NOT correct the official booking or attendance status.'
      : '';
    if(!confirm(`Discard this pending ${syncActionLabel(q.action)} update?\n\nThis only removes the queued write from Recruitment Hub. It will not change the official MBL record.${mismatchWarning}`))return;
    state.syncQueue=state.syncQueue.filter(x=>x.id!==id);
    if(c)c.syncState='synced';
    save();updateSyncUiFromState();renderSyncModal();if(currentPage==='settings')render();
  };

  function syncMini(c) {
    if (!c.mblId) return '<div class="sync-state-mini local-chip">● Local — not yet on MBL</div>';
    if (c.syncState==='failed') return '<div class="sync-state-mini failed-chip">● Official sync failed — queued</div>';
    if (c.syncState==='pending') return '<div class="sync-state-mini pending-chip">● Syncing to official MBL…</div>';
    return '<div class="sync-state-mini live-chip">● Official MBL record linked</div>';
  }

  async function ensureOfficialDetails(c, force=false) {
    if (!c?.mblId || detailsBusy.has(c.id)) return;
    const previousIdentityVersion = 2;
    const identityCacheStale = Number(c.previousIdentityVersion || 0) < previousIdentityVersion;
    if (!force && !identityCacheStale && c.officialDetailsAt && Date.now() - new Date(c.officialDetailsAt).getTime() < 120000) return;
    detailsBusy.add(c.id);
    try {
      const r = await window.mbl.details({mblId:c.mblId,email:c.email,phone:c.phone});
      if (r?.ok) {
        for (const n of r.data.notes || []) if (n && !(c.notes||[]).includes(n)) (c.notes||(c.notes=[])).push(n);
        for (const t of r.data.timeline || []) addHistoryOnce(c, t.at || '', `MBL · ${t.title || t.kind || 'Activity'}`, t.detail || '');
        c.previousApplications = r.data.previousApplications || [];
        c.previousIdentityVersion = previousIdentityVersion;
        c.previousChecked = true; c.officialDetailsAt = new Date().toISOString(); save();
        if ((currentPage==='profile'&&profileId===c.id)||(currentPage==='callmode'&&callCandidates()[state.callIndex]?.id===c.id)) render();
      }
    } catch {} finally { detailsBusy.delete(c.id); }
  }

  function friendlyPriorOutcome(v){
    const map={answered:'Spoke to / Answered',booked:'Booked',confirmed:'Confirmed',rescheduled:'Rescheduled',no_answer:'No Answer',not_attended:'Not Attended / No Show',declined:'Not Coming / Declined',not_meeting_requirements:"Doesn't Meet Requirements",attended:'Attended',hired:'Hired',not_hired:'Not Hired'};
    return map[String(v||'').toLowerCase()] || String(v||'Previous application').replace(/_/g,' ');
  }
  function profilePreviousButton(c){
    if(!c.mblId)return '';
    const n=(c.previousApplications||[]).length;
    if(n)return `<button class="profile-prior-btn found" onclick="openPreviousApplications(${c.id})"><b>↺ Previous applications</b><span>${n} found · View →</span></button>`;
    if(c.previousChecked)return `<button class="profile-prior-btn none" onclick="checkPreviousApplications(${c.id})"><b>↺ Previous applications</b><span>None found · Recheck</span></button>`;
    return `<button class="profile-prior-btn" onclick="checkPreviousApplications(${c.id})"><b>↺ Previous applications</b><span>Check official MBL →</span></button>`;
  }
  window.checkPreviousApplications=async function(id){
    const c=state.candidates.find(x=>x.id===id);if(!c||!c.mblId)return;
    toast('Checking previous MBL applications…');
    await ensureOfficialDetails(c,true);
    const n=(c.previousApplications||[]).length;
    if(n)window.openPreviousApplications(id); else toast('No previous MBL applications found');
  };
  window.openPreviousApplications=function(id){
    const c=state.candidates.find(x=>x.id===id);if(!c)return;
    const apps=(c.previousApplications||[]).slice().reverse();
    document.getElementById('previousAppsTitle').textContent=`${c.name} · Previous applications`;
    const body=document.getElementById('previousAppsBody');
    if(!apps.length){body.innerHTML='<div class="empty">No previous applications are currently linked to this candidate. Use Recheck to query official MBL again.</div>';openModal('previousAppsModal');return;}
    body.innerHTML=`<div class="sub">${apps.length} earlier application${apps.length===1?'':'s'} found on official MBL. Any recorded reason, notes and timeline are shown below.</div>${apps.map(p=>{const tl=(p.timeline||[]).slice().reverse();const reason=p.reason||'';return `<div class="prior-app-detail"><div class="prior-app-head"><div><b>${esc(friendlyPriorOutcome(p.outcome))}</b>${p.id?`<div class="sub" style="margin-top:2px">Official record ${esc(p.id)}</div>`:''}</div><span class="prior-app-date">Applied ${esc(p.date||'Unknown')}</span></div><div class="prior-app-meta"><div><span>Final / last status</span><strong>${esc(friendlyPriorOutcome(p.callStage||p.stage||p.outcome))}</strong></div><div><span>Induction</span><strong>${esc(p.induction||'No induction date recorded')}</strong></div></div><div class="prior-reason ${reason?'':'none'}"><b>${reason?'Reason / outcome':'Reason'}</b><br>${esc(reason||'No explicit reason is recorded on MBL for this application.')}</div>${(p.notes||[]).length?`<div style="margin-top:9px"><div class="history-section-title">Notes</div>${p.notes.map(n=>`<div class="saved-note">${esc(n)}</div>`).join('')}</div>`:''}${tl.length?`<div class="history-section-title">Application history</div><div class="prior-timeline">${tl.map(t=>`<div class="prior-timeline-row"><time>${esc(t.at||'')}</time><div><b>${esc(t.title||'Activity')}</b>${t.detail?`<p>${esc(t.detail)}</p>`:''}</div></div>`).join('')}</div>`:''}</div>`;}).join('')}<button class="smallbtn" style="width:100%;margin-top:10px" onclick="closeModal('previousAppsModal');checkPreviousApplications(${id})">↻ Recheck official MBL</button>`;
    openModal('previousAppsModal');
  };
  renderProfile = function(el) {
    originalRenderProfile(el); const c=state.candidates.find(x=>x.id===profileId); if(!c)return;
    const card=el.querySelector('.profile-grid .card'); if(card){const d=document.createElement('div');d.innerHTML=syncMini(c)+profilePreviousButton(c);card.appendChild(d)}
    ensureOfficialDetails(c);
  };
  renderCallMode = function(el) { originalRenderCallMode(el); const q=callCandidates(),c=q[state.callIndex]; if(c) ensureOfficialDetails(c); };

  const REQUIREMENT_REASONS = [
    ['licence','Licence / driving record'],
    ['right_to_work','Right to work'],
    ['documents','Documents'],
    ['background_check','Background check'],
    ['experience','Experience'],
    ['other','Other']
  ];
  window.openRequirementsFail=function(id){
    const c=state.candidates.find(x=>x.id===id);if(!c)return;
    window.__requirementsCandidateId=id;window.__requirementsReason='';
    document.getElementById('requirementsTitle').textContent=`${c.name} · Doesn't meet requirements`;
    document.getElementById('requirementsBody').innerHTML=`<div class="sub">Choose the reason. The candidate stays fully searchable and all previous notes, contract history and induction history are retained.</div><div class="requirements-grid">${REQUIREMENT_REASONS.map(([v,l])=>`<button class="act" id="req-${v}" onclick="selectRequirementReason('${v}')">${l}</button>`).join('')}</div><textarea id="requirementsNote" class="requirements-note" placeholder="Optional note, e.g. IN10 found during checks..."></textarea><button class="cta red" style="width:100%;margin-top:9px" onclick="confirmRequirementsFail()">Mark Doesn't Meet Requirements</button>`;
    openModal('requirementsModal');
  };
  window.selectRequirementReason=function(reason){
    window.__requirementsReason=reason;document.querySelectorAll('#requirementsBody .requirements-grid button').forEach(b=>b.classList.remove('active'));document.getElementById('req-'+reason)?.classList.add('active');
  };
  window.confirmRequirementsFail=function(){
    const id=window.__requirementsCandidateId,c=state.candidates.find(x=>x.id===id);if(!c)return;
    const reason=window.__requirementsReason,note=String(document.getElementById('requirementsNote')?.value||'').trim();
    if(!reason){toast('Choose why they do not meet requirements');return;}
    if(reason==='other'&&!note){toast('Add a note for Other');return;}
    const expected=expectedFor(c),wasSigned=c.status==='contract_signed'||!!c.contractSignedAt,wasStatus=c.status;
    snapshot(c.id);c.requirementsPreviousStatus=wasStatus;c.requirementsFailedAt=new Date().toISOString();c.requirementsReason=reason;c.requirementsNote=note;c.status='requirements_failed';c.proceeding=false;c.history=c.history||[];
    const reasonLabel=(REQUIREMENT_REASONS.find(x=>x[0]===reason)||[reason,reason])[1];
    c.history.push([nowStamp(),"Doesn't Meet Requirements",`${reasonLabel}${note?` · ${note}`:''}${wasSigned?' · Contract had already been signed':''}`]);
    removeFromActiveQueue(c.id);
    save();
    closeModal('requirementsModal');
    queueSync(c,{type:'not_meeting_requirements',reason,note,expected});
    toast(`${c.name} marked as not meeting requirements`);
    if(currentPage==='callmode') advanceAfterAction(); else render();
  };

  showQuickActions = function(id){
    const c=state.candidates.find(x=>x.id===id); if(!c)return;
    window.__quickCandidateId=id;
    const body=document.getElementById('quickActionsBody'), title=document.getElementById('quickActionsTitle');
    title.textContent=c.name;
    const canOutcome=!!(c.induction||c.officialInduction) && parseDMY(c.induction||parseApiDate(c.officialInduction))<=parseDMY(todayDMY());
    body.innerHTML=`<div class="sub">${esc(c.phone)} · ${esc(statusLabel(c))}</div><div class="quick-actions-grid"><button class="cta" onclick="quickActionConfirm(${id})">${c.status==='confirmed'?'Change induction':'Confirmed / choose date'}</button><button class="act" onclick="quickActionNoAnswer(${id})">No Answer</button><button class="act" onclick="quickActionDecline(${id})">Not Interested</button><button class="act" onclick="quickActionWillLetUsKnow(${id})">Will Let Us Know</button><button class="act" onclick="quickActionProfile(${id})">Open Profile</button><button class="act" style="grid-column:1/-1;border-color:#73303a;color:#ff9aa2" onclick="quickActionRequirements(${id})">Doesn't meet requirements</button>${canOutcome?`<button class="act" style="grid-column:1/-1" onclick="quickActionOutcome(${id})">Set induction outcome</button>`:''}</div><div class="quick-note-box"><b>Add note</b><textarea id="quickActionNote" placeholder="Add a note that stays on this candidate everywhere..."></textarea><button class="cta" style="width:100%;margin-top:8px" onclick="saveQuickActionNote(${id})">Save note</button></div>`;
    openModal('quickActionsModal');
  };
  window.quickActionConfirm=function(id){closeModal('quickActionsModal');openConfirm(id)};
  window.quickActionNoAnswer=function(id){closeModal('quickActionsModal');applyNoAnswer(id)};
  window.quickActionDecline=function(id){closeModal('quickActionsModal');setStatus(id,'not_interested','Not Interested','Candidate marked not interested')};
  window.quickActionWillLetUsKnow=function(id){closeModal('quickActionsModal');setStatus(id,'spoke_to','Will Let Us Know','Spoke to candidate — they will let us know')};
  window.quickActionProfile=function(id){closeModal('quickActionsModal');openProfile(id)};
  window.quickActionRequirements=function(id){closeModal('quickActionsModal');openRequirementsFail(id)};
  window.quickActionOutcome=function(id){closeModal('quickActionsModal');openInductionOutcome(id)};
  window.saveQuickActionNote=function(id){const n=document.getElementById('quickActionNote')?.value.trim();if(!n){toast('Type a note first');return}addNote(id,n);closeModal('quickActionsModal');toast('Note saved to candidate')};

  window.openInductionOutcome=function(id){
    const c=state.candidates.find(x=>x.id===id);if(!c)return;
    window.__outcomeCandidateId=id;
    const date=c.induction||parseApiDate(c.officialInduction)||'previous induction';
    document.getElementById('inductionOutcomeTitle').textContent=`${c.name} · ${date}`;
    document.getElementById('inductionOutcomeBody').innerHTML=`<div class="sub">Choose what actually happened. This will update your Hub and the official MBL record.</div><div class="outcome-grid"><button class="cta" onclick="setPastInductionOutcome(${id},'proceeding')">✓ Attended · proceeding<span class="outcome-help">Moves to Awaiting Contract and marks Attended on MBL</span></button><button class="act" onclick="setPastInductionOutcome(${id},'not_proceeding')">Attended · not proceeding<span class="outcome-help">Keeps attendance in your history and marks Not Hired on MBL</span></button><button class="act" onclick="setPastInductionOutcome(${id},'no_show')">Did not attend<span class="outcome-help">Moves to follow-up and marks Not Attended on MBL</span></button><button class="act" onclick="setPastInductionOutcome(${id},'change_date')">Move to another date<span class="outcome-help">Choose a future induction date</span></button><button class="act" style="grid-column:1/-1;border-color:#73303a;color:#ff9aa2" onclick="closeModal('inductionOutcomeModal');openRequirementsFail(${id})">Doesn't meet requirements<span class="outcome-help">Use for licence, right-to-work, documents or checks that fail after induction</span></button></div>`;
    openModal('inductionOutcomeModal');
  };
  window.setPastInductionOutcome=function(id,outcome){
    const c=state.candidates.find(x=>x.id===id);if(!c)return;
    if(outcome==='change_date'){closeModal('inductionOutcomeModal');closeModal('inductionDetailModal');openConfirm(id);return}
    const expected=expectedFor(c); snapshot(c.id); c.history=c.history||[]; const originalDate=c.induction||parseApiDate(c.officialInduction)||null;
    if(outcome==='proceeding'){
      const now=new Date().toISOString(); c.status='contract_pending';c.proceeding=true;c.docsSent=true;c.contractSentAt=c.contractSentAt||now;c.contractLastChecked=now;c.induction=originalDate;
      c.history.push([nowStamp(),'Attended','Induction outcome corrected / confirmed']);c.history.push([nowStamp(),'Contract stage started','Waiting for signed contract']);
      save(); closeModal('inductionOutcomeModal'); queueSync(c,{type:'attended',expected}); toast(`${c.name} marked attended · awaiting contract`);
    }else if(outcome==='not_proceeding'){
      c.status='not_proceeding';c.proceeding=false;c.induction=originalDate;c.history.push([nowStamp(),'Attended — Not Proceeding','Candidate attended but did not continue']);
      save();closeModal('inductionOutcomeModal');queueSync(c,{type:'not_proceeding',note:'Attended induction but chose not to proceed',expected});toast(`${c.name} marked not proceeding`);
    }else if(outcome==='no_show'){
      c.status='no_show';c.lastInduction=originalDate;c.induction=null;c.history.push([nowStamp(),'Not Attended','Previous induction outcome corrected']);
      save();closeModal('inductionOutcomeModal');queueSync(c,{type:'not_attended',expected});toast(`${c.name} marked not attended`);
    }
    closeModal('inductionDetailModal'); render();
  };

  applyNoAnswer = function(id) { const c=state.candidates.find(x=>x.id===id); const expected=expectedFor(c); originalApplyNoAnswer(id); queueSync(c,{type:'no_answer',expected}); };
  setStatus = function(id,status,title,detail) { const c=state.candidates.find(x=>x.id===id); const expected=expectedFor(c); originalSetStatus(id,status,title,detail); if(status==='not_interested')queueSync(c,{type:'declined',note:detail||'Candidate not interested',expected}); else if(status==='spoke_to')queueSync(c,{type:'answered',note:detail||'Spoke to candidate — they will let us know',expected}); };
  addNote = function(id,n) { const c=state.candidates.find(x=>x.id===id); originalAddNote(id,n); queueSync(c,{type:'note',note:n,expected:expectedFor(c)}); };
  undoLast = function() {
    if(!state.undo){toast('Nothing to undo');return}
    const target=structuredClone(state.undo.candidate); const c=state.candidates.find(x=>x.id===target.id); const mblId=c?.mblId; originalUndoLast();
    const restored=state.candidates.find(x=>x.id===target.id); if(mblId&&restored)queueSync(restored,{type:'correct',targetStatus:restored.status,date:restored.induction,time:getDefaultInductionTime(),note:'Recruitment Hub correction / undo',force:true,expected:expectedFor(restored)});
  };

  // Attendance check: allow a confirmed candidate to move their induction instead of forcing Yes/No.
  // Keep any Yes/No choices already made while the user temporarily opens the date picker.
  const baseOpenAttendance = openAttendance;
  openAttendance = function(keepSelections=false){
    const today=state.candidates.filter(c=>c.status==='confirmed'&&c.induction===todayDMY());
    if(!today.length){toast('No confirmed candidates for today');return}
    if(!keepSelections) attendanceTemp={};
    document.getElementById('attendanceList').innerHTML=today.map(c=>{
      const cur=attendanceTemp[c.id];
      return `<div class="attrow"><div><b>${esc(c.name)}</b><div class="sub">${esc(c.phone)}</div><div class="att-reschedule-note">If they asked to come another day, use Change date.</div></div><button class="yesno ${cur===true?'sel yes':''}" id="ay${c.id}" onclick="setAttend(${c.id},true)">YES</button><button class="yesno ${cur===false?'sel no':''}" id="an${c.id}" onclick="setAttend(${c.id},false)">NO</button><button class="att-change-date" onclick="startAttendanceDateChange(${c.id})">Change date</button></div>`;
    }).join('');
    openModal('attendanceModal');
  };
  window.openAttendance=openAttendance;

  window.startAttendanceDateChange=async function(id){
    const c=state.candidates.find(x=>x.id===id);if(!c)return;
    window.__attendanceOpeningId=id;
    window.__attendanceRescheduleId=id;
    window.__attendanceOldDate=c.induction||parseApiDate(c.officialInduction)||todayDMY();
    delete attendanceTemp[id];
    closeModal('attendanceModal');
    await openConfirm(id);
    const h=document.querySelector('#confirmModal .modalhead h3');if(h)h.textContent='Change Induction Date';
  };

  callPhone = function(id) { const c=state.candidates.find(x=>x.id===id); if(!c)return; const tel=String(c.phone||'').replace(/[^\d+]/g,''); if(!tel){toast('No phone number saved');return} window.mbl.openExternal('tel:'+tel); };
  textCandidate = function(id) { const c=state.candidates.find(x=>x.id===id); if(!c)return; const tel=String(c.phone||'').replace(/[^\d+]/g,''); if(!tel){toast('No phone number saved');return} window.mbl.openExternal('sms:'+tel); };

  const baseDesktopOpenConfirm = openConfirm;
  let confirmCalendarMonth=null;
  let confirmCalendarSessions={};

  function confirmDateAllowed(d){
    const now=new Date();
    const day=new Date(d.getFullYear(),d.getMonth(),d.getDate());
    const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
    // Keep today selectable for the whole day. Real-world walk-ins and late attendance
    // corrections can happen after the scheduled induction time (normally 10:45).
    // Past dates (including Sundays) can be selected for a correction, not a new MBL booking.
    const earliest=new Date(today.getFullYear()-1,today.getMonth(),today.getDate());
    return day>=earliest && (day<=today || d.getDay()!==0);
  }

  function renderConfirmCalendar(){
    const host=document.getElementById('sessionChoices'); if(!host||!confirmCalendarMonth)return;
    const year=confirmCalendarMonth.getFullYear(),month=confirmCalendarMonth.getMonth();
    const first=new Date(year,month,1),last=new Date(year,month+1,0);
    const leading=(first.getDay()+6)%7;
    const cells=[];
    for(let i=0;i<leading;i++)cells.push('<button class="confirm-cal-day empty" disabled></button>');
    for(let day=1;day<=last.getDate();day++){
      const d=new Date(year,month,day),ds=formatDate(d),allowed=confirmDateAllowed(d);
      const sess=confirmCalendarSessions[ds]||null;
      const selected=selectedSession===ds;
      cells.push(`<button class="confirm-cal-day ${allowed?'':'disabled'} ${selected?'selected':''}" ${allowed?`onclick="chooseCalendarSession('${ds}')"`:'disabled'}><span class="daynum">${day}</span>${sess?'<span class="mbl-dot" title="Official MBL session exists"></span>':''}</button>`);
    }
    const selectedSess=selectedSession?confirmCalendarSessions[selectedSession]:null;
    const selectedDate=selectedSession?parseDMY(selectedSession):null;
    const summary=selectedSession
      ? `<div class="confirm-cal-selected"><b>${longDayDate(selectedDate)} ${selectedDate.getFullYear()}</b> · ${formatTime12(getDefaultInductionTime())} · HULL / DHU2${selectedSess?.time&&selectedSess.time!==getDefaultInductionTime()?`<div style="color:#d7a95b;margin-top:3px">Official MBL currently ${formatTime12(selectedSess.time)}</div>`:''}</div>`
      : '<div class="confirm-cal-selected">Select a date. Past Sundays are available for corrections; future Sundays are disabled.</div>';
    host.innerHTML=`<div class="confirm-calendar"><div class="confirm-cal-head"><b>${first.toLocaleDateString('en-GB',{month:'long',year:'numeric'})}</b><div class="confirm-cal-nav"><button onclick="moveConfirmMonth(-1)">‹</button><button onclick="moveConfirmMonth(1)">›</button></div></div><div class="confirm-cal-grid">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(x=>`<div class="confirm-cal-dow">${x}</div>`).join('')}${cells.join('')}</div>${summary}</div>`;
  }

  window.moveConfirmMonth=function(delta){
    const next=new Date(confirmCalendarMonth.getFullYear(),confirmCalendarMonth.getMonth()+delta,1);
    const now=new Date(),floor=new Date(now.getFullYear()-1,now.getMonth(),1);
    if(next<floor)return;
    confirmCalendarMonth=next;renderConfirmCalendar();
  };

  window.chooseCalendarSession=function(date){
    selectedSession=date;
    const s=confirmCalendarSessions[date]||null;
    selectedSessionMeta={sessionId:s?.id||null,officialTime:s?.time||null};
    const submit=document.getElementById('confirmSessionBtn');
    if(submit)submit.textContent=parseDMY(date)<parseDMY(todayDMY())?'Correct historical date':'Confirm Induction';
    renderConfirmCalendar();
  };

  openConfirm = async function(id) {
    const fromAttendance = window.__attendanceOpeningId===id;
    if(!fromAttendance){window.__attendanceRescheduleId=null;window.__attendanceOldDate=null;}
    window.__attendanceOpeningId=null;
    currentConfirmId=id;selectedSession=null;selectedSessionMeta=null;lastConfirmedDate=null;lastConfirmedCandidateId=null;
    const picker=document.getElementById('confirmPicker'),success=document.getElementById('confirmSuccess');if(picker)picker.style.display='block';if(success)success.classList.remove('show');
    const help=picker?.querySelector('.sub');if(help)help.textContent='Choose an upcoming date to book, or a past date to correct an attendance record. Past corrections stay in the Hub and do not rebook MBL. Only future Sundays are disabled.';
    document.getElementById('confirmSessionBtn').textContent='Confirm Induction';
    document.getElementById('copyConfirmationBtn').style.display='';
    window.__historicalCorrectionDate=null;
    const c=state.candidates.find(x=>x.id===id);document.getElementById('confirmCandidate').innerHTML=`<div class="candtop"><div class="bigavatar">${initials(c.name)}</div><div><b style="font-size:16px">${esc(c.name)}</b><div class="email">${esc(c.phone)}</div>${syncMini(c)}</div></div>`;
    confirmCalendarSessions={};
    document.getElementById('sessionChoices').innerHTML='<div class="empty" style="padding:18px">Loading induction calendar…</div>';openModal('confirmModal');
    if(c.mblId){
      try{
        const r=await window.mbl.openSessions(c.mblId);
        if(r?.ok)for(const s of (r.data.sessions||[])){const ds=parseApiDate(s.date);if(ds)confirmCalendarSessions[ds]=s;}
      }catch{}
    }
    const now=new Date();
    const base=(c.status==='confirmed'&&c.induction)?parseDMY(c.induction):now;
    const baseMonth=new Date(base.getFullYear(),base.getMonth(),1);
    const nowMonth=new Date(now.getFullYear(),now.getMonth(),1);
    const oldestMonth=new Date(now.getFullYear()-1,now.getMonth(),1);
    confirmCalendarMonth=baseMonth>=oldestMonth?baseMonth:nowMonth;
    renderConfirmCalendar();
  };
  document.getElementById('confirmSessionBtn').onclick=()=>{
    if(!selectedSession){toast('Choose an induction date');return}
    if(parseDMY(selectedSession)<parseDMY(todayDMY())){correctHistoricalInductionDateV1134(currentConfirmId,selectedSession);return;}
    const c=state.candidates.find(x=>x.id===currentConfirmId);const expected=expectedFor(c);const chosenTime=getDefaultInductionTime();snapshot(c.id);c.status='confirmed';c.induction=selectedSession;c.inductionTime=chosenTime;c.attempts=0;c.history.push([nowStamp(),'Confirmed',`Induction booked for ${selectedSession} at ${chosenTime}`]);removeFromActiveQueue(c.id);lastConfirmedDate=selectedSession;lastConfirmedCandidateId=c.id;save();
    const attendanceMove = window.__attendanceRescheduleId===c.id;
    if(attendanceMove){
      const oldDate=window.__attendanceOldDate||'today';
      c.history.push([nowStamp(),'Induction date changed',`${oldDate} → ${selectedSession} from attendance check`]);
    }
    document.getElementById('confirmPicker').style.display='none';document.getElementById('confirmSuccess').classList.add('show');const d=parseDMY(selectedSession);document.getElementById('confirmSuccessTitle').textContent=attendanceMove?`${firstName(c.name)} moved`:`${firstName(c.name)} confirmed`;document.getElementById('confirmSuccessText').textContent=`${longDayDate(d)} ${d.getFullYear()} at ${formatTime12(chosenTime)} · ready to copy their confirmation message.`;document.getElementById('confirmedNextBtn').innerHTML=attendanceMove?'2&nbsp;&nbsp;Back to Attendance →':'2&nbsp;&nbsp;Next Candidate →';toast(`${c.name} ${attendanceMove?'moved':'confirmed'} for ${selectedSession}`);
    const matchingOfficialTime=selectedSessionMeta?.officialTime===chosenTime; queueSync(c,{type:'confirm',date:selectedSession,time:chosenTime,sessionId:matchingOfficialTime?(selectedSessionMeta?.sessionId||null):null,note:attendanceMove?`Induction moved from ${window.__attendanceOldDate||'previous date'} to ${selectedSession} at ${chosenTime} from Recruitment Hub attendance check`:`Confirmed for ${selectedSession} at ${chosenTime} in Recruitment Hub`,expected});
  };

  document.getElementById('confirmedNextBtn').onclick=()=>{
    const returnToAttendance=!!window.__attendanceRescheduleId;
    window.__attendanceRescheduleId=null;window.__attendanceOldDate=null;
    closeModal('confirmModal');
    document.getElementById('confirmedNextBtn').innerHTML='2&nbsp;&nbsp;Next Candidate →';
    const h=document.querySelector('#confirmModal .modalhead h3');if(h)h.textContent='Confirm Induction';
    if(returnToAttendance){render();setTimeout(()=>openAttendance(true),80);return;}
    if(currentPage==='callmode') advanceAfterAction(); else render();
  };

  buildDayReminder = function(c){
    const dateStr=c?.induction||parseApiDate(c?.officialInduction)||todayDMY();
    const tm=getDefaultInductionTime();
    return `Good morning,

Just a reminder that your MBL Delivery Driver induction is today at ${formatTime12(tm)} at the Amazon DHU2 depot.

📍 Location:
MBL / Amazon DHU2
Brickyard Lane
North Ferriby
HU14 3HB

Please remember to bring the following documents:

• Driving licence
• Passport/visa or full birth certificate
• Proof of address dated within the last 3 months
• Proof of National Insurance number

When you arrive, please let security know that you are here for an MBL induction.

Please reply to confirm that you’re still attending today.

Thank you,
Reece
MBL Logistics`;
  };
  copySessionReminder = function(){copyText(buildDayReminder({induction:todayDMY(),officialInduction:`${apiDateOnly(todayDMY())} ${inductionTimeForCandidate(null,todayDMY())}`}), 'Induction reminder copied')};

  openInductionDetails = function(dateStr){
    const d=parseDMY(dateStr), people=inductionPeopleForDate(dateStr), today=dateStr===todayDMY(), pastOrToday=d<=parseDMY(todayDMY());
    const confirmedCount=confirmedInductionPeopleForDate(dateStr).length;
    const tm=getDefaultInductionTime(), mismatch=timeMismatchText(dateStr);
    document.getElementById('inductionDetailTitle').textContent=d.toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long'});
    document.getElementById('inductionDetailBody').innerHTML=`<div class="session-summary"><div><h4>${formatTime12(tm)} · Amazon DHU2</h4><p>Brickyard Lane · North Ferriby · HU14 3HB${mismatch?` · <span style=\"color:#d7a95b\">${mismatch}</span>`:''}</p></div><div class="session-summary-actions">${today&&people.length?`<button class="session-reminder-top" onclick="copySessionReminder()">📋 Copy reminder</button>`:''}<div class="session-count-pill"><b>${confirmedCount}</b><span>Confirmed</span></div></div></div><div class="session-attendees">${people.map(c=>`<div class="session-attendee"><div class="session-person"><div class="session-avatar">${initials(c.name)}</div><div class="session-person-text"><b>${esc(c.name)}</b><button class="sms-number" onclick="textCandidate(${c.id})" title="Open SMS in Windows / Phone Link">${esc(c.phone)}</button>${pastOrToday?`<span class="session-status-chip">${esc(statusLabel(c))}</span>`:''}</div></div><div class="session-row-actions">${pastOrToday?`<button class="act" onclick="openInductionOutcome(${c.id})">Status</button>`:''}<button class="act" onclick="openProfile(${c.id});closeModal('inductionDetailModal')">Profile</button></div></div>`).join('')||'<div class="empty">No confirmed candidates for this induction.</div>'}</div>${today&&confirmedCount?`<div style="display:flex;gap:8px;margin-top:12px"><button class="cta red" style="flex:1" onclick="closeModal('inductionDetailModal');openAttendance()">12:00 Attendance Check</button></div>`:''}`;
    openModal('inductionDetailModal');
  };

  renderInductions = function(el){
    header('Inductions','Confirmed people only for future sessions; previous sessions keep their recorded outcomes.');
    const baseToday=parseDMY(todayDMY()), raw=[baseToday,...nextInductionDates(6)], seen=new Set(), sessions=raw.filter(d=>{const ds=formatDate(d);if(seen.has(ds))return false;seen.add(ds);return true});
    el.innerHTML=`<div class="induction-shell"><div class="rulestrip"><span class="rulepill"><strong>Confirmed only</strong> — unconfirmed bookings stay off the roster</span></div><div class="induction-grid">${sessions.map(d=>{const dd=formatDate(d),people=inductionPeopleForDate(dd),confirmed=confirmedInductionPeopleForDate(dd).length,isToday=dd===todayDMY(),tm=getDefaultInductionTime(),mismatch=timeMismatchText(dd);return `<div class="induction-panel ${isToday?'today-session':''}" onclick="openInductionDetails('${dd}')"><div class="induction-date"><div class="induction-datebox"><div><b>${d.getDate()}</b><span>${d.toLocaleDateString('en-GB',{month:'short'})}</span></div></div><div class="induction-meta"><b>${d.toLocaleDateString('en-GB',{weekday:'long'})} · ${formatTime12(tm)}</b><span>Amazon DHU2 · North Ferriby${mismatch?` · ${mismatch}`:''}</span></div></div><div class="induction-countline"><div class="count"><b>${confirmed}</b><span>confirmed attending</span></div></div><div class="attendee-preview">${people.slice(0,2).map(c=>`<div class="attendee-preview-row"><span>${esc(c.name)}</span><span>${esc(statusLabel(c))}</span></div>`).join('')}${people.length>2?`<div class="attendee-preview-row"><span>+ ${people.length-2} more</span><span>View all</span></div>`:''}${!people.length?'<div class="sub">No confirmed candidates yet</div>':''}</div><div class="induction-panel-footer"><span class="view-attendees">${people.length?'Open attendee list →':'Open session →'}</span></div></div>`}).join('')}</div></div>`;
  };

  saveAttendance = function(){
    const ids=Object.keys(attendanceTemp);if(!ids.length){toast('Mark at least one candidate');return}const attendedIds=[];
    ids.forEach(k=>{const c=state.candidates.find(x=>x.id===Number(k));const expected=expectedFor(c);snapshot(c.id);if(attendanceTemp[k]){c.status='attended';c.history.push([nowStamp(),'Attended','Induction completed']);attendedIds.push(c.id);queueSync(c,{type:'attended',expected});}else{c.status='no_show';c.induction=null;c.history.push([nowStamp(),'Not Attended','Added to weekly follow-up']);queueSync(c,{type:'not_attended',expected});}});
    save();closeModal('attendanceModal');if(attendedIds.length)startProceedFlow(attendedIds);else{toast('Attendance saved');render()}
  };
  setProceedDecision = function(proceeding){const c=state.candidates.find(x=>x.id===currentProceedId);const expected=c?expectedFor(c):null;originalSetProceedDecision(proceeding);if(c&&!proceeding)queueSync(c,{type:'not_proceeding',note:'Attended induction but chose not to proceed',expected});};

  let addCandidateCalendarMonth=null;
  function addCandidateDateAllowed(d){
    const now=new Date(),day=new Date(d.getFullYear(),d.getMonth(),d.getDate()),today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
    // A manual/inbound candidate may arrive as a same-day walk-in, so today must remain
    // selectable even after the scheduled induction time has passed.
    if(d.getDay()===0||day<today)return false;
    return true;
  }
  function renderAddCandidateCalendar(){
    const host=document.getElementById('addInductionCalendar'),hidden=document.getElementById('addInductionDate');if(!host||!hidden||!addCandidateCalendarMonth)return;
    const y=addCandidateCalendarMonth.getFullYear(),m=addCandidateCalendarMonth.getMonth(),first=new Date(y,m,1),last=new Date(y,m+1,0),leading=(first.getDay()+6)%7;
    const selected=hidden.value||'',officialByDate={};for(const s of (state.mblSessions||[])){const ds=parseApiDate(s.date);if(ds)officialByDate[ds]=s;}
    const cells=[];for(let i=0;i<leading;i++)cells.push('<button class="add-candidate-cal-day empty" disabled></button>');
    for(let day=1;day<=last.getDate();day++){const d=new Date(y,m,day),ds=formatDate(d),allowed=addCandidateDateAllowed(d),sess=officialByDate[ds]||null;cells.push(`<button class="add-candidate-cal-day ${allowed?'':'disabled'} ${selected===ds?'selected':''}" ${allowed?`onclick="selectAddCandidateDate('${ds}')"`:'disabled'}><span class="daynum">${day}</span>${sess?'<span class="mbl-dot" title="Official MBL session exists"></span>':''}</button>`);}
    let summary='<div class="add-candidate-cal-summary">No date selected — candidate will be added to To Call.</div>';
    if(selected){const d=parseDMY(selected),s=officialByDate[selected];summary=`<div class="add-candidate-cal-summary"><b>${longDayDate(d)} ${d.getFullYear()}</b> · ${formatTime12(getDefaultInductionTime())}${s?.time&&s.time!==getDefaultInductionTime()?`<div style="color:#d7a95b;margin-top:3px">Official MBL currently ${formatTime12(s.time)}</div>`:''}</div>`;}
    host.innerHTML=`<div class="add-candidate-cal"><div class="add-candidate-cal-head"><b>${first.toLocaleDateString('en-GB',{month:'long',year:'numeric'})}</b><div class="add-candidate-cal-nav"><button onclick="moveAddCandidateMonth(-1)">‹</button><button onclick="moveAddCandidateMonth(1)">›</button></div></div><div class="add-candidate-cal-grid">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(x=>`<div class="add-candidate-cal-dow">${x}</div>`).join('')}${cells.join('')}</div><button class="add-candidate-cal-none ${selected?'':'active'}" onclick="clearAddCandidateDate()">No date yet — add to To Call</button>${summary}</div>`;
  }
  window.moveAddCandidateMonth=function(delta){const now=new Date(),floor=new Date(now.getFullYear(),now.getMonth(),1),next=new Date(addCandidateCalendarMonth.getFullYear(),addCandidateCalendarMonth.getMonth()+delta,1);if(next<floor)return;addCandidateCalendarMonth=next;renderAddCandidateCalendar();};
  window.selectAddCandidateDate=function(date){document.getElementById('addInductionDate').value=date;renderAddCandidateCalendar();};
  window.clearAddCandidateDate=function(){document.getElementById('addInductionDate').value='';renderAddCandidateCalendar();};
  openAddCandidate = function(){
    ['addFirstName','addSurname','addEmail','addPhone'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
    const hidden=document.getElementById('addInductionDate');if(hidden)hidden.value='';
    const now=new Date();addCandidateCalendarMonth=new Date(now.getFullYear(),now.getMonth(),1);renderAddCandidateCalendar();openModal('addCandidateModal');setTimeout(()=>document.getElementById('addFirstName')?.focus(),50);
  };
  window.openAddCandidate=openAddCandidate;

  saveAddedCandidate = function(){
    const first=document.getElementById('addFirstName').value.trim(),surname=document.getElementById('addSurname').value.trim(),email=document.getElementById('addEmail').value.trim(),phone=document.getElementById('addPhone').value.trim(),induction=document.getElementById('addInductionDate').value;
    if(!first||!surname||!phone){toast('Enter first name, surname and phone number');return}
    const phoneKey=phone.replace(/\s/g,''),emailKey=email.toLowerCase();
    const duplicate=state.candidates.find(c=>((emailKey&&c.email&&(c.email||'').toLowerCase()===emailKey)||((c.phone||'').replace(/\s/g,'')===phoneKey)));
    if(duplicate&&!confirm(`${duplicate.name} may already exist. Add anyway?`))return;
    const c={id:nextLocalId(),mblId:null,localOnly:true,syncState:'local',name:`${first} ${surname}`,phone,email,applied:todayDMY(),status:induction?'confirmed':'to_call',attempts:0,source:'Manual / Inbound',notes:[],history:[[nowStamp(),'Added manually','Local candidate — not yet on MBL']],previousApplications:[],induction:induction||null};
    if(induction){c.inductionTime=getDefaultInductionTime();c.history.push([nowStamp(),'Confirmed locally',`Induction selected for ${induction} at ${getDefaultInductionTime()}`]);}
    state.candidates.push(c);save();closeModal('addCandidateModal');toast(`${c.name} added locally · not yet on MBL`);render();
  };

  enableContractNotifications = async function(){await window.mbl.notify('MBL Recruitment Hub','Contract reminders are enabled while the app is running.');toast('Desktop contract reminders enabled');};
  contractReminderSweep = function(){maintainContracts();const due=contractsDue();if(!due.length)return;const ready=due.filter(c=>!c.contractNotifiedAt||hoursSince(c.contractNotifiedAt)>=3);if(!ready.length)return;const now=new Date().toISOString();ready.forEach(c=>c.contractNotifiedAt=now);save();toast(`${ready.length} contract${ready.length===1?'':'s'} need checking`);window.mbl.notify('MBL Contract Check',`${ready.length} contract${ready.length===1?'':'s'} need checking in Dropbox.`);};

  function pendingLocalLeads(){return state.candidates.filter(c=>(c.localOnly||!c.mblId)&&!c.mblId);}
  window.openLocalLeadsPrompt=function(){
    const list=pendingLocalLeads(),body=document.getElementById('localLeadsBody');if(!body)return;
    body.innerHTML=list.length?`<div class="sub"><b style="color:#fff">${list.length} candidate${list.length===1?'':'s'} still need adding to the official MBL page.</b></div><div class="local-lead-list">${list.map(c=>`<div class="local-lead-row"><div><b>${esc(c.name)}</b><span>${esc(c.phone)}${c.email?' · '+esc(c.email):''}</span></div><button class="smallbtn" onclick="openProfile(${c.id});closeModal('localLeadsModal')">Profile</button></div>`).join('')}</div><div class="modalfoot"><button class="smallbtn" onclick="closeModal('localLeadsModal')">Later</button><button class="cta red" onclick="closeModal('localLeadsModal');go('candidates')">Open Candidates</button></div>`:'<div class="empty">No local candidates need adding to official MBL.</div>';
    openModal('localLeadsModal');
  };
  async function nightlyLocalLeadSweep(){
    const d=new Date();if(d.getHours()<22)return;const key=localStorage.getItem('mblLocalLeadPromptedDate')||'';const today=todayDMY();if(key===today)return;
    // Refresh first so candidates added to MBL by you or another manager are auto-linked
    // by an exact phone/email match and do not appear as false "missing" reminders.
    if(state.connection?.ok){try{await refreshFromMbl(false);}catch{}}
    const list=pendingLocalLeads();if(!list.length){localStorage.setItem('mblLocalLeadPromptedDate',today);return;}
    localStorage.setItem('mblLocalLeadPromptedDate',today);
    const msg=`${list.length} candidate${list.length===1?'':'s'} genuinely appear to be missing from the official MBL page.`;
    window.mbl.notify('MBL Recruitment Hub',msg);toast(msg);window.openLocalLeadsPrompt();
  }

  renderHome = function(el){
    originalRenderHome(el);
    const localMblCount=pendingLocalLeads().length;
    const strip=el.querySelector('.today-strip');
    if(strip&&!strip.querySelector('.local-to-mbl-chip')){const chip=document.createElement('div');chip.className='today-chip local-to-mbl-chip';chip.onclick=()=>window.openLocalLeadsPrompt();chip.innerHTML=`<b>${localMblCount}</b><span>${localMblCount===1?'needs':'need'} adding to MBL</span>`;strip.appendChild(chip);}
    const todayTime=getDefaultInductionTime();
    el.querySelectorAll('.mini-label').forEach(x=>{if(String(x.textContent||'').trim().startsWith('Today ·'))x.textContent=`Today · ${formatTime12(todayTime).replace(' AM','').replace(' PM','')}`;});
    if(!state.connection?.ok){const hero=el.querySelector('.home-lite-hero');if(hero){const b=document.createElement('div');b.className='connect-banner';b.innerHTML=`<div><b>Official MBL is not connected</b><span>Your local data is safe, but official calls and changes will not sync until you sign in.</span></div><button class="cta red" onclick="connectMbl()">Connect to MBL</button>`;hero.insertAdjacentElement('afterend',b)}}
    if((state.syncIssues||[]).length){const hero=el.querySelector('.home-lite-hero');if(hero){const b=document.createElement('div');b.className='sync-alert';b.innerHTML=`<div><b>⚠ ${(state.syncIssues||[]).length} official change${state.syncIssues.length===1?'':'s'} need mapping</b><span>MBL has a category your personal Hub does not currently use.</span></div><button class="smallbtn" onclick="openSyncPanel()">Review</button>`;hero.insertAdjacentElement('afterend',b)}}
    updateSyncUiFromState();
  };

  function renderSyncModal(){
    const body=document.getElementById('syncModalBody');if(!body)return;const pending=(state.syncQueue||[]).filter(x=>x.status!=='done');const issues=state.syncIssues||[];const account=state.connection?.account||{};
    const discrepancies=unattendedOfficialMismatches();
    const attendanceHtml=discrepancies.length
      ?`<div class="issue-row" style="border-color:#a4434d;background:#29181b">
        <b>⚠ ${discrepancies.length} saved attendance decision${discrepancies.length===1?'':'s'} NOT confirmed by MBL</b>
        <p>You already recorded these outcomes in the Hub, but the official call stages disagree. Your original YES/NO choices are protected; nothing has been changed or rebooked automatically. Review the saved evidence before retrying.</p>
        <div class="issue-controls"><button class="smallbtn" onclick="copyAttendanceDiscrepanciesV1153()">Copy correction report</button></div>
        </div>`+
        discrepancies.map(x=>`<div class="issue-row">
          <b>${esc(x.name)}</b>
          <p><strong>Hub: ${x.outcome==='attended'?'Attended':'Not attended'}</strong> on ${esc(x.date)}
          · official MBL: <span style="color:#ff9aa2">${esc(x.official)}</span>
          · booking: ${esc(parseApiDate(x.officialDate)||'unknown')}
          · evidence: ${x.source==='history'?'saved Hub history':'saved attendance record'}</p>
          <div class="issue-controls" style="flex-wrap:wrap">
            <button class="smallbtn" onclick="openProfile(${Number(x.candidateId)})">Review candidate</button>
            <button class="smallbtn" onclick="reviewSavedAttendanceV1153(${Number(x.candidateId)})">Retry saved outcome after review</button>
          </div>
        </div>`).join('')
      :'<div class="sub" style="margin:12px 0">No additional saved attendance mismatches found in local history.</div>';
    body.innerHTML=`<div class="sync-modal-grid"><div class="sync-kpi"><span>Status</span><b style="color:${state.connection?.ok?'#7ce0aa':'#ff8790'}">${state.connection?.ok?'● Connected':'● Not connected'}</b></div><div class="sync-kpi"><span>Account</span><b>${esc(account.name||'Reece Mark Arnold')}</b></div><div class="sync-kpi"><span>Depot</span><b>HULL</b></div><div class="sync-kpi"><span>Last refresh</span><b>${state.lastMblRefresh?new Date(state.lastMblRefresh).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'Never'}</b></div><div class="sync-kpi"><span>Pending writes</span><b>${pending.length}</b></div><div class="sync-kpi"><span>Unrecognised categories</span><b>${issues.length}</b></div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">${state.connection?.ok?`<button class="cta red" onclick="refreshFromMbl(true)">Refresh now</button><button class="smallbtn" onclick="disconnectMbl()">Disconnect</button>`:`<button class="cta red" onclick="connectMbl()">Connect to official MBL</button>`}${pending.some(q=>q.status!=='review')?`<button class="smallbtn" onclick="retrySyncQueue()">Retry recoverable pending</button>`:''}</div>
      ${pending.length?`<h3 style="font-size:13px;margin:12px 0 3px">Pending official updates</h3><div class="sub">Recoverable errors retry automatically. Attendance changes refused by MBL are paused until you review the official booking and local record.</div>${pending.map(q=>{const c=state.candidates.find(x=>x.id===q.candidateId);const review=q.status==='review';const officialDate=review?parseApiDate(c?.officialInduction||q.action?.expected?.induction||''):null;const localDate=review&&(c?.historicalDateCorrection?.date||(c?.status==='attended'?c.induction:null));const locked=review&&c&&futureOfficialAttendanceConflict(c,q.action);return `<div class="issue-row"><b>${esc(c?.name||q.mblId||'Unknown candidate')}</b><p><strong>${esc(syncActionLabel(q.action))}</strong>${q.error?` · <span style="color:#ff9aa2">${esc(q.error)}</span>`:''}</p>${review?`<p style="color:#ffce8c"><b>Needs review · automatic retry paused.</b> ${localDate?`Local attendance: ${esc(localDate)}. `:''}${officialDate?`Official booking: ${esc(officialDate)}. `:''}Check the original attendance record. A conflicting future booking needs official correction; don't assume the candidate missed induction. MBL has NOT confirmed the attendance change; the Hub retains local history.</p>`:''}<div class="issue-controls" style="flex-wrap:wrap">${review?`<button class="smallbtn" onclick="reviewAttendanceSyncCandidate('${esc(q.id)}')">Review candidate</button>${locked?'':`<button class="smallbtn" onclick="retryReviewedAttendanceWrite('${esc(q.id)}')">Retry after review</button>`}`:`<button class="smallbtn" onclick="retrySyncQueue(true,'${esc(q.id)}')">Retry</button>`}<button class="smallbtn" onclick="discardSyncItem('${esc(q.id)}')">Discard queued write</button></div></div>`}).join('')}`:''}
      <h3 style="font-size:13px;margin:14px 0 6px">Attendance verification · saved records</h3>${attendanceHtml}
      ${issues.length?`<h3 style="font-size:13px;margin:12px 0 3px">Unrecognised official categories</h3><div class="sub">Choose how your personal Hub should show these. The official MBL category itself is not changed.</div>${issues.map((x,i)=>`<div class="issue-row"><b>${esc(x.name)}</b><p>Official MBL category: <strong>${esc(x.officialStage)}</strong></p><div class="issue-controls"><select id="mapIssue${i}"><option value="">Choose local status…</option><option value="to_call">To Call</option><option value="spoke_to">Spoke To</option><option value="no_answer">No Answer — Retry</option><option value="confirmed">Confirmed</option><option value="not_interested">Not Interested</option><option value="archived">Archived</option><option value="attended">Attended</option><option value="no_show">Not Attended</option><option value="requirements_failed">Doesn't Meet Requirements</option><option value="__ignore__">Leave my local status unchanged</option></select><button class="cta" onclick="saveStatusMapping('${esc(x.officialStage)}','mapIssue${i}')">Save mapping</button></div></div>`).join('')}`:'<div class="sub" style="margin-top:12px">No unknown MBL categories need your attention.</div>'}`;
  }
  window.openSyncPanel=function(){renderSyncModal();openModal('syncModal');};
  window.saveStatusMapping=function(stage,selectId){const v=document.getElementById(selectId)?.value;if(!v){toast('Choose a local status first');return}state.statusMappings[stage]=v;state.syncIssues=(state.syncIssues||[]).filter(x=>x.officialStage!==stage);state.candidates.filter(c=>c.officialCallStage===stage).forEach(c=>{if(v!=='__ignore__')c.status=v});save();toast(`Saved mapping for ${stage}`);renderSyncModal();render();};

  function updateTopUpdateButton() {
    const b=document.getElementById('updateTopBtn'); if(!b)return;
    const u=state.latestUpdate;
    if(u?.available){b.classList.add('show');b.classList.remove('busy');b.textContent=`⬆ Update ${u.manifest.version}`;}
    else {b.classList.remove('show','busy');}
  }
  async function checkHubUpdate(showToast=false){
    try{
      const r=await window.mbl.checkUpdate();
      if(!r?.ok){if(showToast)toast(r?.error||'Could not check for updates');return r;}
      state.appVersion=r.currentVersion||state.appVersion;
      state.latestUpdate=r; save(); updateTopUpdateButton();
      if(showToast)toast(r.available?`Update ${r.manifest.version} is available`:`Recruitment Hub is up to date · ${state.appVersion}`);
      if(currentPage==='settings')render();
      return r;
    }catch(e){if(showToast)toast(`Update check failed: ${e.message}`);return {ok:false,error:e.message};}
  }
  window.checkHubUpdate=checkHubUpdate;
  async function installLatestUpdate(){
    const u=state.latestUpdate?.available?state.latestUpdate:await checkHubUpdate(true);
    if(!u?.ok||!u.available)return;
    const notes=String(u.manifest.notes||'').trim();
    if(!confirm(`Install Recruitment Hub ${u.manifest.version}?${notes?`\n\n${notes}`:''}\n\nThe app will restart automatically. Your local candidate data and MBL login are kept.`))return;
    const b=document.getElementById('updateTopBtn');if(b){b.classList.add('show','busy');b.textContent='Installing…';}
    const r=await window.mbl.installOnlineUpdate(u.manifest);
    if(!r?.ok){if(b){b.classList.remove('busy');b.textContent=`⬆ Update ${u.manifest.version}`;}toast(r?.error||'Update failed');}
  }
  window.installLatestUpdate=installLatestUpdate;
  renderSettings=function(el){
    header('Settings','Official MBL connection, workflow, display and app updates.');const pending=(state.syncQueue||[]).filter(x=>x.status!=='done').length;const scale=Math.round(getUiScale()*100);
    el.innerHTML=`<div class="card" style="max-width:900px"><h3>Official MBL Connection</h3><div class="info-row"><span>Status</span><span style="color:${state.connection?.ok?'#7ce0aa':'#ff8790'}">${state.connection?.ok?'Connected · live':'Not connected'}</span></div><div class="info-row"><span>Depot</span><span>HULL</span></div><div class="info-row"><span>Automatic refresh</span><span>Every 90 seconds</span></div><div class="info-row"><span>Pending changes</span><span>${pending}</span></div><div class="info-row"><span>Unknown official categories</span><span>${(state.syncIssues||[]).length}</span></div><div class="info-row"><span>Attendance needing official review</span><strong style="color:${unattendedOfficialMismatches().length?'#ff9797':'#a0e6b4'}">${unattendedOfficialMismatches().length} saved outcome${unattendedOfficialMismatches().length===1?'':'s'}</strong></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin:14px 0 22px">${state.connection?.ok?`<button class="cta red" onclick="refreshFromMbl(true)">Refresh from MBL</button>`:`<button class="cta red" onclick="connectMbl()">Connect to MBL</button>`}<button class="smallbtn" onclick="openSyncPanel()">Connection details</button>${(state.syncQueue||[]).some(x=>x.status==='failed'||x.status==='pending')?`<button class="smallbtn" onclick="retrySyncQueue()">Retry recoverable pending</button>`:''}</div><h3>Display</h3><div class="scale-control"><div class="scale-control-head"><div><b>UI Scale</b><span style="display:block;margin-top:3px">Change the size of text, buttons and panels.</span></div><strong>${scale}%</strong></div><div class="scale-options-desktop">${[100,125,150,175,200].map(v=>`<button class="scale-option ${scale===v?'active':''}" onclick="setDesktopScale(${v})">${v}%</button>`).join('')}</div><div class="scale-help">Tip: hold <b>Ctrl</b> and scroll the mouse wheel anywhere in the app to zoom in or out. Ctrl + 0 resets to 125%.</div></div><h3 style="margin-top:22px">Inductions</h3><div class="info-row"><span>Default induction time</span><span style="display:flex;align-items:center;gap:8px"><input id="defaultInductionTime" type="time" value="${getDefaultInductionTime()}" style="background:#0e1114;color:#fff;border:1px solid #384048;border-radius:7px;padding:7px 9px"><button class="smallbtn" onclick="saveDefaultInductionTime()">Save</button></span></div><div class="scale-help">Your Hub uses this as the working time for induction panels, messages and future confirmations. If MBL already has a different time for that date, the Hub shows the mismatch and future candidate confirmations are synced using your selected time. Existing MBL session times themselves cannot currently be edited through the available MBL tools.</div><h3 style="margin-top:22px">Workflow</h3><div class="info-row"><span>No Answer</span><span>2 attempts total → archived locally</span></div><div class="info-row"><span>Not interested / not proceeding</span><span>Declined on official MBL</span></div><div class="info-row"><span>Will Let Us Know</span><span>Spoke To / Answered on official MBL</span></div><div class="info-row"><span>Doesn't meet requirements</span><span>Reason saved here + Not Meeting Requirements on official MBL</span></div><div class="info-row"><span>Notes</span><span>Saved here + official MBL timeline</span></div><div class="info-row"><span>Manual candidates</span><span style="color:#ffc266">Local until MBL adds candidate creation</span></div><div class="info-row"><span>Contract checks</span><span>3h checks · 24h follow-up · 72h Quiet Pending</span></div><h3 style="margin-top:22px">App Updates</h3><div class="info-row"><span>Installed version</span><span>${esc(state.appVersion||'1.0.0')}</span></div><div class="info-row"><span>Update channel</span><span style="color:#7ce0aa">GitHub · automatic</span></div>${state.latestUpdate?.available?`<div class="update-notes"><b style="color:#fff">Version ${esc(state.latestUpdate.manifest.version)} available</b>${state.latestUpdate.manifest.notes?`<div style="margin-top:6px">${esc(state.latestUpdate.manifest.notes)}</div>`:''}</div><button class="cta red" onclick="installLatestUpdate()">Update & Restart</button>`:`<div class="sub" style="margin:10px 0">Recruitment Hub checks the release channel automatically. You can also check now.</div><button class="cta" onclick="checkHubUpdate(true)">Check for updates</button>`}<button class="smallbtn" style="margin-left:8px" onclick="installHubUpdate()">Install package manually…</button></div>`;
  };
  window.setDesktopScale=async function(percent){await changeUiScale(percent);toast(`UI scale ${percent}%`);if(currentPage==='settings')render();};

  window.saveDefaultInductionTime=function(){
    const el=document.getElementById('defaultInductionTime'); const v=String(el?.value||'').trim();
    if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)){toast('Choose a valid induction time');return;}
    localStorage.setItem('mblDefaultInductionTime',v); state.defaultInductionTime=v; save(); toast(`Default induction time set to ${formatTime12(v)}`); renderNav(); render();
  };

  window.installHubUpdate=async function(){if(!confirm('Install a Recruitment Hub update package? The app will close and reopen if the package is valid.'))return;const r=await window.mbl.installUpdate();if(r?.canceled)return;if(!r?.ok)toast(r?.error||'Could not start update');else toast('Installing update…');};

  window.setQuickTimer=async function(mins){const label=`${mins} minute timer`;const r=await window.mbl.setTimer(mins,label);if(r?.ok){activeTimer={id:r.id,label,dueAt:r.dueAt};renderTimerStatus();toast(`${mins} minute timer started`);}};
  window.customTimer=function(){const m=Number(prompt('How many minutes?'));if(m>0)setQuickTimer(m);};
  window.cancelQuickTimer=async function(){if(!activeTimer)return;await window.mbl.cancelTimer(activeTimer.id);activeTimer=null;renderTimerStatus();toast('Timer cancelled');};
  function renderTimerStatus(){const e=document.getElementById('timerStatus');if(!e)return;if(!activeTimer){e.innerHTML='<div class="sub" style="margin-top:13px">No timer running.</div>';return}const mins=Math.max(0,Math.ceil((activeTimer.dueAt-Date.now())/60000));e.innerHTML=`<div class="timer-running"><b>⏱ Timer running</b><div class="sub" style="margin-top:4px">${mins} minute${mins===1?'':'s'} remaining</div><button class="smallbtn" style="margin-top:9px" onclick="cancelQuickTimer()">Cancel timer</button></div>`;}
  window.mbl.onTimerFired(()=>{activeTimer=null;renderTimerStatus();toast('Timer finished');});

  window.addEventListener('wheel',e=>{
    if(!e.ctrlKey)return; e.preventDefault();
    const current=Math.round(getUiScale()*100); const next=Math.max(80,Math.min(200,current+(e.deltaY<0?10:-10)));
    if(next!==current){changeUiScale(next);toast(`UI scale ${next}%`);}
  },{passive:false,capture:true});
  window.addEventListener('keydown',e=>{
    if(!e.ctrlKey)return;
    if(e.key==='0'){e.preventDefault();changeUiScale(125);toast('UI scale 125%');}
    if(e.key==='+'||e.key==='='){e.preventDefault();const n=Math.min(200,Math.round(getUiScale()*100)+10);changeUiScale(n);toast(`UI scale ${n}%`);}
    if(e.key==='-'){e.preventDefault();const n=Math.max(80,Math.round(getUiScale()*100)-10);changeUiScale(n);toast(`UI scale ${n}%`);}
  },true);

  async function bootDesktop(){
    injectDesktopUi();
    try{const v=await window.mbl.version();state.appVersion=v?.version||state.appVersion;save();}catch{}
    try{const c=await window.mbl.status();state.connection=c||{ok:false,state:'signin'};save();}catch(e){state.connection={ok:false,state:'offline',message:e.message};save();}
    auditAttendanceAgainstMbl(false);
    updateSyncUiFromState();renderNav();render();
    setTimeout(()=>checkHubUpdate(false),1500);
    if(state.connection?.ok)await refreshFromMbl(false);
    else setTimeout(()=>openSyncPanel(),450);
  }

  window.copySlackInductionList=function(dateStr){
    const attending=inductionPeopleForDate(dateStr).filter(c=>['confirmed','attended','contract_pending','contract_quiet','contract_signed'].includes(c.status));
    if(!attending.length){toast('No attending candidates to copy');return;}
    const d=parseDMY(dateStr),dd=String(d.getDate()).padStart(2,'0'),mm=String(d.getMonth()+1).padStart(2,'0');
    const text=[`Inductions ${dd}/${mm} ${getDefaultInductionTime()}`,...attending.map(c=>`• ${c.name}`)].join('\n');
    copyText(text,`${attending.length} induction name${attending.length===1?'':'s'} copied for Slack`);
  };
  const baseInductionDetailsWithSlack=openInductionDetails;
  openInductionDetails=function(dateStr){
    baseInductionDetailsWithSlack(dateStr);
    const actions=document.querySelector('#inductionDetailModal .session-summary-actions');
    if(actions&&!actions.querySelector('.slack-copy-btn')){
      const b=document.createElement('button');
      b.className='session-reminder-top slack-copy-btn';
      b.textContent='📋 Copy Slack list';
      b.onclick=()=>window.copySlackInductionList(dateStr);
      actions.insertBefore(b,actions.firstChild);
    }
  };
  window.openInductionDetails=openInductionDetails;


// v1.1.8: clickable previous applications with full historical details.
function ensurePreviousAppsUi(){
  if(!document.getElementById('previousAppsV118Style')){
    const st=document.createElement('style');st.id='previousAppsV118Style';st.textContent=`
      .prior-alert.clickable-prior,.prior-item.clickable-prior{cursor:pointer;transition:.15s ease}
      .prior-alert.clickable-prior:hover,.prior-item.clickable-prior:hover{border-color:#a63a46!important;box-shadow:0 0 14px rgba(242,47,61,.11);transform:translateY(-1px)}
      .prior-item.clickable-prior:after{content:'Open application →';display:block;margin-top:6px;color:#ff9da4;font-size:8px;font-weight:800}
      .prior-app-detail{border:1px solid #303840;background:#121619;border-radius:10px;padding:12px;margin-top:10px}.prior-app-detail.focused{border-color:#a63a46;box-shadow:0 0 16px rgba(242,47,61,.12)}
      .prior-app-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.prior-app-head b{font-size:12px}.prior-app-date{font-size:9px;color:#98a1aa;white-space:nowrap}
      .prior-app-meta{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}.prior-app-meta div{background:#0e1114;border:1px solid #272e34;border-radius:7px;padding:8px}.prior-app-meta span{display:block;color:#7f8992;font-size:7px;text-transform:uppercase}.prior-app-meta strong{display:block;margin-top:3px;font-size:9px}
      .prior-reason{margin-top:9px;border-left:3px solid #f22f3d;background:#211316;border-radius:6px;padding:8px 9px;font-size:9px;line-height:1.45}.prior-reason.none{border-left-color:#46515b;background:#111519;color:#98a1aa}
      .prior-timeline{margin-top:9px;display:flex;flex-direction:column;gap:6px;max-height:220px;overflow:auto}.prior-timeline-row{display:grid;grid-template-columns:92px 1fr;gap:8px;border-top:1px solid #242b31;padding-top:6px}.prior-timeline-row:first-child{border-top:0}.prior-timeline-row time{font-size:8px;color:#84909a}.prior-timeline-row b{font-size:9px}.prior-timeline-row p{margin:2px 0 0;color:#aeb6bd;font-size:8px;line-height:1.4}
      @media(max-width:720px){.prior-app-meta{grid-template-columns:1fr}.prior-timeline-row{grid-template-columns:1fr}}
    `;document.head.appendChild(st);
  }
  if(!document.getElementById('previousAppsModal')){
    const m=document.createElement('div');m.className='modalwrap';m.id='previousAppsModal';m.innerHTML=`<div class="modal" style="width:min(760px,96vw);max-height:92vh;overflow:auto"><div class="modalhead"><h3 id="previousAppsTitle">Previous applications</h3><button class="x" onclick="closeModal('previousAppsModal')">×</button></div><div id="previousAppsBody"></div></div>`;document.body.appendChild(m);
  }
}
function friendlyPriorOutcome(v){const map={answered:'Spoke to / Answered',booked:'Booked',confirmed:'Confirmed',rescheduled:'Rescheduled',no_answer:'No Answer',not_attended:'Not Attended / No Show',declined:'Not Coming / Declined',not_meeting_requirements:"Doesn't Meet Requirements",attended:'Attended',hired:'Hired',not_hired:'Not Hired'};return map[String(v||'').toLowerCase()]||String(v||'Previous application').replace(/_/g,' ')}
function decoratePreviousApplicationsV118(c,root=document){
  if(!c||(c.previousApplications||[]).length===0||!root)return;
  const a=root.querySelector('.prior-alert');if(a){a.classList.add('clickable-prior');a.title='Open previous applications';a.onclick=()=>window.openPreviousApplications(c.id)}
  const rev=(c.previousApplications||[]).slice().reverse();root.querySelectorAll('.prior-item').forEach((item,i)=>{item.classList.add('clickable-prior');item.title='Open this previous application';const rec=rev[i];item.onclick=()=>window.openPreviousApplications(c.id,rec?.id||null)});
}
window.openPreviousApplications=function(id,focusRecordId=null){
  ensurePreviousAppsUi();const c=state.candidates.find(x=>x.id===id);if(!c)return;const apps=(c.previousApplications||[]).slice().reverse();
  document.getElementById('previousAppsTitle').textContent=`${c.name} · Previous applications`;const body=document.getElementById('previousAppsBody');
  if(!apps.length){body.innerHTML='<div class="empty">No previous applications found.</div>';openModal('previousAppsModal');return}
  body.innerHTML=`<div class="sub">${apps.length} earlier application${apps.length===1?'':'s'} found on official MBL. Where MBL has a reason or outcome recorded, it is shown below.</div>${apps.map(p=>{const focused=focusRecordId&&String(p.id)===String(focusRecordId),tl=(p.timeline||[]).slice().reverse(),reason=p.reason||'';return `<div class="prior-app-detail ${focused?'focused':''}" data-prior-id="${esc(p.id||'')}"><div class="prior-app-head"><div><b>${esc(friendlyPriorOutcome(p.outcome))}</b></div><span class="prior-app-date">Applied ${esc(p.date||'Unknown')}</span></div><div class="prior-app-meta"><div><span>Final / last status</span><strong>${esc(friendlyPriorOutcome(p.callStage||p.stage||p.outcome))}</strong></div><div><span>Induction</span><strong>${esc(p.induction||'No induction date recorded')}</strong></div></div><div class="prior-reason ${reason?'':'none'}"><b>${reason?'Reason / outcome':'Reason'}</b><br>${esc(reason||'No explicit reason for non-attendance is recorded on MBL for this application.')}</div>${(p.notes||[]).length?`<div style="margin-top:9px"><div class="history-section-title">Notes</div>${p.notes.map(n=>`<div class="saved-note">${esc(n)}</div>`).join('')}</div>`:''}${tl.length?`<div class="history-section-title">Application history</div><div class="prior-timeline">${tl.map(t=>`<div class="prior-timeline-row"><time>${esc(t.at||'')}</time><div><b>${esc(t.title||'Activity')}</b>${t.detail?`<p>${esc(t.detail)}</p>`:''}</div></div>`).join('')}</div>`:''}</div>`}).join('')}`;openModal('previousAppsModal');
  if(focusRecordId)setTimeout(()=>body.querySelector(`[data-prior-id="${CSS.escape(String(focusRecordId))}"]`)?.scrollIntoView({block:'start',behavior:'smooth'}),80);
};
const renderProfileV117=renderProfile;renderProfile=function(el){renderProfileV117(el);const c=state.candidates.find(x=>x.id===profileId);if(c)decoratePreviousApplicationsV118(c,el)};
const renderCallModeV117=renderCallMode;renderCallMode=function(el){renderCallModeV117(el);const q=callCandidates(),c=q[state.callIndex];if(c)decoratePreviousApplicationsV118(c,el)};



// v1.1.12: isolated bridge test pages. These do NOT change live candidate/contract workflow.
const BRIDGE_TEST_STORAGE='mblBridgeTestV1';
function getBridgeTestData(){
  try{return JSON.parse(localStorage.getItem(BRIDGE_TEST_STORAGE)||'{"contracts":[],"onboarding":[],"contractSync":null,"onboardingSync":null}')}
  catch{return {contracts:[],onboarding:[],contractSync:null,onboardingSync:null}}
}
function saveBridgeTestData(v){localStorage.setItem(BRIDGE_TEST_STORAGE,JSON.stringify(v))}
function bridgeStamp(iso){if(!iso)return 'Never';try{return new Date(iso).toLocaleString('en-GB',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}catch{return String(iso)}}
function bridgePill(text,kind='muted'){return `<span class="bridge-pill ${kind}">${esc(text)}</span>`}
function ensureBridgeTestNav(){
  if(!navItems.some(x=>x[0]==='contracttest')) navItems.push(['contracttest','◫','Contracts Test']);
  if(!navItems.some(x=>x[0]==='onboardingtest')) navItems.push(['onboardingtest','◉','Onboarding Test']);
}
ensureBridgeTestNav();

(function addBridgeTestStyles(){
  if(document.getElementById('bridgeTestStyles'))return;
  const st=document.createElement('style');st.id='bridgeTestStyles';st.textContent=`
    .navbtn[data-page="contracttest"] .navtxt:after,.navbtn[data-page="onboardingtest"] .navtxt:after{content:'TEST';font-size:6px;font-weight:900;letter-spacing:.09em;color:#ffb0b6;border:1px solid #71313a;border-radius:999px;padding:2px 4px;margin-left:6px;vertical-align:2px}
    .bridge-test{max-width:1720px;width:100%}.bridge-warning{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid #6b3d24;background:#21180f;border-radius:10px;padding:11px 13px;margin-bottom:13px}.bridge-warning b{font-size:11px;color:#ffd08a}.bridge-warning span{display:block;color:#bcaa8f;font-size:9px;margin-top:3px}
    .bridge-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin-bottom:13px}.bridge-kpi{background:#101316;border:1px solid #2b3238;border-radius:9px;padding:12px}.bridge-kpi b{display:block;font-size:24px}.bridge-kpi span{font-size:8px;color:#8f99a2;text-transform:uppercase;letter-spacing:.07em}.bridge-kpi.alert{border-color:#7a5622;background:#1d180e}.bridge-kpi.good{border-color:#285c43;background:#101a15}
    .bridge-toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 11px}.bridge-toolbar .sub{margin-right:auto}.bridge-table-wrap{background:#101316;border:1px solid #293038;border-radius:10px;overflow:auto}.bridge-table{min-width:820px}.bridge-table td,.bridge-table th{font-size:9px}.bridge-name b{display:block;font-size:10px}.bridge-name span{display:block;color:#8f99a2;margin-top:2px;font-size:8px}.bridge-pill{display:inline-flex;align-items:center;border-radius:999px;border:1px solid #3a424a;padding:4px 7px;font-size:8px;white-space:nowrap}.bridge-pill.good{color:#83e5ad;border-color:#2b704c;background:#11271c}.bridge-pill.warn{color:#ffd176;border-color:#785b29;background:#2e240f}.bridge-pill.bad{color:#ff939b;border-color:#74313a;background:#2d1418}.bridge-pill.info{color:#9fc5ff;border-color:#345f8c;background:#10243a}.bridge-pill.muted{color:#aeb5bb;border-color:#444b52;background:#1b2024}.bridge-action{font-weight:900;color:#ffd176}.bridge-empty{padding:30px;text-align:center;color:#89939b;font-size:10px}.bridge-empty b{display:block;color:#dce1e4;font-size:12px;margin-bottom:5px}.bridge-note{margin-top:10px;color:#818c95;font-size:8px;line-height:1.5}
    @media(max-width:900px){.bridge-kpis{grid-template-columns:repeat(2,1fr)}}
    @media(max-width:560px){.bridge-kpis{grid-template-columns:1fr}}
  `;document.head.appendChild(st);
})();

window.loadContractBridgeDemo=function(){
  const d=getBridgeTestData(); const now=new Date().toISOString();
  d.contractSync=now; d.contracts=[
    {name:'Demo Driver A',document:'MBL INDUCTION PACK V24(2026)',status:'pending',match:'matched',updated:now},
    {name:'Demo Driver B',document:'MBL INDUCTION PACK V24(2026)',status:'signed',match:'matched',updated:now},
    {name:'Unknown signer',document:'MBL INDUCTION PACK V24(2026)',status:'signed',match:'unmatched',updated:now}
  ];saveBridgeTestData(d);if(currentPage==='contracttest')render();
};
window.loadOnboardingBridgeDemo=function(){
  const d=getBridgeTestData(); const now=new Date().toISOString();
  d.onboardingSync=now; d.onboarding=[
    {name:'Demo Driver A',summary:'14/15',detail:'18 of 20',background:'Approved',driverRecord:'Complete',training:'Incomplete',action:'Send online training',updated:now},
    {name:'Demo Driver B',summary:'9/15',detail:'12 of 20',background:'Processing',driverRecord:'Pending',training:'Incomplete',action:'Waiting on checks',updated:now},
    {name:'Demo Driver C',summary:'15/15',detail:'20 of 20',background:'Approved',driverRecord:'Complete',training:'Complete',action:'Onboarding complete',updated:now}
  ];saveBridgeTestData(d);if(currentPage==='onboardingtest')render();
};
window.clearBridgeTestData=function(which){const d=getBridgeTestData();if(which==='contracts'){d.contracts=[];d.contractSync=null}else{d.onboarding=[];d.onboardingSync=null}saveBridgeTestData(d);render()};
// Future browser companion/local receiver can feed these without touching recruitment state.
window.receiveBridgeTestData=function(source,rows){const d=getBridgeTestData(),now=new Date().toISOString();if(source==='contracts'){d.contracts=Array.isArray(rows)?rows:[];d.contractSync=now}else if(source==='onboarding'){d.onboarding=Array.isArray(rows)?rows:[];d.onboardingSync=now}else{return false}saveBridgeTestData(d);if((source==='contracts'&&currentPage==='contracttest')||(source==='onboarding'&&currentPage==='onboardingtest'))render();return true};

function renderContractBridgeTest(el){
  header('Contracts Test','Experimental Dropbox Sign reader area — completely separate from your working Contracts page.');
  const d=getBridgeTestData(),rows=d.contracts||[],pending=rows.filter(x=>x.status==='pending').length,signed=rows.filter(x=>x.status==='signed').length,unmatched=rows.filter(x=>x.match!=='matched').length;
  el.innerHTML=`<div class="bridge-test"><div class="bridge-warning"><div><b>TEST AREA — live recruitment workflow is untouched</b><span>Anything shown here is test/bridge data only. It will not move candidates, mark contracts signed or change MBL.</span></div>${bridgePill(d.contractSync?'DATA RECEIVED':'NOT CONNECTED',d.contractSync?'good':'warn')}</div><div class="bridge-kpis"><div class="bridge-kpi"><b>${pending}</b><span>Pending signature</span></div><div class="bridge-kpi good"><b>${signed}</b><span>Signed</span></div><div class="bridge-kpi ${unmatched?'alert':''}"><b>${unmatched}</b><span>Unmatched</span></div><div class="bridge-kpi"><b style="font-size:13px;margin:5px 0 4px">${esc(bridgeStamp(d.contractSync))}</b><span>Last bridge sync</span></div></div><div class="bridge-toolbar"><div class="sub">Dropbox Sign · Pending / Signed prototype</div><button class="smallbtn" onclick="loadContractBridgeDemo()">Load safe demo</button><button class="smallbtn" onclick="clearBridgeTestData('contracts')">Clear test data</button></div><div class="bridge-table-wrap">${rows.length?`<table class="bridge-table"><thead><tr><th>Signer / candidate</th><th>Document</th><th>Dropbox status</th><th>Candidate match</th><th>Updated</th></tr></thead><tbody>${rows.map(r=>`<tr><td><div class="bridge-name"><b>${esc(r.name||'Unknown')}</b></div></td><td>${esc(r.document||'—')}</td><td>${r.status==='signed'?bridgePill('Signed','good'):bridgePill('Pending signature','warn')}</td><td>${r.match==='matched'?bridgePill('Matched','good'):bridgePill('Needs matching','bad')}</td><td>${esc(bridgeStamp(r.updated))}</td></tr>`).join('')}</tbody></table>`:`<div class="bridge-empty"><b>No Dropbox Sign data received yet</b>The future browser companion will feed Pending and Signed documents into this page first, without changing your current Contracts workflow.</div>`}</div><div class="bridge-note">Safety rule: even once the reader is connected, an unmatched or uncertain document will stay here for review instead of being attached to the wrong candidate.</div></div>`;
}
function onboardingStatusPill(v){const s=String(v||'').toLowerCase();if(/approved|complete/.test(s))return bridgePill(v,'good');if(/processing|pending|waiting/.test(s))return bridgePill(v,'warn');return bridgePill(v||'Unknown','muted')}
function renderOnboardingBridgeTest(el){
  header('Onboarding Test','Experimental Amazon DHU2 onboarding reader — separate from the recruitment workflow.');
  const d=getBridgeTestData(),rows=d.onboarding||[],waiting=rows.filter(x=>/waiting|processing/i.test(x.action||'')).length,training=rows.filter(x=>/send online training/i.test(x.action||'')).length,complete=rows.filter(x=>/onboarding complete/i.test(x.action||'')).length;
  el.innerHTML=`<div class="bridge-test"><div class="bridge-warning"><div><b>TEST AREA — does not alter candidates</b><span>This page is for proving the Amazon reader before we connect it to contracts, candidate stages or notifications.</span></div>${bridgePill(d.onboardingSync?'DATA RECEIVED':'NOT CONNECTED',d.onboardingSync?'good':'warn')}</div><div class="bridge-kpis"><div class="bridge-kpi"><b>${rows.length}</b><span>Onboarding records</span></div><div class="bridge-kpi"><b>${waiting}</b><span>Waiting on checks</span></div><div class="bridge-kpi alert"><b>${training}</b><span>Training needs sending</span></div><div class="bridge-kpi good"><b>${complete}</b><span>Onboarding complete</span></div></div><div class="bridge-toolbar"><div class="sub">Amazon Logistics · Setup → Associates → DHU2 → Onboarding</div><button class="smallbtn" onclick="loadOnboardingBridgeDemo()">Load safe demo</button><button class="smallbtn" onclick="clearBridgeTestData('onboarding')">Clear test data</button></div><div class="bridge-table-wrap">${rows.length?`<table class="bridge-table"><thead><tr><th>Associate</th><th>Progress</th><th>Background check</th><th>Driver record</th><th>Onboarding training</th><th>Next action</th><th>Updated</th></tr></thead><tbody>${rows.map(r=>`<tr><td><div class="bridge-name"><b>${esc(r.name||'Unknown')}</b></div></td><td>${bridgePill([r.summary,r.detail].filter(Boolean).join(' · '),'info')}</td><td>${onboardingStatusPill(r.background)}</td><td>${onboardingStatusPill(r.driverRecord)}</td><td>${/complete/i.test(String(r.training||''))&&!/incomplete/i.test(String(r.training||''))?bridgePill(r.training,'good'):bridgePill(r.training||'Incomplete','warn')}</td><td class="${/send online training/i.test(effectiveOnboardingAction(r))?'bridge-action':''}">${esc(effectiveOnboardingAction(r))}</td><td>${esc(bridgeStamp(r.updated))}</td></tr>`).join('')}</tbody></table>`:`<div class="bridge-empty"><b>No Amazon onboarding data received yet</b>The test reader will eventually populate this page with the associate list and detailed named tasks such as Background Check, Driver Record Verification and Onboarding Training.</div>`}</div><div class="bridge-note">Primary trigger being tested: all prerequisite checks complete while Onboarding Training remains incomplete/grey → <b style="color:#ffd176">Send online training</b>. The named task states are treated as more important than the 14/15 summary alone.</div></div>`;
}
const renderV1111=render;
render=function(){const el=document.getElementById('content');if(currentPage==='contracttest')return renderContractBridgeTest(el);if(currentPage==='onboardingtest')return renderOnboardingBridgeTest(el);return renderV1111();};



// v1.1.13 — live read-only browser bridge feeding isolated TEST pages.
let bridgeServerInfo=null;
let bridgeContractSearch='', bridgeContractRange='30', bridgeContractSort='newest', bridgeContractStatus='all';
let bridgeOnboardingSearch='', bridgeOnboardingFilter='all', bridgeOnboardingSort='priority';
function receiveLiveBridgeData(data){
  if(!data)return;
  const local=getBridgeTestData();
  local.contracts=Array.isArray(data.contracts)?data.contracts:local.contracts||[];
  local.onboarding=Array.isArray(data.onboarding)?data.onboarding:local.onboarding||[];
  local.contractSync=data.contractSync||null;local.onboardingSync=data.onboardingSync||null;local.lastPayload=data.lastPayload||null;
  saveBridgeTestData(local);
  if(currentPage==='contracttest'||currentPage==='onboardingtest')render();
}
async function pullLiveBridgeData(){
  try{const r=await window.mbl.bridgeSnapshot();if(r?.ok){bridgeServerInfo=r.server||null;receiveLiveBridgeData(r.data)}}catch{}
}
window.openRecruitmentBridgeFolder=async()=>{const r=await window.mbl.openBridgeFolder();if(!r?.ok)toast(r?.error||'Could not open reader folder')};
window.clearBridgeTestData=async function(which){
  try{await window.mbl.clearBridgeData(which)}catch{}
  const d=getBridgeTestData();if(which==='contracts'){d.contracts=[];d.contractSync=null}else{d.onboarding=[];d.onboardingSync=null}saveBridgeTestData(d);render();
};
window.setBridgeContractRange=v=>{bridgeContractRange=v;render()};
window.setBridgeContractSort=v=>{bridgeContractSort=v;render()};
window.setBridgeContractStatus=v=>{bridgeContractStatus=v;render()};
window.applyBridgeContractSearch=()=>{bridgeContractSearch=document.getElementById('bridgeContractSearch')?.value||'';render()};
window.setBridgeOnboardingFilter=v=>{bridgeOnboardingFilter=v;render()};
window.setBridgeOnboardingSort=v=>{bridgeOnboardingSort=v;render()};
window.applyBridgeOnboardingSearch=()=>{bridgeOnboardingSearch=document.getElementById('bridgeOnboardingSearch')?.value||'';render()};
function bridgeDateMs(r){const n=Date.parse(r?.sourceUpdatedAt||r?.updated||r?.receivedAt||'');return Number.isFinite(n)?n:0}
function selectOpt(v,label,current){return `<option value="${esc(v)}" ${String(v)===String(current)?'selected':''}>${esc(label)}</option>`}
function bridgeReaderInstall(){return `<div class="bridge-warning"><div><b>READ-ONLY TEST FEED</b><span>Install the MBL Recruitment Bridge once, then keep the Amazon/Dropbox page open during this first test. It only feeds these TEST pages.</span></div><div style="display:flex;gap:7px;align-items:center">${bridgePill(bridgeServerInfo?.state==='listening'?'HUB READER READY':'READER OFFLINE',bridgeServerInfo?.state==='listening'?'good':'warn')}<button class="smallbtn" onclick="openRecruitmentBridgeFolder()">Open reader folder</button></div></div>`}
function filteredContractBridgeRows(rows){
  const q=bridgeContractSearch.trim().toLowerCase(),now=Date.now(),days=Number(bridgeContractRange);
  let out=rows.filter(r=>{
    if(q&&!`${r.name||''} ${r.document||''} ${r.updatedDisplay||''}`.toLowerCase().includes(q))return false;
    if(bridgeContractStatus==='pending'&&r.status!=='pending')return false;
    if(bridgeContractStatus==='signed'&&r.status!=='signed')return false;
    if(bridgeContractStatus==='unmatched'&&r.match==='matched')return false;
    if(Number.isFinite(days)&&days>0){const t=bridgeDateMs(r);if(t&&now-t>days*86400000)return false}
    return true;
  });
  out.sort((a,b)=>bridgeContractSort==='oldest'?bridgeDateMs(a)-bridgeDateMs(b):bridgeContractSort==='name'?String(a.name||a.document||'').localeCompare(String(b.name||b.document||'')):bridgeDateMs(b)-bridgeDateMs(a));
  return out;
}
function renderContractBridgeLive(el){
  header('Contracts Test','Live Dropbox Sign reader test — isolated from your working Contracts page.');
  const d=getBridgeTestData(),all=d.contracts||[],rows=filteredContractBridgeRows(all),pending=all.filter(x=>x.status==='pending').length,signed=all.filter(x=>x.status==='signed').length,unmatched=all.filter(x=>x.match!=='matched').length;
  el.innerHTML=`<div class="bridge-test">${bridgeReaderInstall()}<div class="bridge-kpis"><div class="bridge-kpi"><b>${pending}</b><span>Pending signature</span></div><div class="bridge-kpi good"><b>${signed}</b><span>Signed</span></div><div class="bridge-kpi ${unmatched?'alert':''}"><b>${unmatched}</b><span>Needs matching</span></div><div class="bridge-kpi"><b style="font-size:13px;margin:5px 0 4px">${esc(bridgeStamp(d.contractSync))}</b><span>Last reader sync</span></div></div>
  <div class="bridge-toolbar"><input id="bridgeContractSearch" class="field" style="max-width:330px" value="${esc(bridgeContractSearch)}" placeholder="Search name or document…" onkeydown="if(event.key==='Enter')applyBridgeContractSearch()"><button class="smallbtn" onclick="applyBridgeContractSearch()">Search</button><select class="field" style="width:auto" onchange="setBridgeContractStatus(this.value)">${selectOpt('all','Pending + signed',bridgeContractStatus)}${selectOpt('pending','Pending only',bridgeContractStatus)}${selectOpt('signed','Signed only',bridgeContractStatus)}${selectOpt('unmatched','Needs matching',bridgeContractStatus)}</select><select class="field" style="width:auto" onchange="setBridgeContractRange(this.value)">${selectOpt('7','Updated last 7 days',bridgeContractRange)}${selectOpt('30','Updated last 30 days',bridgeContractRange)}${selectOpt('90','Updated last 90 days',bridgeContractRange)}${selectOpt('all','All history',bridgeContractRange)}</select><select class="field" style="width:auto" onchange="setBridgeContractSort(this.value)">${selectOpt('newest','Newest first',bridgeContractSort)}${selectOpt('oldest','Oldest first',bridgeContractSort)}${selectOpt('name','Name A–Z',bridgeContractSort)}</select><span class="sub">Showing ${rows.length} of ${all.length}</span><button class="smallbtn" onclick="clearBridgeTestData('contracts')">Clear test feed</button></div>
  <div class="bridge-table-wrap">${rows.length?`<table class="bridge-table"><thead><tr><th>Signer / candidate</th><th>Document</th><th>Dropbox status</th><th>Match</th><th>Dropbox updated</th></tr></thead><tbody>${rows.map(r=>`<tr><td><div class="bridge-name"><b>${esc(r.name||'Name not in title')}</b></div></td><td>${esc(r.document||'—')}</td><td>${r.status==='signed'?bridgePill('Signed','good'):bridgePill('Pending signature','warn')}</td><td>${r.match==='matched'?bridgePill('Matched','good'):bridgePill('Needs matching','bad')}</td><td>${esc(r.updatedDisplay||bridgeStamp(r.sourceUpdatedAt||r.updated))}</td></tr>`).join('')}</tbody></table>`:`<div class="bridge-empty"><b>${all.length?'No contracts match these filters':'No live Dropbox rows received yet'}</b>${all.length?'Change the date/status filter or use All history.':'With the reader installed, open Dropbox Sign → Documents → Pending or Signed. Visible rows will feed here automatically.'}</div>`}</div><div class="bridge-note">Default view is the last 30 days so hundreds of old documents do not swamp the page. <b>All history</b> remains available whenever you need an older contract.</div></div>`;
}
function effectiveOnboardingAction(r){
  const summary=String(r?.summary||'').replace(/\s/g,'');
  const training=String(r?.training||'');
  const background=String(r?.background||'');
  const driver=String(r?.driverRecord||'');
  if(summary==='15/15')return 'Onboarding complete';
  if(summary==='14/15'&&/Incomplete/i.test(training))return 'Send online training';
  if(/Processing|Pending/i.test(background)||/Processing|Pending/i.test(driver)||/waiting/i.test(String(r?.action||'')))return 'Waiting on checks';
  return 'Onboarding in progress';
}
function onboardingPriority(r){const a=effectiveOnboardingAction(r);return /send online training/i.test(a)?0:/waiting/i.test(a)?1:/in progress/i.test(a)?2:/complete/i.test(a)?3:4}
function filteredOnboardingBridgeRows(rows){
  const q=bridgeOnboardingSearch.trim().toLowerCase();let out=rows.filter(r=>{
    const action=effectiveOnboardingAction(r);
    if(q&&!`${r.name||''} ${r.providerId||''} ${action}`.toLowerCase().includes(q))return false;
    if(bridgeOnboardingFilter==='training'&&!/send online training/i.test(action))return false;
    if(bridgeOnboardingFilter==='waiting'&&!/waiting/i.test(action))return false;
    if(bridgeOnboardingFilter==='complete'&&!/onboarding complete/i.test(action))return false;
    if(bridgeOnboardingFilter==='progress'&&!/in progress/i.test(action))return false;
    return true;
  });
  out.sort((a,b)=>bridgeOnboardingSort==='name'?String(a.name||'').localeCompare(String(b.name||'')):bridgeOnboardingSort==='progress'?(Number(String(b.summary||'0').match(/\d+/)?.[0]||0)-Number(String(a.summary||'0').match(/\d+/)?.[0]||0)):onboardingPriority(a)-onboardingPriority(b));return out;
}
function renderOnboardingBridgeLive(el){
  header('Onboarding Test','Live Amazon DHU2 onboarding list test — isolated from candidate stages.');
  const d=getBridgeTestData(),all=d.onboarding||[],rows=filteredOnboardingBridgeRows(all),waiting=all.filter(x=>/waiting/i.test(x.action||'')).length,training=all.filter(x=>/send online training/i.test(x.action||'')).length,complete=all.filter(x=>/onboarding complete/i.test(x.action||'')).length;
  el.innerHTML=`<div class="bridge-test">${bridgeReaderInstall()}<div class="bridge-kpis"><div class="bridge-kpi"><b>${all.length}</b><span>Onboarding records</span></div><div class="bridge-kpi"><b>${waiting}</b><span>Waiting on checks</span></div><div class="bridge-kpi alert"><b>${training}</b><span>Training needs sending</span></div><div class="bridge-kpi good"><b>${complete}</b><span>Onboarding complete</span></div></div>
  <div class="bridge-toolbar"><input id="bridgeOnboardingSearch" class="field" style="max-width:330px" value="${esc(bridgeOnboardingSearch)}" placeholder="Search associate or provider ID…" onkeydown="if(event.key==='Enter')applyBridgeOnboardingSearch()"><button class="smallbtn" onclick="applyBridgeOnboardingSearch()">Search</button><select class="field" style="width:auto" onchange="setBridgeOnboardingFilter(this.value)">${selectOpt('all','All onboarding',bridgeOnboardingFilter)}${selectOpt('training','Training needs sending',bridgeOnboardingFilter)}${selectOpt('waiting','Waiting on checks',bridgeOnboardingFilter)}${selectOpt('progress','In progress',bridgeOnboardingFilter)}${selectOpt('complete','Complete',bridgeOnboardingFilter)}</select><select class="field" style="width:auto" onchange="setBridgeOnboardingSort(this.value)">${selectOpt('priority','Action priority',bridgeOnboardingSort)}${selectOpt('name','Name A–Z',bridgeOnboardingSort)}${selectOpt('progress','Highest progress',bridgeOnboardingSort)}</select><span class="sub">Showing ${rows.length} of ${all.length}</span><button class="smallbtn" onclick="clearBridgeTestData('onboarding')">Clear test feed</button></div>
  <div class="bridge-table-wrap">${rows.length?`<table class="bridge-table"><thead><tr><th>Associate</th><th>Progress</th><th>Next action</th><th>Updated</th></tr></thead><tbody>${rows.map(r=>`<tr><td><div class="bridge-name"><b>${esc(r.name||'Name from onboarding list')}</b><span>${esc(r.providerId||'')}</span></div></td><td>${bridgePill(r.summary||'—','info')}</td><td class="${/send online training/i.test(r.action||'')?'bridge-action':''}">${/send online training/i.test(r.action||'')?bridgePill('Send online training','warn'):/onboarding complete/i.test(r.action||'')?bridgePill('Onboarding complete','good'):esc(r.action||'Onboarding in progress')}</td><td>${esc(bridgeStamp(r.updated||r.receivedAt))}</td></tr>`).join('')}</tbody></table>`:`<div class="bridge-empty"><b>${all.length?'No associates match these filters':'No live Amazon rows received yet'}</b>${all.length?'Change the action filter or search.':'Open Setup → Associates → DHU2 → Onboarding. The reader now uses that list directly; you should not need to open individual profiles.'}</div>`}</div><div class="bridge-note">For this test the Associates list is the source of truth: <b>14/15 = Send online training</b> and <b>15/15 = Onboarding complete</b>. No 18/20 count and no individual profile crawl.</div></div>`;
}
const renderV1112=render;
render=function(){const el=document.getElementById('content');if(currentPage==='contracttest')return renderContractBridgeLive(el);if(currentPage==='onboardingtest')return renderOnboardingBridgeLive(el);return renderV1112();};
try{window.mbl.onBridgeData(receiveLiveBridgeData)}catch{}
setTimeout(pullLiveBridgeData,700);



  function supportSnapshotPayload(){
    return {
      appVersion: state.appVersion || '1.1.18',
      lastMblRefresh: state.lastMblRefresh || null,
      connectionOk: !!state.connection?.ok,
      currentPage: typeof currentPage === 'string' ? currentPage : null,
      candidates: (state.candidates || []).map(c => ({
        id: c.id || '', mblId: c.mblId || '', name: c.name || '', status: c.status || '',
        displayStatus: (()=>{try{return statusLabel(c)}catch{return c.status||''}})(),
        officialStage: c.officialStage || '', officialCallStage: c.officialCallStage || '',
        officialInduction: c.officialInduction || '', induction: c.induction || '',
        attempts: Number(c.attempts || 0), officialAttempts: Number(c.officialAttempts || 0),
        applied: c.applied || '', source: c.source || '', localOnly: !!c.localOnly, syncState: c.syncState || ''
      }))
    };
  }
  async function pushSupportSnapshot(){ try { await window.mbl.supportPush(supportSnapshotPayload()); } catch {} }
  window.openChatGptSupportView = async function(){
    try { const r=await window.mbl.supportUrl(); if(!r?.ok||!r.url) throw new Error(r?.error||'Support view unavailable'); await window.mbl.openExternal(r.url); toast('Opened read-only support view in your browser'); }
    catch(e){ toast(e.message||'Unable to open support view'); }
  };
  setTimeout(pushSupportSnapshot,800);
  setInterval(pushSupportSnapshot,3000);

  setInterval(()=>{if(state.connection?.ok)refreshFromMbl(false)},90000);
  setInterval(()=>checkHubUpdate(false),2*60*60*1000);
  setInterval(()=>{if((state.syncQueue||[]).some(x=>x.status==='failed'||x.status==='pending'))retrySyncQueue(false)},120000);setInterval(nightlyLocalLeadSweep,60000);setTimeout(nightlyLocalLeadSweep,1500);
  setInterval(renderTimerStatus,30000);
  setTimeout(bootDesktop,120);

// v1.1.25 — manual contract + onboarding workflow.
const V1125_PENDING_CONTRACTS_URL='https://app.hellosign.com/home/manage?status=out_for_signature';
const V1125_SIGNED_CONTRACTS_URL='https://app.hellosign.com/home/manage?status=completed';
const V1125_AMAZON_ONBOARDING_URL='https://logistics.amazon.co.uk/account-management/delivery-associates?providerType=DA&searchStart=0&searchSize=100';
const V1125_ONBOARDING_CHECK_HOURS=12;
let v1125OnboardingFilter='active';

(function configureV1125Navigation(){
  for(const key of ['contracttest','onboardingtest']){
    const i=navItems.findIndex(x=>x[0]===key);if(i>=0)navItems.splice(i,1);
  }
  if(!navItems.some(x=>x[0]==='onboarding')){
    const contractsIndex=navItems.findIndex(x=>x[0]==='contracts');
    navItems.splice(contractsIndex>=0?contractsIndex+1:navItems.length,0,['onboarding','◉','Onboarding']);
  }
  try{renderNav()}catch{}
})();

(function addV1125Styles(){
  if(document.getElementById('v1125Styles'))return;
  const st=document.createElement('style');st.id='v1125Styles';st.textContent=`
    .contract-portal-links{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 11px}.contract-portal-links .hint{color:#8f99a2;font-size:9px;margin-right:auto}.contract-check-link{border:1px solid #8f2731;background:#301419;color:#ffabb1;border-radius:7px;padding:8px 11px;font-size:10px;font-weight:900;letter-spacing:.04em}.contract-check-link:hover{border-color:#f22f3d;background:#3b151b}.contract-view-signed{border-color:#2d6749;background:#10251b;color:#8ee5b3}.contract-lookup-note{font-size:7px;color:#7f8992;margin-top:4px}
    .onboarding-shell{max-width:1720px;width:100%}.onboarding-summary{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin-bottom:12px}.onboarding-kpi{border:1px solid #2b3238;background:#101316;border-radius:9px;padding:12px}.onboarding-kpi b{display:block;font-size:24px}.onboarding-kpi span{display:block;color:#89939b;font-size:8px;text-transform:uppercase;letter-spacing:.06em;margin-top:2px}.onboarding-kpi.due{border-color:#71313a;background:#241417}.onboarding-kpi.training{border-color:#72551f;background:#251e0e}.onboarding-kpi.good{border-color:#285c43;background:#101a15}
    .onboarding-top{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:11px}.onboarding-table-wrap{overflow:auto;border:1px solid #293038;border-radius:10px}.onboarding-table{min-width:940px}.onboarding-table th,.onboarding-table td{font-size:9px}.onboarding-actions{display:flex;gap:5px;flex-wrap:wrap}.onboarding-actions button{padding:6px 8px;font-size:8px}.onboarding-check{font-weight:900;border-color:#8f2731!important;color:#ffabb1!important;background:#301419!important}.onboarding-check.ok{border-color:#3b4852!important;color:#dce1e5!important;background:#171b1f!important}.onboarding-state{display:inline-flex;border:1px solid #3b434a;border-radius:999px;padding:4px 7px;font-size:8px}.onboarding-state.progress{color:#9fc5ff;border-color:#345f8c;background:#10243a}.onboarding-state.training{color:#ffd176;border-color:#785b29;background:#2e240f}.onboarding-state.sent{color:#d8b2ff;border-color:#62467d;background:#21172d}.onboarding-state.complete{color:#83e5ad;border-color:#2b704c;background:#11271c}.onboarding-due{color:#ff9da5;font-weight:900}.onboarding-home{border-color:#2f4e61}.onboarding-home.due{border-color:#71313a;box-shadow:0 0 24px rgba(242,47,61,.08)}.onboarding-home .mini-list{margin-top:10px}.onboarding-name-row{display:flex;align-items:center;justify-content:space-between;gap:8px;border-top:1px solid #242a2f;padding:6px 0;font-size:9px}.onboarding-name-row:first-child{border-top:0}.onboarding-name-row span{color:#8d98a1}
    @media(max-width:900px){.onboarding-summary{grid-template-columns:repeat(2,1fr)}}@media(max-width:620px){.onboarding-summary{grid-template-columns:1fr}}
  `;document.head.appendChild(st);
})();

function v1125OnboardingCandidates(){return state.candidates.filter(c=>c.status==='contract_signed')}
function v1125OnboardingBase(c){return c.onboardingLastChecked||c.onboardingStartedAt||c.contractSignedAt||null}
function v1125OnboardingDue(c){if(c.onboardingState==='complete')return false;if(c.onboardingState==='training_ready')return true;const b=v1125OnboardingBase(c);return !b||hoursSince(b)>=V1125_ONBOARDING_CHECK_HOURS}
function v1125OnboardingState(c){return c.onboardingState||'in_progress'}
function v1125OnboardingLabel(c){const s=v1125OnboardingState(c);if(s==='training_ready')return 'Send online training';if(s==='training_sent')return 'Training sent · waiting';if(s==='complete')return 'Onboarding complete';return 'Onboarding in progress'}
function v1125OnboardingBadge(c){const s=v1125OnboardingState(c),cls=s==='training_ready'?'training':s==='training_sent'?'sent':s==='complete'?'complete':'progress';return `<span class="onboarding-state ${cls}">${esc(v1125OnboardingLabel(c))}</span>`}
function v1125NextCheckText(c){if(c.onboardingState==='complete')return 'Complete';if(v1125OnboardingDue(c))return '<span class="onboarding-due">CHECK NOW</span>';const left=Math.max(1,Math.ceil(V1125_ONBOARDING_CHECK_HOURS-hoursSince(v1125OnboardingBase(c))));return `${left}h`}

window.openContractPortalV1125=async function(id,mode='pending'){
  const c=state.candidates.find(x=>x.id===id);if(!c)return;
  if(c.email)await copyText(c.email,`Email copied · opening ${mode==='signed'?'Signed':'Pending'} contracts`);
  await window.mbl.openExternal(mode==='signed'?V1125_SIGNED_CONTRACTS_URL:V1125_PENDING_CONTRACTS_URL);
};
window.openContractListV1125=async function(mode='pending'){await window.mbl.openExternal(mode==='signed'?V1125_SIGNED_CONTRACTS_URL:V1125_PENDING_CONTRACTS_URL)};
window.openOnboardingProgressV1125=async function(id){const c=state.candidates.find(x=>x.id===id);if(!c)return;if(c.name)await copyText(c.name,'Candidate name copied · opening Amazon onboarding');await window.mbl.openExternal(V1125_AMAZON_ONBOARDING_URL)};
window.openAmazonOnboardingV1125=async function(){await window.mbl.openExternal(V1125_AMAZON_ONBOARDING_URL)};
window.setOnboardingFilterV1125=function(v){v1125OnboardingFilter=v;render()};
window.markOnboardingV1125=function(id,next){
  const c=state.candidates.find(x=>x.id===id);if(!c)return;snapshot(id);
  const now=new Date().toISOString();c.onboardingStartedAt=c.onboardingStartedAt||c.contractSignedAt||now;c.onboardingLastChecked=now;c.onboardingState=next;c.history=c.history||[];
  let title='Onboarding checked',detail='Still progressing in Amazon';
  if(next==='training_ready'){title='Online training ready';detail='Amazon progress checked · 14/15 — send online training'}
  if(next==='training_sent'){title='Online training sent';detail='Training sent · waiting for Amazon onboarding to complete'}
  if(next==='complete'){title='Onboarding complete';detail='Amazon progress checked · 15/15 complete';c.onboardingCompletedAt=now}else delete c.onboardingCompletedAt;
  c.history.push([nowStamp(),title,detail]);save();toast(`${c.name}: ${detail}`);render();
};

const v1125BaseMarkContractSigned=markContractSigned;
markContractSigned=function(id){
  v1125BaseMarkContractSigned(id);
  const c=state.candidates.find(x=>x.id===id);if(c&&c.status==='contract_signed'){
    c.onboardingStartedAt=c.onboardingStartedAt||c.contractSignedAt||new Date().toISOString();
    c.onboardingState=c.onboardingState||'in_progress';
    save();render();
  }
};

const v1125BaseRenderContracts=renderContracts;
renderContracts=function(el){
  v1125BaseRenderContracts(el);
  document.getElementById('pageSub').textContent='Check Dropbox Sign directly, then mark the result here. Signed candidates automatically appear in Onboarding.';
  const toolbar=el.querySelector('.toolbar');
  if(toolbar&&!el.querySelector('.contract-portal-links')){
    const links=document.createElement('div');links.className='contract-portal-links';links.innerHTML=`<div class="hint">Direct checks · candidate email is copied automatically from each row</div><button class="contract-check-link" onclick="openContractListV1125('pending')">CHECK PENDING ↗</button><button class="contract-check-link contract-view-signed" onclick="openContractListV1125('signed')">VIEW SIGNED ↗</button>`;toolbar.insertAdjacentElement('beforebegin',links);
  }
  el.querySelectorAll('#contractRows tr[data-search]').forEach(row=>{
    const email=row.querySelector('.person span')?.textContent?.trim()||'';
    const c=state.candidates.find(x=>String(x.email||'').trim().toLowerCase()===email.toLowerCase());if(!c)return;
    const cell=row.children[4];if(!cell)return;
    if(c.status==='contract_signed')cell.innerHTML=`<button class="contract-check-link contract-view-signed" onclick="openContractPortalV1125(${c.id},'signed')">VIEW SIGNED ↗</button><div class="contract-lookup-note">copies email + opens Signed</div>`;
    else cell.innerHTML=`<button class="contract-check-link" onclick="openContractPortalV1125(${c.id},'pending')">CHECK ↗</button><div class="contract-lookup-note">copies email + opens Pending</div>`;
  });
};

function renderOnboardingV1125(el){
  header('Onboarding','Signed candidates live here until Amazon onboarding is complete. Check progress only when it is due.');
  const all=v1125OnboardingCandidates();const active=all.filter(c=>v1125OnboardingState(c)!=='complete');const complete=all.filter(c=>v1125OnboardingState(c)==='complete');const due=active.filter(v1125OnboardingDue);const training=active.filter(c=>v1125OnboardingState(c)==='training_ready');
  let rows=v1125OnboardingFilter==='complete'?complete:v1125OnboardingFilter==='all'?all:active;
  rows=rows.slice().sort((a,b)=>Number(v1125OnboardingDue(b))-Number(v1125OnboardingDue(a))||Date.parse(a.onboardingLastChecked||a.contractSignedAt||0)-Date.parse(b.onboardingLastChecked||b.contractSignedAt||0));
  el.innerHTML=`<div class="onboarding-shell"><div class="onboarding-summary"><div class="onboarding-kpi"><b>${active.length}</b><span>Currently onboarding</span></div><div class="onboarding-kpi ${due.length?'due':''}"><b>${due.length}</b><span>Checks due now</span></div><div class="onboarding-kpi ${training.length?'training':''}"><b>${training.length}</b><span>Training needs sending</span></div><div class="onboarding-kpi good"><b>${complete.length}</b><span>Completed</span></div></div><div class="onboarding-top"><div class="sub">Each CHECK copies the candidate name and opens your Amazon Associates page.</div><button class="cta red" onclick="openAmazonOnboardingV1125()">Open Amazon Onboarding ↗</button></div><div class="tabs"><button class="tab ${v1125OnboardingFilter==='active'?'active':''}" onclick="setOnboardingFilterV1125('active')">Active ${active.length}</button><button class="tab ${v1125OnboardingFilter==='complete'?'active':''}" onclick="setOnboardingFilterV1125('complete')">Complete ${complete.length}</button><button class="tab ${v1125OnboardingFilter==='all'?'active':''}" onclick="setOnboardingFilterV1125('all')">All ${all.length}</button></div><div class="onboarding-table-wrap"><table class="onboarding-table"><thead><tr><th>Candidate</th><th>Contract signed</th><th>Amazon status</th><th>Last checked</th><th>Next check</th><th>Actions</th></tr></thead><tbody>${rows.map(c=>{const signed=c.contractSignedAt?fmtElapsed(hoursSince(c.contractSignedAt))+' ago':'—';const last=c.onboardingLastChecked?fmtElapsed(hoursSince(c.onboardingLastChecked))+' ago':'Never';const dueNow=v1125OnboardingDue(c);return `<tr><td class="person"><b>${esc(c.name)}</b><span>${esc(c.email||'')}</span></td><td>${signed}</td><td>${v1125OnboardingBadge(c)}</td><td>${last}</td><td>${v1125NextCheckText(c)}</td><td><div class="onboarding-actions"><button class="act onboarding-check ${dueNow?'':'ok'}" onclick="openOnboardingProgressV1125(${c.id})">CHECK PROGRESS ↗</button>${v1125OnboardingState(c)!=='complete'?`<button class="act" onclick="markOnboardingV1125(${c.id},'in_progress')">Still onboarding</button><button class="act" onclick="markOnboardingV1125(${c.id},'training_ready')">14/15 · Training</button>${v1125OnboardingState(c)==='training_ready'?`<button class="act" onclick="markOnboardingV1125(${c.id},'training_sent')">Training sent</button>`:''}<button class="act" onclick="markOnboardingV1125(${c.id},'complete')">15/15 · Complete</button>`:`<button class="act" onclick="openProfile(${c.id})">Profile</button>`}</div></td></tr>`}).join('')||'<tr><td colspan="6"><div class="empty">No candidates in this onboarding view.</div></td></tr>'}</tbody></table></div></div>`;
}

const v1125BaseRender=render;
render=function(){const el=document.getElementById('content');if(currentPage==='onboarding')return renderOnboardingV1125(el);return v1125BaseRender()};

const v1125BaseRenderHome=renderHome;
renderHome=function(el){
  v1125BaseRenderHome(el);
  const grid=el.querySelector('.lite-grid');if(!grid||grid.querySelector('.onboarding-home'))return;
  const all=v1125OnboardingCandidates(),active=all.filter(c=>v1125OnboardingState(c)!=='complete'),due=active.filter(v1125OnboardingDue),training=active.filter(c=>v1125OnboardingState(c)==='training_ready');
  const card=document.createElement('div');card.className=`card clickable onboarding-home ${due.length?'due':''}`;card.onclick=()=>go('onboarding');card.innerHTML=`<div class="lite-title"><div><div class="mini-label">After contract</div><h3>◉ Onboarding</h3></div><div class="iconbox">◉</div></div><div class="contract-stats"><div class="contract-stat"><b>${active.length}</b><span>Active</span></div><div class="contract-stat"><b>${due.length}</b><span>Check now</span></div><div class="contract-stat"><b>${training.length}</b><span>Training</span></div></div>${active.length?`<div class="mini-list">${active.slice(0,3).map(c=>`<div class="onboarding-name-row"><b>${esc(c.name)}</b><span>${v1125OnboardingDue(c)?'Check due':esc(v1125OnboardingLabel(c))}</span></div>`).join('')}</div>`:'<div class="attention-line" style="color:#80dca6"><span class="attention-dot" style="background:#34c979;box-shadow:none"></span>No active onboarding</div>'}<div class="quick-footer"><button class="cta ${due.length?'red':''}" onclick="event.stopPropagation();go('onboarding')">${due.length?'Check onboarding →':'Open Onboarding →'}</button></div>`;
  const contracts=grid.querySelector('.lite-contracts');if(contracts)contracts.insertAdjacentElement('afterend',card);else grid.appendChild(card);
};

setInterval(()=>{if(currentPage==='home'||currentPage==='onboarding')render()},15*60*1000);


// v1.1.26 — cleaner onboarding cards + name/email contract lookup.
(function addV1126Styles(){
  if(document.getElementById('v1126Styles'))return;
  const st=document.createElement('style');st.id='v1126Styles';st.textContent=`
    .mini-copy-row{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.mini-copy-btn{border:1px solid #343c44;background:#15191d;color:#cfd5da;border-radius:6px;padding:4px 7px;font-size:7px;line-height:1.2}.mini-copy-btn:hover{border-color:#65717b;color:#fff}.mini-copy-btn.disabled{opacity:.4;cursor:default}
    .onboarding-list-v1126{display:flex;flex-direction:column;gap:9px}.onboarding-card-v1126{display:grid;grid-template-columns:minmax(190px,1.05fr) minmax(220px,1fr) minmax(330px,1.55fr);gap:14px;align-items:center;background:linear-gradient(180deg,#121619,#0f1316);border:1px solid #293038;border-radius:10px;padding:13px 14px}.onboarding-card-v1126.due{border-color:#6f3038;box-shadow:0 0 20px rgba(242,47,61,.06)}.onboarding-person-v1126 b{display:block;font-size:12px}.onboarding-person-v1126>span{display:block;color:#8e98a1;font-size:8px;margin-top:3px;overflow-wrap:anywhere}.onboarding-meta-v1126{display:grid;grid-template-columns:1fr 1fr;gap:7px}.onboarding-meta-box{border:1px solid #252d33;background:#0e1215;border-radius:7px;padding:8px}.onboarding-meta-box span{display:block;color:#77838d;font-size:7px;text-transform:uppercase;letter-spacing:.06em}.onboarding-meta-box b{display:block;margin-top:3px;font-size:9px}.onboarding-status-line{grid-column:1/-1;display:flex;align-items:center;justify-content:space-between;gap:8px;border-bottom:1px solid #242a2f;padding-bottom:8px;margin-bottom:1px}.onboarding-status-line .onboarding-state{font-size:8px}.onboarding-actions-v1126{display:flex;flex-direction:column;gap:7px}.onboarding-main-check{width:100%;padding:10px 11px!important;font-size:9px!important}.onboarding-choice-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.onboarding-choice-row button{min-height:34px;padding:6px!important;font-size:7px!important;white-space:normal}.onboarding-choice-row.four{grid-template-columns:repeat(4,minmax(0,1fr))}.contract-person-tools{margin-top:5px}
    @media(max-width:1180px){.onboarding-card-v1126{grid-template-columns:minmax(180px,.9fr) minmax(200px,1fr)}.onboarding-actions-v1126{grid-column:1/-1}.onboarding-choice-row button{font-size:8px!important}}
    @media(max-width:760px){.onboarding-card-v1126{grid-template-columns:1fr}.onboarding-actions-v1126{grid-column:auto}.onboarding-meta-v1126{grid-template-columns:1fr 1fr}.onboarding-choice-row,.onboarding-choice-row.four{grid-template-columns:1fr 1fr}}
  `;document.head.appendChild(st);
})();

window.copyCandidateNameV1126=async function(id){const c=state.candidates.find(x=>x.id===id);if(!c)return;await copyText(c.name||'','Candidate name copied')};
window.copyCandidateEmailV1126=async function(id){const c=state.candidates.find(x=>x.id===id);if(!c)return;if(!c.email){toast('No email saved for this candidate');return}await copyText(c.email,'Candidate email copied')};

// Name is the safest common lookup because some candidates do not have an email saved.
window.openContractPortalV1125=async function(id,mode='pending'){
  const c=state.candidates.find(x=>x.id===id);if(!c)return;
  if(c.name)await copyText(c.name,`Name copied · opening ${mode==='signed'?'Signed':'Pending'} contracts`);
  await window.mbl.openExternal(mode==='signed'?V1125_SIGNED_CONTRACTS_URL:V1125_PENDING_CONTRACTS_URL);
};

const v1126BaseRenderContracts=renderContracts;
renderContracts=function(el){
  v1126BaseRenderContracts(el);
  const hint=el.querySelector('.contract-portal-links .hint');if(hint)hint.textContent='Direct checks · CHECK copies the candidate name. Use the small buttons for name or email search.';
  el.querySelectorAll('#contractRows tr[data-search]').forEach(row=>{
    const person=row.querySelector('.person');if(!person)return;
    const name=person.querySelector('b')?.textContent?.trim()||'';
    const email=person.querySelector('span')?.textContent?.trim()||'';
    let matches=state.candidates.filter(x=>String(x.name||'').trim().toLowerCase()===name.toLowerCase() && ['contract_pending','contract_quiet','contract_signed'].includes(x.status));
    let c=(email?matches.find(x=>String(x.email||'').trim().toLowerCase()===email.toLowerCase()):null)||matches[0];
    if(!c)return;
    if(!person.querySelector('.contract-person-tools')){
      const tools=document.createElement('div');tools.className='mini-copy-row contract-person-tools';
      tools.innerHTML=`<button class="mini-copy-btn" onclick="copyCandidateNameV1126(${c.id})">Copy name</button>${c.email?`<button class="mini-copy-btn" onclick="copyCandidateEmailV1126(${c.id})">Copy email</button>`:`<span class="mini-copy-btn disabled">No email</span>`}`;
      person.appendChild(tools);
    }
    const cell=row.children[4];if(!cell)return;
    if(c.status==='contract_signed')cell.innerHTML=`<button class="contract-check-link contract-view-signed" onclick="openContractPortalV1125(${c.id},'signed')">VIEW SIGNED ↗</button><div class="contract-lookup-note">copies name + opens Signed</div>`;
    else cell.innerHTML=`<button class="contract-check-link" onclick="openContractPortalV1125(${c.id},'pending')">CHECK ↗</button><div class="contract-lookup-note">copies name + opens Pending</div>`;
  });
};

renderOnboardingV1125=function(el){
  header('Onboarding','Signed candidates stay here until Amazon onboarding is complete. The layout now stays clean at half-screen size.');
  const all=v1125OnboardingCandidates();const active=all.filter(c=>v1125OnboardingState(c)!=='complete');const complete=all.filter(c=>v1125OnboardingState(c)==='complete');const due=active.filter(v1125OnboardingDue);const training=active.filter(c=>v1125OnboardingState(c)==='training_ready');
  let rows=v1125OnboardingFilter==='complete'?complete:v1125OnboardingFilter==='all'?all:active;
  rows=rows.slice().sort((a,b)=>Number(v1125OnboardingDue(b))-Number(v1125OnboardingDue(a))||Date.parse(a.onboardingLastChecked||a.contractSignedAt||0)-Date.parse(b.onboardingLastChecked||b.contractSignedAt||0));
  el.innerHTML=`<div class="onboarding-shell"><div class="onboarding-summary"><div class="onboarding-kpi"><b>${active.length}</b><span>Currently onboarding</span></div><div class="onboarding-kpi ${due.length?'due':''}"><b>${due.length}</b><span>Checks due now</span></div><div class="onboarding-kpi ${training.length?'training':''}"><b>${training.length}</b><span>Training needs sending</span></div><div class="onboarding-kpi good"><b>${complete.length}</b><span>Completed</span></div></div><div class="onboarding-top"><div class="sub">CHECK PROGRESS copies the candidate name and opens Amazon Associates. Name/email can also be copied separately.</div><button class="cta red" onclick="openAmazonOnboardingV1125()">Open Amazon Onboarding ↗</button></div><div class="tabs"><button class="tab ${v1125OnboardingFilter==='active'?'active':''}" onclick="setOnboardingFilterV1125('active')">Active ${active.length}</button><button class="tab ${v1125OnboardingFilter==='complete'?'active':''}" onclick="setOnboardingFilterV1125('complete')">Complete ${complete.length}</button><button class="tab ${v1125OnboardingFilter==='all'?'active':''}" onclick="setOnboardingFilterV1125('all')">All ${all.length}</button></div><div class="onboarding-list-v1126">${rows.map(c=>{const signed=c.contractSignedAt?fmtElapsed(hoursSince(c.contractSignedAt))+' ago':'—';const last=c.onboardingLastChecked?fmtElapsed(hoursSince(c.onboardingLastChecked))+' ago':'Never';const dueNow=v1125OnboardingDue(c);const stateNow=v1125OnboardingState(c);const choiceClass=stateNow==='training_ready'?'four':'';return `<div class="onboarding-card-v1126 ${dueNow?'due':''}"><div class="onboarding-person-v1126"><b>${esc(c.name)}</b><span>${esc(c.email||'No email saved')}</span><div class="mini-copy-row"><button class="mini-copy-btn" onclick="copyCandidateNameV1126(${c.id})">Copy name</button>${c.email?`<button class="mini-copy-btn" onclick="copyCandidateEmailV1126(${c.id})">Copy email</button>`:`<span class="mini-copy-btn disabled">No email</span>`}</div></div><div class="onboarding-meta-v1126"><div class="onboarding-status-line"><span style="font-size:7px;color:#77838d;text-transform:uppercase">Amazon status</span>${v1125OnboardingBadge(c)}</div><div class="onboarding-meta-box"><span>Contract signed</span><b>${signed}</b></div><div class="onboarding-meta-box"><span>Last checked</span><b>${last}</b></div><div class="onboarding-meta-box" style="grid-column:1/-1"><span>Next check</span><b>${v1125NextCheckText(c)}</b></div></div><div class="onboarding-actions-v1126"><button class="act onboarding-check onboarding-main-check ${dueNow?'':'ok'}" onclick="openOnboardingProgressV1125(${c.id})">CHECK PROGRESS ↗</button>${stateNow!=='complete'?`<div class="onboarding-choice-row ${choiceClass}"><button class="act" onclick="markOnboardingV1125(${c.id},'in_progress')">Still onboarding</button><button class="act" onclick="markOnboardingV1125(${c.id},'training_ready')">14/15 · Training</button>${stateNow==='training_ready'?`<button class="act" onclick="markOnboardingV1125(${c.id},'training_sent')">Training sent</button>`:''}<button class="act" onclick="markOnboardingV1125(${c.id},'complete')">15/15 · Complete</button></div>`:`<button class="act" onclick="openProfile(${c.id})">Open profile</button>`}</div></div>`}).join('')||'<div class="empty">No candidates in this onboarding view.</div>'}</div></div>`;
};

// v1.1.27 — make Amazon status plain readable text instead of a tiny pill.
(function addV1127StatusStyles(){
  if(document.getElementById('v1127StatusStyles'))return;
  const st=document.createElement('style');st.id='v1127StatusStyles';st.textContent=`
    .onboarding-status-text{display:inline-block;font-size:9px!important;font-weight:800;line-height:1.35!important;padding:0!important;border:0!important;background:transparent!important;white-space:normal!important;overflow:visible!important;min-width:0!important;height:auto!important}
    .onboarding-status-text.progress{color:#9fc5ff}.onboarding-status-text.training{color:#ffd176}.onboarding-status-text.sent{color:#d8b2ff}.onboarding-status-text.complete{color:#83e5ad}
    .onboarding-status-line{min-height:28px;align-items:flex-start!important}.onboarding-status-line>span:first-child{padding-top:1px}
  `;document.head.appendChild(st);
})();

v1125OnboardingBadge=function(c){
  const s=v1125OnboardingState(c),cls=s==='training_ready'?'training':s==='training_sent'?'sent':s==='complete'?'complete':'progress';
  return `<span class="onboarding-status-text ${cls}">${esc(v1125OnboardingLabel(c))}</span>`;
};


// v1.1.28 — cancel upcoming induction from candidate profile.
(function addV1128CancelInductionStyles(){
  if(document.getElementById('v1128CancelInductionStyles'))return;
  const st=document.createElement('style');st.id='v1128CancelInductionStyles';st.textContent=`
    .cancel-induction-v1128{width:100%;margin-top:8px;border:1px solid #9a3a45;background:#261417;color:#ff9da5;border-radius:8px;padding:10px 12px;font-weight:800;font-size:11px}
    .cancel-induction-v1128:hover{border-color:#f22f3d;background:#31161b;color:#ffd0d4}
  `;document.head.appendChild(st);
})();

const v1128BaseStatusLabel=statusLabel;
statusLabel=function(c){
  if(c?.cancelledInductionByCandidate && c.status==='not_interested'){
    return (!c.mblId || c.localOnly) ? 'Local · Not Attending' : 'Not Attending';
  }
  return v1128BaseStatusLabel(c);
};

window.cancelUpcomingInductionV1128=function(id){
  const c=state.candidates.find(x=>x.id===id);if(!c)return;
  const date=c.induction||parseApiDate(c.officialInduction)||'';
  if(!date){toast('No induction is currently booked for this candidate');return;}
  const time=getDefaultInductionTime();
  const ok=confirm(`Mark ${c.name} as NOT ATTENDING ${date} at ${time}?\n\nThis removes them from your induction list and updates official MBL to Not Coming / Declined.\n\nYou can still book them onto another induction later if they change their mind.`);
  if(!ok)return;
  const expected=expectedFor(c);
  snapshot(c.id);
  c.history=c.history||[];
  c.cancelledInductionByCandidate=true;
  c.cancelledInductionDate=date;
  c.cancelledInductionAt=new Date().toISOString();
  c.status='not_interested';
  c.induction=null;
  c.history.push([nowStamp(),'Induction cancelled · Not attending',`Candidate contacted recruitment and said they will not attend ${date} at ${time}`]);
  try{removeFromActiveQueue(c.id)}catch{}
  save();
  queueSync(c,{type:'declined',note:`Candidate contacted recruitment and said they will not attend induction on ${date} at ${time}.`,expected});
  toast(`${c.name} removed from ${date} induction · marked Not Attending`);
  render();
};

const v1128BaseRenderProfile=renderProfile;
renderProfile=function(el){
  v1128BaseRenderProfile(el);
  const c=state.candidates.find(x=>x.id===profileId);if(!c)return;
  const bookedDate=c.induction||parseApiDate(c.officialInduction)||'';
  if(c.status!=='confirmed'||!bookedDate)return;
  const confirmBtn=[...el.querySelectorAll('.profile-grid .card button')].find(b=>String(b.textContent||'').includes('Set / Change Induction'));
  if(!confirmBtn||el.querySelector('.cancel-induction-v1128'))return;
  const b=document.createElement('button');
  b.className='cancel-induction-v1128';
  b.textContent='✕ Not Attending / Cancel Induction';
  b.onclick=()=>window.cancelUpcomingInductionV1128(c.id);
  confirmBtn.insertAdjacentElement('afterend',b);
};


// v1.1.29 — contract reminder text + Phone Link shortcut.
(function addV1129ContractReminderStyles(){
  if(document.getElementById('v1129ContractReminderStyles'))return;
  const st=document.createElement('style');st.id='v1129ContractReminderStyles';st.textContent=`
    .contract-text-v1129{border:1px solid #315a8c!important;background:#10233a!important;color:#a9ccff!important;font-weight:800!important}
    .contract-text-v1129:hover{border-color:#4d93ff!important;color:#fff!important}
    .contract-text-v1129.disabled{opacity:.42;cursor:default}
  `;document.head.appendChild(st);
})();

function v1129FirstName(c){
  return String(c?.name||'').trim().split(/\s+/)[0]||'there';
}
function buildContractReminderV1129(c){
  return `Hi ${v1129FirstName(c)},

Hope you're well. You should have received your MBL Delivery Driver contract by email by now, ready for you to review and sign.

Once you've signed it, please send me a quick message to let me know so I can move you onto the next stage of onboarding.

If you've decided that you no longer wish to proceed with the role, that's absolutely fine — just let me know and I'll close your application on our recruitment system.

If you're having any trouble finding or signing the contract, just message me and I'll help.

Thanks,
Reece
MBL Logistics`;
}

window.textContractReminderV1129=async function(id){
  const c=state.candidates.find(x=>x.id===id);if(!c)return;
  const tel=String(c.phone||'').replace(/[^\d+]/g,'');
  if(!tel){toast('No phone number saved for this candidate');return;}
  await copyText(buildContractReminderV1129(c),'Contract reminder copied · opening messages');
  c.history=c.history||[];
  c.history.push([nowStamp(),'Contract reminder copied','Follow-up message copied and candidate message thread opened']);
  save();
  setTimeout(()=>textCandidate(id),80);
};

const v1129BaseRenderContracts=renderContracts;
renderContracts=function(el){
  v1129BaseRenderContracts(el);
  el.querySelectorAll('#contractRows tr[data-search]').forEach(row=>{
    const person=row.querySelector('.person');if(!person)return;
    const name=person.querySelector('b')?.textContent?.trim()||'';
    const email=person.querySelector('span')?.textContent?.trim()||'';
    let matches=state.candidates.filter(x=>String(x.name||'').trim().toLowerCase()===name.toLowerCase() && ['contract_pending','contract_quiet','contract_signed'].includes(x.status));
    const c=(email?matches.find(x=>String(x.email||'').trim().toLowerCase()===email.toLowerCase()):null)||matches[0];
    if(!c)return;
    const actionCell=[...row.children].find(td=>[...td.querySelectorAll('button')].some(b=>/Checked|Mark Signed|requirements/i.test(String(b.textContent||''))));
    if(!actionCell||actionCell.querySelector('.contract-text-v1129'))return;
    const firstAction=actionCell.querySelector('button');
    const b=document.createElement('button');
    b.className='act contract-text-v1129'+(c.phone?'':' disabled');
    b.textContent=c.phone?'💬 Text Reminder':'No phone';
    b.title=c.phone?'Copy contract reminder and open this candidate in Phone Link':'No phone number saved';
    if(c.phone)b.onclick=()=>window.textContractReminderV1129(c.id);
    if(firstAction)firstAction.insertAdjacentElement('beforebegin',b);else actionCell.appendChild(b);
  });
};


// v1.1.31 — call priority is local-only: never write these preferences to official MBL.
state.personalCallSkips = state.personalCallSkips || {};
function v1131CallKey(c){return String(c.mblId || 'local:'+c.id);}
function v1131HadCall(c){
  const count=Math.max(0,Number(c.officialAttempts || 0),Number(c.attempts || 0));
  const history=(c.history || []).some(h=>/^(Called — No Answer|Will Let Us Know|Not Interested|Confirmed|Induction cancelled)/i.test(String(h?.[1] || '')));
  return count>0 || history;
}
function v1131Skipped(c){return !!state.personalCallSkips[v1131CallKey(c)];}
function v1131NewCalls(){return state.candidates.filter(c=>c.status==='to_call'&&!v1131Skipped(c)&&!v1131HadCall(c));}
function v1131PreviousCalls(){return state.candidates.filter(c=>c.status==='to_call'&&!v1131Skipped(c)&&v1131HadCall(c));}
function v1131SkippedCalls(){return state.candidates.filter(c=>c.status==='to_call'&&v1131Skipped(c));}
window.setPersonalCallSkipV1131=function(id,skip){
  const c=state.candidates.find(x=>x.id===id);if(!c)return;
  const key=v1131CallKey(c);
  if(skip)state.personalCallSkips[key]={at:new Date().toISOString()};
  else delete state.personalCallSkips[key];
  // No queueSync, set_call_stage or other official MBL write.
  save();render();
  toast(skip?c.name+' hidden from personal calling':c.name+' restored to personal calling');
};
const v1131BaseStartCalling=startCalling;
startCalling=function(queueIds=null){
  // Explicit queues such as the weekly follow-up retain existing behaviour.
  if(Array.isArray(queueIds))return v1131BaseStartCalling(queueIds);
  const ids=v1131NewCalls().map(c=>c.id);
  if(!ids.length){toast('No new uncalled candidates. Previous calls are in their own section.');return;}
  return v1131BaseStartCalling(ids);
};
window.startPreviousCallsV1131=function(){
  const ids=v1131PreviousCalls().map(c=>c.id);
  if(!ids.length){toast('No previously called candidates');return;}
  v1131BaseStartCalling(ids);
};
window.startAllCallsV1131=function(){
  v1131BaseStartCalling([...v1131NewCalls(),...v1131PreviousCalls()].map(c=>c.id));
};
(function v1131Styles(){
  const st=document.createElement('style');st.id='v1131CallPriorityStyles';
  st.textContent='.call-priority-strip{display:flex;flex-wrap:wrap;gap:10px;align-items:center;border:1px solid #343c42;background:#111719;border-radius:10px;padding:10px 12px;margin:10px 0 12px;font-size:10px;color:#bec7ce}.call-priority-strip strong{color:#9ee9c0;font-size:12px}.call-priority-strip .retry-count{color:#ffc976}#callRows .call-priority-heading td{background:#192124!important;color:#9ce3bb;font-size:10px;font-weight:800;padding:10px 12px}#callRows .call-priority-heading.prior td{background:#261f15!important;color:#ffd08d}#callRows .call-priority-heading.skipped td{background:#1c1b21!important;color:#a7a2b7}#callRows tr.local-skip-row{opacity:.6}.personal-skip-btn{border:1px solid #46515a;background:#172025;color:#d6e0e6;border-radius:6px;font-size:9px;padding:6px 8px;cursor:pointer;margin-right:5px}';
  document.head.appendChild(st);
})();
const v1131BaseRenderCallList=renderCallList;
renderCallList=function(el){
  v1131BaseRenderCallList(el);
  if(callFilter!=='to_call')return;
  const fresh=v1131NewCalls(),prior=v1131PreviousCalls(),skipped=v1131SkippedCalls();
  const toolbar=el.querySelector('.toolbar'),tableBody=el.querySelector('#callRows');
  if(!toolbar||!tableBody)return;
  const summary=document.createElement('div');
  summary.className='call-priority-strip';
  summary.innerHTML='<span><strong>'+fresh.length+' new calls</strong> (no prior phone attempt)</span><span class="retry-count">'+prior.length+' previously called</span><span>'+skipped.length+' locally skipped</span><span>Official MBL unchanged</span>';
  toolbar.insertAdjacentElement('beforebegin',summary);
  const defaultButton=toolbar.querySelector('.cta.red');
  if(defaultButton)defaultButton.textContent='Start New Calls ('+fresh.length+')';
  const retryButton=document.createElement('button');retryButton.className='act';
  retryButton.textContent='Previously Called ('+prior.length+')';
  retryButton.onclick=()=>window.startPreviousCallsV1131();toolbar.appendChild(retryButton);
  const allButton=document.createElement('button');allButton.className='act';
  allButton.textContent='Call All (New First)';
  allButton.onclick=()=>window.startAllCallsV1131();toolbar.appendChild(allButton);
  function row(c){
    const skip=v1131Skipped(c);
    const button='<button class="personal-skip-btn" title="Local to this PC. Does not change official MBL." onclick="setPersonalCallSkipV1131('+c.id+','+String(!skip)+')">'+(skip?'Restore':'Skip')+'</button>';
    return callRow(c).replace('<td><button class="callbtn"','<td>'+button+'<button class="callbtn"').replace('<tr data-search=','<tr '+(skip?'class="local-skip-row" ':'')+'data-search=');
  }
  function group(label,cls,items){
    if(!items.length)return '';
    return '<tr class="call-priority-heading '+cls+'"><td colspan="6">'+label+' ('+items.length+')</td></tr>'+items.map(row).join('');
  }
  tableBody.innerHTML=group('NEW — no previous calls','fresh',fresh)+group('PREVIOUSLY CALLED — optional reattempts','prior',prior)+group('SKIPPED IN MY HUB — official MBL unchanged','skipped',skipped);
  if(!tableBody.innerHTML)tableBody.innerHTML='<tr><td colspan="6"><div class="empty">No candidates in this category.</div></td></tr>';
};
const v1131BaseRenderCallMode=renderCallMode;
renderCallMode=function(el){
  v1131BaseRenderCallMode(el);
  const span=el.querySelector('.call-head .counter span');
  if(span&&state.callQueue){
    const people=callCandidates();
    span.textContent=people.every(c=>!v1131HadCall(c))?'New calls':people.every(v1131HadCall)?'Previously called':'New first · reattempts later';
  }
};
const v1131BaseRenderHome=renderHome;
renderHome=function(el){
  v1131BaseRenderHome(el);
  const fresh=v1131NewCalls(),prior=v1131PreviousCalls(),skipped=v1131SkippedCalls();
  const count=el.querySelector('.lite-call .lite-number'),sub=el.querySelector('.lite-call .lite-sub');
  if(count)count.textContent=String(fresh.length);
  if(sub)sub.textContent='New calls · '+prior.length+' previously called · '+skipped.length+' skipped';
  const topChip=el.querySelector('.today-strip .today-chip');
  if(topChip){
    const b=topChip.querySelector('b'),span=topChip.querySelector('span');
    if(b)b.textContent=String(fresh.length);
    if(span)span.textContent='New calls';
  }
};


// v1.1.32 — provisional induction outcomes, including existing No Answer bookings.
// No rebooking/confirmation is needed for someone who physically attended.
function v1132OfficialBookedDate(c){
  const raw=c.officialInduction || c.induction || '';
  return parseApiDate(raw) || (/^\d{2}\/\d{2}\/\d{4}$/.test(raw)?raw:'');
}
function v1132CanRecordOutcome(c){
  if(!c || !c.mblId)return false;
  const date=v1132OfficialBookedDate(c);
  if(!date || parseDMY(date)>parseDMY(todayDMY()))return false;
  // Attendance changes should be available on provisionally booked and confirmed candidates,
  // but never silently overwrite a completed contract/onboarding outcome.
  return ['to_call','no_answer','spoke_to','confirmed','archived','no_show','attended'].includes(c.status)
    && !['declined','not_hired','hired','not_meeting_requirements'].includes(String(c.officialCallStage || ''));
}
window.openBookedAttendanceV1132=function(id,source){
  const c=state.candidates.find(x=>x.id===id);
  if(!v1132CanRecordOutcome(c)){toast('Only booked inductions scheduled today or earlier can be recorded here');return;}
  if(source==='confirm')closeModal('confirmModal');
  if(source==='attendance')closeModal('attendanceModal');
  window.openInductionOutcome(id);
};
(function v1132Styles(){
  const style=document.createElement('style');style.id='v1132OutcomeStyles';
  style.textContent='.booked-attended-v1132{display:block;width:100%;border:1px solid #368b68;background:#11261d;color:#a1e8bf;border-radius:9px;padding:12px;margin:8px 0 12px;text-align:left;cursor:pointer;font-size:11px;font-weight:800}.booked-attended-v1132 small{display:block;color:#a1b4aa;font-size:9px;margin-top:4px;font-weight:500}.unconfirmed-attendees-v1132{margin-top:13px;border-top:1px solid #354049;padding-top:13px}.unconfirmed-attendees-v1132 h4{font-size:12px;margin:0 0 7px}.unconfirmed-attendees-v1132 p{font-size:10px;color:#9eacb4;margin:0 0 10px}.unconfirmed-entry-v1132{display:flex;align-items:center;justify-content:space-between;gap:10px;background:#151b1d;border:1px solid #34413d;border-radius:8px;padding:9px;margin:7px 0;font-size:10px}.unconfirmed-entry-v1132 button{border:1px solid #34845e;color:#b6ebc8;background:#12281c;border-radius:6px;padding:8px;cursor:pointer}.call-attendance-v1132{margin-left:7px;border:1px solid #34845e;color:#b6ebc8;background:#12281c;border-radius:6px;padding:7px 9px;cursor:pointer}';
  document.head.appendChild(style);
})();
const v1132BaseOpenConfirm=openConfirm;
openConfirm=async function(id){
  await v1132BaseOpenConfirm(id);
  const c=state.candidates.find(x=>x.id===id),host=document.getElementById('confirmCandidate');
  if(!host || !v1132CanRecordOutcome(c) || currentConfirmId!==id)return;
  document.getElementById('bookedAttendedShortcutV1132')?.remove();
  const button=document.createElement('button');button.id='bookedAttendedShortcutV1132';button.className='booked-attended-v1132';
  button.innerHTML='✓ They already attended — record induction outcome<small>Official MBL booking: '+esc(v1132OfficialBookedDate(c))+' · Does not book or confirm again</small>';
  button.onclick=()=>window.openBookedAttendanceV1132(id,'confirm');
  host.insertAdjacentElement('afterend',button);
};
const v1132BaseRenderProfile=renderProfile;
renderProfile=function(el){
  v1132BaseRenderProfile(el);
  const c=state.candidates.find(x=>x.id===profileId);
  if(!v1132CanRecordOutcome(c))return;
  const card=el.querySelector('.profile-grid .card');
  if(!card || card.querySelector('.booked-attended-v1132'))return;
  const button=document.createElement('button');button.className='booked-attended-v1132';
  button.innerHTML='✓ Record induction outcome<small>Already booked for '+esc(v1132OfficialBookedDate(c))+' · even if marked No Answer</small>';
  button.onclick=()=>window.openBookedAttendanceV1132(c.id);
  card.appendChild(button);
};
const v1132BaseCallRow=callRow;
callRow=function(c){
  const html=v1132BaseCallRow(c);
  if(!v1132CanRecordOutcome(c))return html;
  return html.replace('<td><button class="callbtn"', '<td><button class="call-attendance-v1132" onclick="openBookedAttendanceV1132('+c.id+')">Attendance</button><button class="callbtn"');
};
const v1132BaseRenderCallMode=renderCallMode;
renderCallMode=function(el){
  v1132BaseRenderCallMode(el);
  const c=callCandidates()[state.callIndex];
  if(!v1132CanRecordOutcome(c))return;
  const card=el.querySelector('.candidate-box');
  if(!card || card.querySelector('.booked-attended-v1132'))return;
  const button=document.createElement('button');button.className='booked-attended-v1132';
  button.innerHTML='✓ Already attended? Record induction outcome<small>Uses existing official booking '+esc(v1132OfficialBookedDate(c))+'</small>';
  button.onclick=()=>window.openBookedAttendanceV1132(c.id);
  card.appendChild(button);
};
const v1132BaseOpenAttendance=openAttendance;
openAttendance=function(keepSelections=false){
  const confirmed=state.candidates.filter(c=>c.status==='confirmed'&&c.induction===todayDMY());
  const provisional=state.candidates.filter(c=>v1132CanRecordOutcome(c)&&v1132OfficialBookedDate(c)===todayDMY()&&!['confirmed','attended'].includes(c.status));
  if(confirmed.length)v1132BaseOpenAttendance(keepSelections);
  else if(provisional.length){
    attendanceTemp={};
    document.getElementById('attendanceList').innerHTML='';
    openModal('attendanceModal');
  }else return v1132BaseOpenAttendance(keepSelections);
  const list=document.getElementById('attendanceList');
  list.querySelector('.unconfirmed-attendees-v1132')?.remove();
  if(provisional.length){
    const section=document.createElement('div');
    section.className='unconfirmed-attendees-v1132';
    section.innerHTML='<h4>Provisional bookings — not confirmed ('+provisional.length+')</h4><p>These people were already booked by MBL but did not confirm. Record an outcome ONLY for people who actually arrived; all others remain unchanged.</p>'
      +provisional.map(c=>'<div class="unconfirmed-entry-v1132"><span><strong>'+esc(c.name)+'</strong><br>'+esc(statusLabel(c))+'</span><button onclick="openBookedAttendanceV1132('+c.id+',\'attendance\')">Record outcome</button></div>').join('');
    list.appendChild(section);
  }
  const saveButton=document.querySelector('#attendanceModal .modalfoot .cta.red');
  if(saveButton)saveButton.style.display=confirmed.length?'':'none';
};
// A candidate choosing not to continue must first be recorded as Attended on MBL,
// then as Not Hired. The old handler tried Not Hired directly from No Answer.
const v1132BaseSetOutcome=window.setPastInductionOutcome;
window.setPastInductionOutcome=async function(id,outcome){
  if(outcome!=='not_proceeding')return v1132BaseSetOutcome(id,outcome);
  const c=state.candidates.find(x=>x.id===id);if(!c || !v1132CanRecordOutcome(c))return;
  const expected=expectedFor(c),date=v1132OfficialBookedDate(c);
  snapshot(c.id);c.history=c.history||[];c.induction=date;c.status='attended';
  c.history.push([nowStamp(),'Attended','Induction attended; checking whether candidate will proceed']);
  removeFromActiveQueue(c.id);
  save();closeModal('inductionOutcomeModal');closeModal('inductionDetailModal');render();
  const first=await queueSync(c,{type:'attended',expected});
  if(first?.error || first?.conflict){toast('Attendance saved locally. Resolve official MBL sync before recording Not Hired.');return;}
  const nextExpected=expectedFor(c);
  c.status='not_proceeding';c.proceeding=false;
  c.history.push([nowStamp(),'Attended — Not Proceeding','Candidate attended but chose not to continue']);
  save();render();
  const second=await queueSync(c,{type:'not_proceeding',note:'Attended induction but chose not to proceed',expected:nextExpected});
  if(second?.error || second?.conflict)toast('Not Proceeding saved locally; official MBL sync needs attention.');
};
// We intentionally reuse the existing Attended → Proceeding handler for contract checks,
// retaining its existing MBL "attended" sync and no booking/rescheduling writes.


// Allow an attendee to be recorded even before their post-induction decision is known.
// This makes it possible to revisit their profile later and select Proceeding or Not Proceeding.
const v1132OriginalOpenOutcome=window.openInductionOutcome;
window.openInductionOutcome=function(id){
  v1132OriginalOpenOutcome(id);
  const c=state.candidates.find(x=>x.id===id);
  if(!v1132CanRecordOutcome(c))return;
  const grid=document.querySelector('#inductionOutcomeBody .outcome-grid');
  if(!grid)return;
  const btn=document.createElement('button');btn.className='act';
  btn.innerHTML='Attended · decision pending<span class="outcome-help">Marks Attended on official MBL, but does not start contracts until you choose Proceeding</span>';
  btn.onclick=()=>window.recordAttendedOnlyV1132(id);
  grid.appendChild(btn);
};
window.recordAttendedOnlyV1132=function(id){
  const c=state.candidates.find(x=>x.id===id);
  if(!v1132CanRecordOutcome(c))return;
  const expected=expectedFor(c),date=v1132OfficialBookedDate(c);
  snapshot(c.id);c.status='attended';c.induction=date;c.history=c.history||[];
  c.history.push([nowStamp(),'Attended','Attended induction; proceeding decision not yet recorded']);
  removeFromActiveQueue(c.id);
  save();closeModal('inductionOutcomeModal');closeModal('inductionDetailModal');render();
  queueSync(c,{type:'attended',expected});
};


// v1.1.33 — hired mapping and post-induction licence resolution.
// Hired is a final official outcome; this only teaches the personal Hub how to display it.
clearResolvedIssues();
(function v1133SyncResolution(){
  const previousRenderSyncModal=renderSyncModal;
  function resolvableLicenceIssue(q){
    if(!q || q.action?.type!=='not_meeting_requirements' || q.action.reason!=='licence')return false;
    const c=state.candidates.find(x=>x.id===q.candidateId || x.mblId===q.mblId);
    return !!c && c.officialCallStage==='attended' && c.status==='requirements_failed';
  }
  renderSyncModal=function(){
    previousRenderSyncModal();
    const root=document.getElementById('syncModalBody');
    if(!root)return;
    for(const q of (state.syncQueue||[]).filter(resolvableLicenceIssue)){
      const c=state.candidates.find(x=>x.id===q.candidateId || x.mblId===q.mblId);
      const row=[...root.querySelectorAll('.issue-row')].find(x=>x.querySelector('b')?.textContent===c.name && x.textContent.includes("Doesn't Meet Requirements"));
      const controls=row?.querySelector('.issue-controls');
      if(!controls || controls.querySelector('.fix-licence-after-attended'))continue;
      const button=document.createElement('button');
      button.className='smallbtn fix-licence-after-attended';
      button.textContent='Resolve licence failure';
      button.title='Review an Attended → Not Hired transition with an explanatory licence-check note';
      button.onclick=()=>window.resolvePostInductionLicenceV1133(q.id);
      controls.appendChild(button);
      const explanation=document.createElement('p');
      explanation.textContent='MBL does not permit Doesn’t Meet Requirements after Attended. You can record Not Hired with a licence-check explanation instead. This requires your confirmation.';
      row.appendChild(explanation);
    }
  };
  window.resolvePostInductionLicenceV1133=async function(queueId){
    const q=(state.syncQueue||[]).find(x=>x.id===queueId);
    if(!resolvableLicenceIssue(q))return toast('This licence issue no longer needs this correction');
    const c=state.candidates.find(x=>x.id===q.candidateId || x.mblId===q.mblId);
    const msg='Mark '+c.name+' as Not Hired on official MBL because they attended but failed the driving licence eligibility check?\n\nThe Hub will retain Doesn’t Meet Requirements (Licence). The official record will gain a note explaining the licence check. The exact endorsement will NOT be stated because it is unverified.\n\nThis change will be attributed to your connected Recruitment Hub application in MBL’s audit history.';
    if(!confirm(msg))return;
    const note='Attended induction but did not pass the driving licence eligibility check. Specific endorsement not verified.';
    q.status='resolving';q.error='';c.syncState='pending';
    save();renderSyncModal();
    try{
      const r=await window.mbl.action({mblId:c.mblId,type:'not_proceeding',note,expected:expectedFor(c)});
      if(!r?.ok)throw Error(r?.error||'Official MBL update unsuccessful');
      if(r.data?.conflict)throw Error('Official record changed since the last refresh. Refresh MBL before retrying.');
      const verified=r.data?.verified?.candidate||null;
      if(verified?.callStage!=='not_hired')throw Error('MBL did not confirm the expected Not Hired status.');
      state.syncQueue=state.syncQueue.filter(x=>x.id!==q.id);
      c.officialCallStage='not_hired';c.officialStage=verified.stage||c.officialStage;
      c.status='requirements_failed';c.requirementsReason='licence';c.proceeding=false;c.syncState='synced';
      c.history=c.history||[];
      c.history.push([nowStamp(),'Licence check failed after induction','Official MBL: Not Hired; personal Hub: Does not meet requirements (Licence). Exact endorsement not recorded.']);
      save();updateSyncUiFromState();renderSyncModal();render();
      toast('Official MBL updated to Not Hired; licence failure saved');
      setTimeout(()=>refreshFromMbl(false),1200);
    }catch(e){
      q.status='failed';q.error=e.message||String(e);c.syncState='failed';
      save();updateSyncUiFromState();renderSyncModal();
      toast('Could not resolve licence outcome — '+q.error);
    }
  };
})();


  // v1.1.34 — history navigation and backdated attendance for the PC Hub only.
  // Do not use a past-day booking correction to reschedule an MBL session.
  let historyCalendarWeekShiftV1134=0;
  let historicalAttendanceDateV1134=null;
  let historicalAttendanceTempV1134={};
  const historicalTodayV1134=()=>parseDMY(todayDMY());
  const historicalDateIsPastV1134=d=>parseDMY(d)<historicalTodayV1134();

  function correctHistoricalInductionDateV1134(id,date){
    const c=state.candidates.find(x=>x.id===id);
    if(!c||!historicalDateIsPastV1134(date))return;
    const old=c.induction||parseApiDate(c.officialInduction)||'not recorded';
    snapshot(c.id);
    c.induction=date;
    c.historicalDateCorrection={date:date,recordedAt:new Date().toISOString(),previous:old};
    c.history=c.history||[];
    c.history.push([nowStamp(),'Historical induction date corrected',old+' → '+date+' (Hub-only correction; official MBL booking unchanged)']);
    if(c.status==='no_show')c.lastInduction=date;
    save();
    document.getElementById('confirmPicker').style.display='none';
    document.getElementById('confirmSuccess').classList.add('show');
    document.getElementById('copyConfirmationBtn').style.display='none';
    document.getElementById('confirmSuccessTitle').textContent='Historical date corrected';
    document.getElementById('confirmSuccessText').textContent=c.name+' is now linked to '+date+' in the Recruitment Hub. The official MBL booking date was NOT changed. Use the attendance check to record whether they came, and review any MBL sync issues.';
    document.getElementById('confirmedNextBtn').innerHTML='2&nbsp;&nbsp;Open attendance check →';
    window.__historicalCorrectionDate=date;
    toast('Historical date saved in the Hub; MBL booking unchanged');
  }

  const oldConfirmedNextV1134=document.getElementById('confirmedNextBtn').onclick;
  document.getElementById('confirmedNextBtn').onclick=function(){
    const date=window.__historicalCorrectionDate;
    if(!date)return oldConfirmedNextV1134();
    window.__historicalCorrectionDate=null;
    window.__attendanceRescheduleId=null;window.__attendanceOldDate=null;
    closeModal('confirmModal');
    document.getElementById('confirmedNextBtn').innerHTML='2&nbsp;&nbsp;Next Candidate →';
    const heading=document.querySelector('#confirmModal .modalhead h3');
    if(heading)heading.textContent='Confirm Induction';
    render();
    window.openHistoricalAttendanceV1134(date);
  };

  (function addHistoricalAttendanceModalV1134(){
    const style=document.createElement('style');
    style.textContent='.history-check-row-v1134{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:7px;align-items:center;padding:11px 9px;border:1px solid #313b41;background:#14191d;border-radius:9px;margin:8px 0}.history-check-name-v1134{font-weight:800;font-size:12px}.history-check-sub-v1134{display:block;font-size:9px;color:#a4b2bd;margin-top:4px}.history-check-row-v1134 button{min-width:77px;border:1px solid #505d64;background:#222b31;color:#fff;border-radius:7px;padding:9px 7px;cursor:pointer}.history-check-row-v1134 button.selected-yes{background:#163525;border-color:#55b37a;color:#c1f2d4}.history-check-row-v1134 button.selected-no{background:#3b1c21;border-color:#e36b77;color:#ffd0d0}.history-check-help-v1134{color:#a4b2bd;font-size:11px;line-height:1.5;margin-bottom:12px}.history-nav-v1134{display:flex;gap:5px;align-items:center}.history-nav-v1134 button{padding:2px 6px!important}.history-induction-heading-v1134{font-size:13px;font-weight:800;margin:17px 0 10px}.history-day-grid-v1134{display:grid;grid-template-columns:repeat(auto-fill,minmax(142px,1fr));gap:8px}.history-day-v1134{background:#13191d;border:1px solid #303b42;border-radius:8px;color:#e7edf1;padding:10px;text-align:left;cursor:pointer}.history-day-v1134:hover{border-color:#e74c5b}.history-day-v1134 small{display:block;color:#a4b2bd;margin-top:5px}@media(max-width:560px){.history-check-row-v1134{grid-template-columns:1fr 1fr}.history-check-row-v1134>div{grid-column:1/-1}}';
    style.textContent+=' .history-check-row-v1134 .history-continue-v1136{grid-column:1/-1;border-color:#40875e;background:#173024;color:#b4efc8;font-weight:800}.side-cal-decision-v1136{position:absolute;bottom:-2px;right:-2px;display:grid;place-items:center;width:11px;height:11px;border-radius:99px;background:#d99f39;color:#17120a;font-size:8px;font-weight:900}.history-check-row-v1134 .history-continue-v1136:hover{border-color:#78cd95}';
    document.head.appendChild(style);
    const modal=document.createElement('div');
    modal.className='modalwrap';modal.id='historicAttendanceModalV1134';
    modal.innerHTML='<div class="modal" style="width:min(740px,95vw);max-height:92vh;overflow:auto"><div class="modalhead"><h3 id="historicAttendanceTitleV1134">Previous attendance check</h3><button class="x" onclick="closeModal(\'historicAttendanceModalV1134\')">×</button></div><div class="history-check-help-v1134">Select YES if they physically attended or NO if they did not. Saved outcomes remain visible and any previous Attended records can continue to the Proceeding Yes/No step. The red calendar badge counts only people whose attendance is still unchecked. This does not create a new booking; contract/onboarding outcomes remain protected.</div><div id="historicAttendanceListV1134"></div><div class="modalfoot"><button class="smallbtn" onclick="closeModal(\'historicAttendanceModalV1134\')">Cancel</button><button class="cta red" onclick="saveHistoricalAttendanceV1134()">Save Attendance</button></div></div>';
    document.body.appendChild(modal);
  })();

  // v1.1.36 — reuse the ordinary Proceeding/Contracts flow for historical dates.
  function historicalProceedingPendingV1136(c){
    return c.status==='attended' && typeof c.proceeding!=='boolean';
  }
  function historicAttendanceProtectedV1134(c){
    return ['contract_pending','contract_quiet','contract_signed','not_proceeding',
      'requirements_failed','hired'].includes(c.status)
      || (c.status==='attended' && typeof c.proceeding==='boolean');
  }
  // A future booking is not overdue attendance. A previously completed
  // official call stage or a saved YES/NO outcome clears the day in question.
  function historicalAttendanceSummaryV1136(date){
    // A provisional MBL booking is neither a confirmed attendee nor an
    // attendance error. Only confirmed people can count as 'to check';
    // still count real saved/official outcomes separately.
    const people=historyAttendeeListV1134(date);
    const recordedOnDate=c=>{
      const evidence=recordedAttendance(c);
      if(evidence?.date===date)return true;
      const stage=String(c.officialCallStage||'');
      const officialDate=parseApiDate(c.officialInduction);
      if(['attended','not_attended','hired','not_hired'].includes(stage)&&
        officialDate===date)return true;
      return historicAttendanceProtectedV1134(c)&&
        (c.induction===date||c.lastInduction===date||
         c.historicalDateCorrection?.date===date);
    };
    const confirmed=confirmedInductionPeopleForDate(date);
    const recorded=people.filter(recordedOnDate);
    const remaining=confirmed.filter(c=>!recordedOnDate(c));
    return {
      total:new Set([...confirmed,...recorded].map(c=>c.id)).size,
      unchecked:remaining.length,
      proceeding:recorded.filter(historicalProceedingPendingV1136).length,
      recorded:recorded.length
    };
  }
  function historyAttendeeListV1134(date){
    // The old list was restricted to "Confirmed" statuses; MBL's actual
    // bookings can be provisionally in Spoke To, Call Back or To Call.
    // Read the booking date regardless of the call-board column.
    return (state.candidates||[]).filter(c=>{
      const match=!!c.mblId && parseApiDate(c.officialInduction)===date;
      const local=c.induction===date || c.lastInduction===date ||
        c.historicalDateCorrection?.date===date;
      return match||local;
    });
  }
  window.openHistoricalAttendanceV1134=function(date){
    if(!date||parseDMY(date)>historicalTodayV1134()){toast('Attendance checks are only available for today or previous dates');return;}
    if(date===todayDMY()){openAttendance();return;}
    const people=historyAttendeeListV1134(date);
    if(!people.length){toast('No confirmed bookings or recorded outcomes on this date');return;}
    historicalAttendanceDateV1134=date;
    historicalAttendanceTempV1134={};
    const title=document.getElementById('historicAttendanceTitleV1134');
    title.textContent='Attendance check · '+parseDMY(date).toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
    const list=document.getElementById('historicAttendanceListV1134');
    const summary=historicalAttendanceSummaryV1136(date);
    list.innerHTML='<p class="history-check-help-v1134"><b>'+summary.unchecked+'</b> awaiting attendance · <b>'+summary.proceeding+'</b> awaiting Proceeding decision · <b>'+summary.recorded+'</b> completed / recorded</p>'+
      people.map(c=>{
      const existing=recordedAttendance(c);
      const protectedOutcome=historicAttendanceProtectedV1134(c)||
        (existing?.date===date);
      const awaitingDecision=historicalProceedingPendingV1136(c);
      const saved=existing?.date===date
        ?(existing.outcome==='attended'?'Attended saved in Hub':'Not attended saved in Hub')
        :c.status==='attended'?'Attendance saved':c.status==='no_show'?'Absence saved':'Attendance unchecked';
      const sync=existing?.date===date&&attendanceAudit?.disagreement(c)
        ?' · ⚠ OFFICIAL MBL DOES NOT MATCH — Connection details'
        :c.syncState==='failed'?' · MBL sync needs attention':'';
      const detail='<span class="history-check-sub-v1134">'+esc(statusLabel(c)+' · '+saved+sync)+'</span>';
      const id=Number(c.id);
      return '<div class="history-check-row-v1134"><div><span class="history-check-name-v1134">'+esc(c.name)+'</span>'+detail+'</div>'+(protectedOutcome
        ? '<span class="history-check-sub-v1134" style="grid-column:span 2">Outcome already recorded — open profile to review</span>'+
          (awaitingDecision?'<button class="history-continue-v1136" onclick="resumeHistoricalProceedingV1136('+id+')">Continue → Proceeding Y/N</button>':'')
        : '<button class="'+(c.status==='attended'?'selected-yes':'')+'" id="historyYesV1134-'+id+'" onclick="setHistoricalAttendanceV1134('+id+',true)">YES · Attended</button>'+
          '<button class="'+(c.status==='no_show'?'selected-no':'')+'" id="historyNoV1134-'+id+'" onclick="setHistoricalAttendanceV1134('+id+',false)">NO · Absent</button>'+
          (awaitingDecision?'<button class="history-continue-v1136" onclick="resumeHistoricalProceedingV1136('+id+')">Continue → Proceeding Y/N</button>':'')
        )+'</div>';
    }).join('');
    openModal('historicAttendanceModalV1134');
  };
  window.resumeHistoricalProceedingV1136=function(id){
    const c=state.candidates.find(x=>x.id===id);
    if(!c||!historicalProceedingPendingV1136(c)){toast('No outstanding Proceeding decision for this candidate');return;}
    closeModal('historicAttendanceModalV1134');
    historicalAttendanceDateV1134=null;
    historicalAttendanceTempV1134={};
    startProceedFlow([id]);
  };
  window.setHistoricalAttendanceV1134=function(id,attended){
    if(!historicalAttendanceDateV1134)return;
    const c=state.candidates.find(x=>x.id===id);
    if(!c||historicAttendanceProtectedV1134(c)||!historyAttendeeListV1134(historicalAttendanceDateV1134).some(x=>x.id===id))return;
    historicalAttendanceTempV1134[id]=attended;
    const yes=document.getElementById('historyYesV1134-'+id);
    const no=document.getElementById('historyNoV1134-'+id);
    if(yes)yes.className=attended?'selected-yes':'';
    if(no)no.className=attended?'':'selected-no';
  };
  window.saveHistoricalAttendanceV1134=function(){
    const date=historicalAttendanceDateV1134,entries=Object.entries(historicalAttendanceTempV1134);
    if(!date||!entries.length){toast('Select YES or NO for at least one candidate');return;}
    if(parseDMY(date)>historicalTodayV1134()){toast('Cannot record future attendance');return;}
    let changed=0;
    const proceedingIds=[];
    for(const [rawId,attended] of entries){
      const c=state.candidates.find(x=>x.id===Number(rawId));
      if(!c||historicAttendanceProtectedV1134(c)||!historyAttendeeListV1134(date).some(x=>x.id===c.id))continue;
      const priorStatus=c.status;
      const priorDate=c.induction;
      const recordedForDay=recordedAttendance(c)?.date===date;
      const sameOutcome=attended?priorStatus==='attended':priorStatus==='no_show';
      const expected=expectedFor(c);
      // Reopening an already-recorded Attended result must not write it twice to MBL.
      if(!recordedForDay && (!sameOutcome || (attended&&priorDate!==date))){
        snapshot(c.id);
        c.history=c.history||[];
        if(attended){
          localAttendanceRecord(c,'attended',date);
          c.status='attended';c.induction=date;c.lastInduction=date;c.proceeding=null;
          c.history.push([nowStamp(),'Attended · historical check','Attended induction on '+date]);
          removeFromActiveQueue(c.id);
        }else{
          localAttendanceRecord(c,'not_attended',date);
          c.status='no_show';c.lastInduction=date;c.induction=null;c.proceeding=null;
          c.history.push([nowStamp(),'Not Attended · historical check','Did not attend induction on '+date]);
        }
        // Do not queue a second identical write if an earlier attempt failed.
        const actionType=attended?'attended':'not_attended';
        // If the recruiter explicitly reverses attendance, retire FAILED older
        // opposite writes so a later retry cannot reapply the superseded result.
        const obsolete=(state.syncQueue||[]).filter(q=>
          q.candidateId===c.id&&['attended','not_attended'].includes(q.action?.type)&&
          q.action.type!==actionType&&q.status==='failed');
        if(obsolete.length){
          const oldIds=new Set(obsolete.map(q=>q.id));
          state.syncQueue=state.syncQueue.filter(q=>!oldIds.has(q.id));
          c.history.push([nowStamp(),'Historical attendance sync corrected',
            obsolete.length+' superseded failed write(s) replaced by '+actionType]);
        }
        const alreadyQueued=(state.syncQueue||[]).some(q=>
          q.candidateId===c.id&&q.action?.type===actionType&&q.status!=='done');
        if(c.officialCallStage!==actionType&&!alreadyQueued){
          queueSync(c,{type:actionType,attendanceDate:date,expected});
        }
        changed++;
      }
      if(attended&&historicalProceedingPendingV1136(c))proceedingIds.push(c.id);
    }
    save();
    closeModal('historicAttendanceModalV1134');
    historicalAttendanceDateV1134=null;
    historicalAttendanceTempV1134={};
    render();
    if(proceedingIds.length){
      // Same post-induction Yes/No prompt and contract pipeline as today's check.
      startProceedFlow([...new Set(proceedingIds)]);
    }else{
      toast(changed
        ? changed+' attendance correction'+(changed===1?'':'s')+' saved · check MBL sync'
        : 'No new attendance changes to save');
      openInductionDetails(date);
    }
  };

  // Roll the sidebar six-week window backward one week at a time.
  window.moveHistoryCalendarV1134=function(weeks){
    const next=historyCalendarWeekShiftV1134+weeks;
    if(next<-52||next>52)return;
    historyCalendarWeekShiftV1134=next;
    renderSideCalendar();
  };
  renderSideCalendar=function(){
    const box=document.getElementById('sideCalendar');if(!box)return;
    const today=new Date();today.setHours(12,0,0,0);
    const start=new Date(today);
    start.setDate(start.getDate()-(start.getDay()+6)%7+historyCalendarWeekShiftV1134*7);
    const end=new Date(start);end.setDate(end.getDate()+41);
    let cells=['M','T','W','T','F','S','S'].map(x=>'<div class="side-cal-head">'+x+'</div>').join('');
    for(let i=0;i<42;i++){
      const d=new Date(start);d.setDate(d.getDate()+i);
      const date=formatDate(d),stats=historicalAttendanceSummaryV1136(date);
      // The little RED NUMBER counts confirmed attendees, not overdue
      // attendance and never provisionally booked people.
      const count=confirmedInductionPeopleForDate(date).length;
      const decision=stats.proceeding;
      const monthTag=d.getDate()===1||i===0?'<span class="side-month-tag">'+d.toLocaleDateString('en-GB',{month:'short'}).toUpperCase()+'</span>':'';
      const classes='side-cal-day'+(date===todayDMY()?' today':'')+
        (count?' has-event has-confirmed-v1155':'')+
        (d.getMonth()!==start.getMonth()?' other-month':'');
      const title=count?count+' confirmed attendee'+(count===1?'':'s')+
        (stats.unchecked?' · '+stats.unchecked+' awaiting attendance':'')
        :stats.recorded?stats.recorded+' attendance outcome'+(stats.recorded===1?'':'s')+' recorded'
        :'No confirmed attendees';
      cells+='<div class="'+classes+'" onclick="openInductionDetails(\''+date+'\')" title="'+title+'">'+
        monthTag+'<span class="side-cal-number-v1155">'+d.getDate()+'</span>'+
        (count?'<span class="side-cal-count" title="'+count+' confirmed">'+count+'</span>':'')+
        (!count&&decision?'<span class="side-cal-decision-v1136" title="Proceeding decision pending">!</span>':'')+
        '</div>';
    }
    const range=start.toLocaleDateString('en-GB',{day:'numeric',month:'short'})+' → '+end.toLocaleDateString('en-GB',{day:'numeric',month:'short'});
    box.innerHTML='<div class="side-calendar-title"><b>Induction calendar</b><div class="history-nav-v1134"><button title="Previous week" onclick="moveHistoryCalendarV1134(-1)">‹</button><button title="Current week" onclick="moveHistoryCalendarV1134('+(-historyCalendarWeekShiftV1134)+')">Today</button><button title="Next week" onclick="moveHistoryCalendarV1134(1)">›</button><button onclick="go(\'inductions\')">View</button></div></div><div class="side-cal-grid">'+cells+'</div><div class="side-cal-range">'+range+'</div>';
  };

  const renderPreviousInductionsV1134=renderInductions;
  renderInductions=function(el){
    renderPreviousInductionsV1134(el);
    const dates=[];
    const today=historicalTodayV1134();
    for(let i=1;i<=14;i++){
      const d=new Date(today);d.setDate(d.getDate()-i);dates.push(d);
    }
    const section=document.createElement('div');
    section.innerHTML='<h3 class="history-induction-heading-v1134">Previous 14 days · attendance corrections</h3><div class="history-day-grid-v1134">'+dates.map(d=>{
      const ds=formatDate(d),stats=historicalAttendanceSummaryV1136(ds);
      return '<button class="history-day-v1134" onclick="openInductionDetails(\''+ds+'\')"><b>'+d.toLocaleDateString('en-GB',{weekday:'short',day:'numeric',month:'short'})+'</b><small>'+stats.unchecked+' to check · '+stats.proceeding+' need Proceeding · '+stats.recorded+' recorded</small></button>';
    }).join('')+'</div>';
    el.appendChild(section);
  };

  const previousInductionDetailV1134=openInductionDetails;
  openInductionDetails=function(date){
    previousInductionDetailV1134(date);
    if(!historicalDateIsPastV1134(date))return;
    const people=historyAttendeeListV1134(date);
    if(!people.length)return;
    const body=document.getElementById('inductionDetailBody');
    if(!body||body.querySelector('.history-check-open-v1134'))return;
    const stats=historicalAttendanceSummaryV1136(date);
    const caption=document.createElement('p');
    caption.className='history-check-help-v1134';
    caption.style.marginTop='10px';
    caption.textContent=stats.unchecked+' awaiting attendance · '+stats.proceeding+' awaiting Proceeding · '+stats.recorded+' completed / recorded';
    body.appendChild(caption);
    const btn=document.createElement('button');
    btn.className='cta red history-check-open-v1134';
    btn.textContent='Attendance Check · '+date;
    btn.style.cssText='width:100%;margin-top:12px';
    btn.onclick=function(){closeModal('inductionDetailModal');window.openHistoricalAttendanceV1134(date);};
    body.appendChild(btn);
  };
  window.openInductionDetails=openInductionDetails;


  // v1.1.37 — separate day-before induction reminders and copyable AmiGO training pack.
  const V1137_ANDROID_URL='https://play.google.com/store/apps/details?id=com.disprz.amiigo&pcampaignid=web_share';
  const V1137_IOS_URL='https://apps.apple.com/gb/app/amiigo-ai/id6760543241';

  (function addV1137Styles(){
    const style=document.createElement('style');
    style.id='v1137RecruitmentMessagesStyles';
    style.textContent=[
      '.day-before-note-v1137{margin:10px 0;border:1px solid #315a8c;background:#132233;color:#bad9fb;border-radius:9px;padding:9px 12px;font-size:10px;line-height:1.5}',
      '.day-before-reminder-v1137{border-color:#356895!important;background:#122c43!important;color:#bde1ff!important;font-weight:800!important;white-space:nowrap}',
      '.day-before-reminder-v1137:hover{border-color:#79baff!important}',
      '.training-pack-v1137{border:1px solid #536c35;border-radius:9px;padding:11px;margin-top:8px;background:#172119}',
      '.training-pack-title-v1137{font-size:10px;font-weight:900;color:#c3efaa;margin-bottom:7px}',
      '.training-pack-fields-v1137{display:grid;grid-template-columns:minmax(140px,1.4fr) minmax(100px,.8fr);gap:7px}',
      '.training-pack-fields-v1137 label{font-size:8px;color:#bdc9b8;display:block;margin:0 0 4px}',
      '.training-pack-fields-v1137 input{width:100%;min-width:0;background:#0c1411;border:1px solid #45564a;color:#f4fff5;border-radius:7px;padding:8px;font-size:11px}',
      '.training-pack-actions-v1137{display:flex;gap:7px;align-items:center;flex-wrap:wrap;margin-top:8px}',
      '.training-pack-copy-v1137{background:#25482e!important;color:#dcffe1!important;border:1px solid #4b985e!important;font-weight:900!important;padding:9px 12px!important}',
      '.training-pack-hint-v1137{display:block;font-size:8px;line-height:1.5;color:#a9b8aa;margin-top:7px}',
      '@media(max-width:520px){.training-pack-fields-v1137{grid-template-columns:1fr}}'
    ].join('');
    document.head.appendChild(style);
  })();

  function v1137TomorrowDate(){
    const d=parseDMY(todayDMY());
    d.setDate(d.getDate()+1);
    return formatDate(d);
  }
  function v1137IsTomorrow(date){
    return date===v1137TomorrowDate();
  }
  function buildDayBeforeReminderV1137(c){
    const name=firstName(String(c?.name||'').trim())||'there';
    const time=formatTime12(getDefaultInductionTime());
    return [
      'Hello '+name+',',
      '',
      'Just a reminder that your MBL Delivery Driver induction is tomorrow. Please be at the Amazon DHU2 depot for '+time+'.',
      '',
      'Location:',
      'MBL / Amazon DHU2',
      'Brickyard Lane, North Ferriby',
      'HU14 3HB',
      '',
      'Please make sure you have the following documents ready:',
      '- Driving licence',
      '- Passport/visa or full British birth certificate',
      '- Proof of address dated within the last 3 months',
      '- Proof of National Insurance number',
      '',
      'When you arrive, please let security know that you are here for an MBL induction.',
      '',
      'Thank you,',
      'Reece',
      'MBL Logistics'
    ].join('\n');
  }
  window.copyDayBeforeReminderV1137=async function(id,date){
    const c=state.candidates.find(x=>x.id===id);
    if(!c||c.status!=='confirmed'||c.induction!==date||!v1137IsTomorrow(date)){
      toast('Day-before reminders can only be copied for confirmed candidates attending tomorrow');
      return;
    }
    // The official MBL time mismatch is already visible in the induction header
    // and blue information strip. No repeated confirmation popup on copy.
    await copyText(buildDayBeforeReminderV1137(c),'Tomorrow reminder copied · opening SMS for '+firstName(c.name));
    c.history=c.history||[];
    c.history.push([nowStamp(),'Day-before reminder copied','Prepared personalised reminder for '+date+'; not automatically sent']);
    c.dayBeforeReminderCopiedFor=date;
    save();
    // Copying a reminder never changes confirmation, attendance or MBL state.
    const b=document.getElementById('dayBeforeCopyV1137-'+id);
    if(b)b.textContent='✓ Copied · text again';
    // Reuse the Hub's current SMS/Phone Link handler. Opening is not sending.
    const phone=String(c.phone||'').replace(/[^\d+]/g,'');
    if(phone) setTimeout(()=>textCandidate(id),80);
    else toast('Reminder copied · no phone number saved to open Phone Link');
  };

  const v1137PreviousInductionDetail=openInductionDetails;
  openInductionDetails=function(date){
    v1137PreviousInductionDetail(date);
    if(!v1137IsTomorrow(date))return;
    const people=inductionPeopleForDate(date).filter(c=>c.status==='confirmed'&&c.induction===date);
    if(!people.length)return;
    const list=document.querySelectorAll('#inductionDetailBody .session-attendee');
    people.forEach((c,i)=>{
      const actions=list[i]?.querySelector('.session-row-actions');
      if(!actions || actions.querySelector('.day-before-reminder-v1137'))return;
      const button=document.createElement('button');
      button.className='act day-before-reminder-v1137';
      button.id='dayBeforeCopyV1137-'+c.id;
      button.textContent=c.dayBeforeReminderCopiedFor===date?'✓ Copied · text again':'📋 Copy & text reminder';
      button.title='Copy day-before text and open SMS in Windows Phone Link. Press Send manually.';
      button.onclick=()=>window.copyDayBeforeReminderV1137(c.id,date);
      actions.insertBefore(button,actions.firstChild);
    });
    const summary=document.querySelector('#inductionDetailBody .session-summary');
    if(summary && !document.querySelector('#inductionDetailBody .day-before-note-v1137')){
      const info=document.createElement('div');
      info.className='day-before-note-v1137';
      const official=officialTimeForDate(date);
      const mismatch=official&&official!==getDefaultInductionTime();
      info.textContent='Tomorrow only: copy a personalised reminder and open SMS for each confirmed candidate. This is separate from the same-day reminder. '+(mismatch?'Important: official MBL is '+formatTime12(official)+'; your message uses '+formatTime12(getDefaultInductionTime())+'. Please check the arrival time before sending.':'');
      summary.insertAdjacentElement('afterend',info);
    }
  };
  window.openInductionDetails=openInductionDetails;

  // Training instructions and login credentials are deliberately separate chat messages.
  // This text can be copied with one click; it contains no driver-specific data or password.
  function buildTrainingPackMessageV1137(){
    return [
      'Hello,',
      '',
      "Your checks have come through and you're ready to start your online training. I'll send your login details over now in a separate message.",
      '',
      'Please download the AmiGO app using the link for your phone:',
      '',
      'Android:',
      V1137_ANDROID_URL,
      '',
      'iPhone / Apple:',
      V1137_IOS_URL,
      '',
      '',
      'Once installed, use the username and password I send you to log in.',
      '',
      'Please complete your online training pack and let me know once you have finished.',
      '',
      'If you have any issues logging in or completing the training, just message me.',
      '',
      'Thanks,',
      'Reece',
      'MBL Logistics'
    ].join('\n');
  }
  window.copyTrainingPackV1137=async function(id){
    const c=state.candidates.find(x=>x.id===id);
    if(!c || !['training_ready','training_sent'].includes(c.onboardingState)){
      toast('First mark the candidate as 14/15 · Training');
      return;
    }
    await copyText(buildTrainingPackMessageV1137(),'Training pack copied · send login separately');
    c.history=c.history||[];
    c.history.push([nowStamp(),'Training pack copied','AmiGO links and instructions copied; login details must be sent separately (not yet marked sent)']);
    save();
    // Copying is not sending and never updates the candidate's onboarding stage.
  };

  const v1137PreviousRenderOnboarding=renderOnboardingV1125;
  renderOnboardingV1125=function(el){
    v1137PreviousRenderOnboarding(el);
    const all=v1125OnboardingCandidates();
    const active=all.filter(c=>v1125OnboardingState(c)!=='complete');
    const complete=all.filter(c=>v1125OnboardingState(c)==='complete');
    let rows=v1125OnboardingFilter==='complete'?complete:v1125OnboardingFilter==='all'?all:active;
    rows=rows.slice().sort((a,b)=>
      Number(v1125OnboardingDue(b))-Number(v1125OnboardingDue(a))||
      Date.parse(a.onboardingLastChecked||a.contractSignedAt||0)-Date.parse(b.onboardingLastChecked||b.contractSignedAt||0));
    const cards=el.querySelectorAll('.onboarding-card-v1126');
    rows.forEach((c,i)=>{
      if(!['training_ready','training_sent'].includes(v1125OnboardingState(c)))return;
      const actions=cards[i]?.querySelector('.onboarding-actions-v1126');
      if(!actions||actions.querySelector('.training-pack-v1137'))return;
      const pack=document.createElement('div');
      pack.className='training-pack-v1137';
      pack.innerHTML=
        '<div class="training-pack-title-v1137">📦 AmiGO online training pack · 14/15</div>'+
        '<div class="training-pack-actions-v1137">'+
        '<button class="act training-pack-copy-v1137" onclick="copyTrainingPackV1137('+c.id+')">📋 Copy training pack</button>'+
        '<button class="act" onclick="openAmazonOnboardingV1125()">↗ Amazon onboarding</button>'+
        '</div>'+
        '<span class="training-pack-hint-v1137">Copies the introduction and both AmiGO download links. Send the username and password separately in their own chat message. Copying does not mark training as sent.</span>';
      actions.appendChild(pack);
    });
    const top=el.querySelector('.onboarding-top');
    if(top&&!top.querySelector('.training-pack-top-hint-v1137')){
      const note=document.createElement('div');
      note.className='sub training-pack-top-hint-v1137';
      note.textContent='At 14/15, click “Copy training pack” to copy the AmiGO instructions. Send the driver’s login details separately.';
      top.insertAdjacentElement('afterend',note);
    }
  };


  // v1.1.38–1.1.40 — Home shortcuts, with one-click copy for training instructions.
  // Preserve previous candidate/onboarding data; remove only the visible page and tile.
  (function v1138RemoveOnboardingNavigation(){
    for(const section of ['onboarding','onboardingtest']){
      const i=navItems.findIndex(x=>x[0]===section);
      if(i>=0)navItems.splice(i,1);
    }
    renderNav();
  })();

  (function v1138InstallHomeToolStyles(){
    const style=document.createElement('style');
    style.id='v1138HomeToolStyles';
    style.textContent=[
      '.home-quick-tools-v1138{display:flex;align-items:stretch;flex-wrap:wrap;gap:9px;margin:12px 0 15px}',
      '.home-tool-tile-v1138{width:186px;min-height:115px;border:1px solid #303c46;background:#11181d;color:#edf2f5;border-radius:11px;padding:13px;display:flex;flex-direction:column;align-items:flex-start;gap:7px;text-align:left;cursor:pointer;transition:border-color .15s,background .15s}',
      '.home-tool-tile-v1138:hover{border-color:#b54a55;background:#1b181b;box-shadow:0 0 12px rgba(242,47,61,.08)}',
      '.home-tool-tile-v1138 .tool-icon{font-size:22px;line-height:1}',
      '.home-tool-tile-v1138 b{font-size:12px;line-height:1.2}',
      '.home-tool-tile-v1138 small{font-size:9px;color:#a6b4bf;line-height:1.4}',
      '.home-tool-tile-v1138.amazon{border-color:#315944}',
      '.home-tool-tile-v1138.amazon:hover{border-color:#6eba8a;background:#14241c}',
      '@media(max-width:520px){.home-tool-tile-v1138{flex:1 1 140px;width:auto}}'
    ].join('');
    document.head.appendChild(style);
  })();

  // One click from Home copies the pack without asking for a name or credentials.
  window.copyHomeTrainingPackV1138=async function(){
    await copyText(buildTrainingPackMessageV1137(),'Training pack copied · send login separately');
  };
  const previousRenderHomeV1138=renderHome;
  renderHome=function(el){
    previousRenderHomeV1138(el);
    // The previous home onboarding dashboard is deliberately hidden.
    el.querySelector('.onboarding-home')?.remove();
    const strip=el.querySelector('.today-strip');
    if(!strip || el.querySelector('.home-quick-tools-v1138'))return;
    const tools=document.createElement('div');
    tools.className='home-quick-tools-v1138';
    tools.innerHTML=
      '<button class="home-tool-tile-v1138" onclick="copyHomeTrainingPackV1138()" title="Copy AmiGO training instructions with one click">'+
      '<span class="tool-icon">📦</span><b>Training Pack</b><small>One-click copy · send login separately</small></button>'+
      '<button class="home-tool-tile-v1138 amazon" onclick="openAmazonOnboardingV1125()" title="Open Amazon Associates onboarding in your browser">'+
      '<span class="tool-icon">↗</span><b>Amazon Onboarding</b><small>Open Associates to check 14/15</small></button>';
    strip.insertAdjacentElement('afterend',tools);
  };
  const previousRenderV1138=render;
  render=function(){
    if(currentPage==='onboarding'||currentPage==='onboardingtest'){
      currentPage='home';renderNav();
    }
    return previousRenderV1138();
  };

  // v1.1.42: only the final recruiter-confirmed decision writes Hired / Not Hired.
  // All checklist ticks stay local; reuse the conflict-safe official sync queue.
  window.pipelineQueueDecisionV1142=function(id,decision,reason){
    const c=state.candidates.find(x=>String(x.id)===String(id));
    if(!c||!c.mblId)return Promise.resolve({error:'Candidate is not linked to official MBL'});
    if(!['hired','not_hired'].includes(decision))return Promise.resolve({error:'Invalid hiring decision'});
    if(decision==='not_hired' && !String(reason||'').trim())return Promise.resolve({error:'Not Hired requires a reason'});
    return queueSync(c,{type:decision==='hired'?'hired':'not_proceeding',
      note:decision==='not_hired'?String(reason||'').trim():'',expected:expectedFor(c)});
  };

  // v1.1.53 — every booked induction has a single YES/NO attendance workflow,
  // whether their MBL call-board column is Confirmed, Spoke To, Call Back or
  // To Call. An unconfirmed invitation is not the same as an absent attendee.
  function attendanceCandidatesTodayV1153(){
    // The everyday induction check MUST use the same confirmed roster as
    // the calendar, plus only genuinely recorded outcomes on this date.
    // Provisional bookings are handled through the separate historical
    // correction / official review workflows, never mixed into this form.
    return inductionPeopleForDate(todayDMY())
      .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||'')));
  }
  const priorSaveAttendanceV1153=saveAttendance;
  saveAttendance=function(){
    const today=todayDMY();
    const booked=attendanceCandidatesTodayV1153();
    const decisions=Object.entries(attendanceTemp||{}).filter(([id])=>
      booked.some(c=>String(c.id)===String(id)));
    if(!decisions.length){
      toast('Select YES / NO for at least one candidate; existing saved results are protected.');
      return;
    }
    const undecided=booked.filter(c=>
      recordedAttendance(c)?.date!==today &&
      !['attended','not_attended'].includes(String(c.officialCallStage||'')) &&
      !Object.prototype.hasOwnProperty.call(attendanceTemp,c.id));
    if(undecided.length&&!confirm(
       decisions.length+' attendance choice(s) made, but '+undecided.length+
       ' booked candidate(s) still have NO recorded outcome: '+
       undecided.slice(0,6).map(c=>c.name).join(', ')+
       (undecided.length>6?'…':'')+
       '\\n\\nSave the selected decisions and leave these people unchecked?'+
       '\\nMBL may flag them tomorrow. Cancel to finish checking.'))return;
    // Persist the exact recruiter's decision BEFORE any network operation.
    // No automatic marking of missing people, no automatic status reversal.
    for(const [id,attended] of decisions){
      const c=booked.find(c=>String(c.id)===String(id));
      if(!c)continue;
      localAttendanceRecord(c,attended?'attended':'not_attended',today);
      if(!attended)c.lastInduction=today;
    }
    save();
    return priorSaveAttendanceV1153();
  };
  const previousOpenAttendanceV1153=openAttendance;
  openAttendance=function(keepSelections=false){
    const today=todayDMY(),booked=attendanceCandidatesTodayV1153();
    if(!booked.length)return previousOpenAttendanceV1153(keepSelections);
    if(!keepSelections)attendanceTemp={};
    const html=booked.map(c=>{
      const saved=recordedAttendance(c),prior=saved?.date===today;
      const official=String(c.officialCallStage||'');
      const verified=prior && official===saved.outcome;
      const finished=verified || (!prior&&['attended','not_attended'].includes(official));
      const status=prior
        ?(saved.outcome==='attended'?'YES · Attended':'NO · Not attended')+
          (verified?' · confirmed by MBL':' · OFFICIAL MBL NOT VERIFIED')
        :finished?'Already recorded by MBL: '+official:'Awaiting YES / NO';
      const note=prior||finished
        ?'<span style="color:'+(verified||finished?'#9ad5ac':'#ffb0aa')+
          ';font-weight:800;font-size:10px">'+esc(status)+'</span>'
        :'<button class="yesno '+(attendanceTemp[c.id]===true?'sel yes':'')+
          '" id="ay'+Number(c.id)+'" onclick="setAttend('+Number(c.id)+',true)">YES</button>'+
         '<button class="yesno '+(attendanceTemp[c.id]===false?'sel no':'')+
          '" id="an'+Number(c.id)+'" onclick="setAttend('+Number(c.id)+',false)">NO</button>';
      return '<div class="attrow"><div><b>'+esc(c.name)+'</b>'+
        '<div class="sub">'+esc(c.phone)+
        ' · Official MBL: '+esc(official||'Booked, not confirmed')+'</div>'+
        '<div class="att-reschedule-note">Induction '+esc(today)+
        ' · attendance is independent of call confirmation</div>'+
        '</div>'+note+
        (!prior&&!finished?'<button class="att-change-date" onclick="startAttendanceDateChange('+
          Number(c.id)+')">Change date</button>':
          (!verified&&prior?'<button class="smallbtn" onclick="openSyncPanel()">Review MBL</button>':''))+
        '</div>';
    }).join('');
    const unrecorded=booked.filter(c=>recordedAttendance(c)?.date!==today &&
      !['attended','not_attended'].includes(String(c.officialCallStage||''))).length;
    document.getElementById('attendanceList').innerHTML=
      '<div class="history-check-help-v1134"><b>'+booked.length+
      '</b> booked for '+esc(today)+' · <b>'+unrecorded+
      '</b> awaiting YES / NO. This is your confirmed induction roster, with previously saved outcomes retained. Unconfirmed calls are not added. Select NO only when they genuinely did not attend. Red means MBL has not accepted the saved outcome.</div>'+
      html;
    const saveButton=document.querySelector('#attendanceModal .modalfoot .cta.red');
    if(saveButton){
      saveButton.style.display=unrecorded?'':'none';
      saveButton.textContent='Save attendance & verify official MBL';
    }
    openModal('attendanceModal');
  };
  window.openAttendance=openAttendance;
  window.attendanceCandidatesTodayV1153=attendanceCandidatesTodayV1153;

})();
